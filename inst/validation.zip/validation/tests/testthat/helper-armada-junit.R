# ── ARMADA ENRICHED JUNIT REPORTER ───────────────────────────────────────────
# Shared across every TFL — not generated per-TFL, unlike helper-armada-<tfl>.R.
#
# testthat's JunitReporter emits <testcase name= classname= time=> and nothing
# else: no requirement ID, no expected/actual, no link back to the metadata. So
# Stage 7 can only reconstruct traceability by string-matching test names, and a
# passing test records nothing about what it actually compared.
#
# This adds, per assertion:
#   <testcase id="ARMADA-DV_T01-1-BY_VARIABLE-01" ...>
#     <properties>
#       <property name="requirement_id" value="section-1-by_variable"/>
#       <property name="expected"       value="TRT01PN/NA/TRT01P"/>
#       <property name="actual"         value="TRT01AN/NA/TRT01A"/>
#       <property name="metadata_uuid"  value="3f2a10c4-..."/>
#       <property name="metadata_path"  value="arm$byVariables -> var_group"/>
#     </properties>
#   </testcase>
#
# Closes gap D-d (skills/04-run-tests.md).
# ─────────────────────────────────────────────────────────────────────────────

# ── Evidence slot ────────────────────────────────────────────────────────────
# testthat emits one <testcase> per EXPECTATION, not per test_that(). Evidence
# is therefore per-assertion, and must not drift onto a neighbouring testcase.
#
# A single slot — not a queue — makes drift impossible. Each expect_armada_*()
# sets the slot immediately before firing its expectation; the reporter consumes
# and CLEARS it. A bare expect_*() guard finds the slot already empty and gets no
# properties, which is the correct degradation: no evidence beats wrong evidence.

.armada_evidence <- new.env(parent = emptyenv())
.armada_evidence$current <- NULL
.armada_evidence$warned  <- FALSE

# `assertion` names the RELATION between expected and actual, and only
# "equal" means the two are identical. Without it a reader of the Stage 7
# matrix applies equality to every row, and a membership assertion — where
# `actual` is the set searched, not a scalar — reads as a mismatch that
# somehow passed. Emitted as a property so the report can say which
# comparison was made rather than assuming.
#
# Vocabulary (tokens, not display text — Stage 7 renders them):
#   "equal"   expected == actual
#   "match"   actual satisfies the pattern in expected
#   "member"  expected is present in the set in actual
armada_set_evidence <- function(requirement_id, expected, actual,
                                uuid = NULL, metadata_path = NULL,
                                test_id = NULL, assertion = NULL) {
  .armada_evidence$current <- list(
    requirement_id = requirement_id,
    expected       = armada_fmt_value(expected),
    actual         = armada_fmt_value(actual),
    uuid           = armada_fmt_value(uuid),
    metadata_path  = metadata_path,
    test_id        = test_id,
    assertion      = assertion
  )
  invisible(NULL)
}

armada_take_evidence <- function() {
  ev <- .armada_evidence$current
  .armada_evidence$current <- NULL
  ev
}

# Multi-value fields follow ARMADA's own separator so a property value reads the
# same way the metadata does.
armada_fmt_value <- function(x) {
  if (is.null(x) || length(x) == 0L) return(NA_character_)
  paste(vapply(x, function(v) {
    if (is.null(v) || is.na(v)) "NA" else as.character(v)
  }, character(1)), collapse = " * ")
}

# ── Reporter ─────────────────────────────────────────────────────────────────
# Subclasses the stock reporter rather than replacing it: super$add_result()
# builds the testcase exactly as testthat would, and this appends to it. If a
# future testthat changes those internals, injection is skipped with a warning
# and the XML stays valid, un-enriched JUnit.

ArmadaJunitReporter <- R6::R6Class(
  "ArmadaJunitReporter",
  inherit = testthat::JunitReporter,
  public = list(
    add_result = function(context, test, result) {
      super$add_result(context, test, result)

      ev <- armada_take_evidence()
      if (is.null(ev)) return(invisible(NULL))

      tryCatch({
        kids <- xml2::xml_children(self$suite)
        if (length(kids) == 0L) return(invisible(NULL))
        testcase <- kids[[length(kids)]]

        if (!is.null(ev$test_id)) {
          xml2::xml_set_attr(testcase, "id", ev$test_id)
        }

        props <- xml2::xml_add_child(testcase, "properties")
        add_property <- function(name, value) {
          if (is.null(value) || all(is.na(value)) || !nzchar(as.character(value)[1])) {
            return(invisible(NULL))
          }
          xml2::xml_add_child(props, "property",
                              name = name, value = as.character(value)[1])
        }
        add_property("requirement_id", ev$requirement_id)
        add_property("assertion",      ev$assertion)
        add_property("expected",       ev$expected)
        add_property("actual",         ev$actual)
        add_property("metadata_uuid",  ev$uuid)
        add_property("metadata_path",  ev$metadata_path)
      }, error = function(e) {
        if (!.armada_evidence$warned) {
          warning("ArmadaJunitReporter could not enrich the JUnit XML (",
                  conditionMessage(e), "). Falling back to plain JUnit output. ",
                  "Stage 7 will match tests by name prefix instead.",
                  call. = FALSE)
          .armada_evidence$warned <- TRUE
        }
      })

      invisible(NULL)
    }
  )
)

# ── Assertion wrappers ───────────────────────────────────────────────────────
# Recording and asserting are one call. Split them and a later refactor can move
# one without the other, which is how evidence silently detaches from its claim.

expect_armada_equal <- function(requirement_id, test_id, expected, actual,
                                uuid = NULL, metadata_path = NULL,
                                label = NULL) {
  armada_set_evidence(requirement_id, expected, actual, uuid, metadata_path, test_id,
                      assertion = "equal")
  testthat::expect_equal(
    actual, expected,
    info = paste0(
      if (!is.null(label)) paste0(label, "\n") else "",
      "  Requirement: ", requirement_id, "  [", test_id, "]",
      "\n  Path: ", metadata_path %||% "<unspecified>",
      "\n  Expected: ", armada_fmt_value(expected),
      "\n  Actual: ", armada_fmt_value(actual),
      if (!is.null(uuid)) paste0("\n  UUID: ", armada_fmt_value(uuid)) else ""
    )
  )
}

expect_armada_match <- function(requirement_id, test_id, pattern, actual,
                                expected_display = pattern,
                                uuid = NULL, metadata_path = NULL,
                                label = NULL) {
  armada_set_evidence(requirement_id, expected_display, actual, uuid, metadata_path, test_id,
                      assertion = "match")
  testthat::expect_match(
    as.character(actual), pattern,
    info = paste0(
      if (!is.null(label)) paste0(label, "\n") else "",
      "  Requirement: ", requirement_id, "  [", test_id, "]",
      "\n  Path: ", metadata_path %||% "<unspecified>",
      "\n  Expected to contain: ", expected_display,
      "\n  Actual: ", armada_fmt_value(actual),
      if (!is.null(uuid)) paste0("\n  UUID: ", armada_fmt_value(uuid)) else ""
    )
  )
}

# For membership claims — "the label references ACAT1" — where the actual value
# is the set searched, not a single scalar.
expect_armada_in <- function(requirement_id, test_id, expected, actual_set,
                             uuid = NULL, metadata_path = NULL, label = NULL) {
  armada_set_evidence(requirement_id, expected, actual_set, uuid, metadata_path, test_id,
                      assertion = "member")
  testthat::expect_true(
    expected %in% actual_set,
    info = paste0(
      if (!is.null(label)) paste0(label, "\n") else "",
      "  Requirement: ", requirement_id, "  [", test_id, "]",
      "\n  Path: ", metadata_path %||% "<unspecified>",
      "\n  Expected to be present: ", armada_fmt_value(expected),
      "\n  Actual set: ", armada_fmt_value(actual_set),
      if (!is.null(uuid)) paste0("\n  UUID: ", armada_fmt_value(uuid)) else ""
    )
  )
}

`%||%` <- function(x, y) if (is.null(x)) y else x
