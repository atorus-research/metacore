# ── ARMADA METADATA HELPERS ──────────────────────────────────────────────────
# Auto-generated helpers for ARMADA validation — DV_T01
# DO NOT EDIT MANUALLY — regenerate with agent if requirements change.
# ─────────────────────────────────────────────────────────────────────────────

# The run directory is baked in at generation time. Tests execute from
# tests/testthat/ in a separate process, so this MUST be an absolute path.
ARMADA_RUN_DIR <- "C:/Users/liamh/Documents/validation/validation_runs/dv_t01_20260819-120911"

load_armada_metadata <- function(
    metadata_file = file.path(ARMADA_RUN_DIR, "metadata.json")) {
  if (!file.exists(metadata_file)) {
    stop("metadata.json not found at: ", metadata_file,
         "\n  ARMADA_RUN_DIR points at a run that does not exist. Regenerate Stage 3.")
  }
  jsonlite::read_json(metadata_file)
}

load_armada_requirements <- function(
    requirements_file = file.path(ARMADA_RUN_DIR, "requirements.json")) {
  if (!file.exists(requirements_file)) {
    stop("requirements.json not found at: ", requirements_file,
         "\n  ARMADA_RUN_DIR points at a run that does not exist. Regenerate Stage 3.")
  }
  jsonlite::read_json(requirements_file)
}

split_uuids <- function(uuid_string) {
  if (is.null(uuid_string)) return(character(0))
  s <- as.character(uuid_string)
  if (length(s) == 0L || all(!nzchar(s))) return(character(0))
  trimws(strsplit(s, "\\*")[[1]])
}

# Fails loudly with the UUID rather than returning NULL to be dereferenced later.
get_entity <- function(metadata, uuid) {
  if (is.null(uuid) || !nzchar(as.character(uuid))) {
    stop("UUID not resolved: empty or NULL reference")
  }
  e <- metadata$entities[[as.character(uuid)]]
  if (is.null(e)) {
    stop("UUID not resolved: '", uuid, "' is not present in metadata$entities")
  }
  e
}

get_data <- function(metadata, uuid) get_entity(metadata, uuid)$data

get_main_aom <- function(metadata) {
  for (entity in metadata$entities) {
    if (!is.null(entity$entity_type) && entity$entity_type == "main_aom") return(entity$data)
  }
  NULL
}

get_section_aom <- function(metadata, section_number) {
  # Section order is defined ONLY by position in main_aom$sections —
  # section_aom entities carry no section number of their own.
  main_aom <- get_main_aom(metadata)
  uuids <- split_uuids(main_aom$sections)
  if (section_number > length(uuids)) return(NULL)
  get_data(metadata, uuids[section_number])
}

# section_aom$analyses -> arm
get_section_arm_uuid <- function(metadata, section_number) {
  section_aom <- get_section_aom(metadata, section_number)
  if (is.null(section_aom)) stop("Section ", section_number, " not found in metadata")
  split_uuids(section_aom$analyses)[1]
}

get_section_arm <- function(metadata, section_number) {
  get_data(metadata, get_section_arm_uuid(metadata, section_number))
}

# arm$methodGroupID -> methodgroup$methods -> first method UUID
get_section_method_uuid <- function(metadata, arm) {
  split_uuids(get_data(metadata, arm$methodGroupID)$methods)[1]
}

# arm$byVariables -> var_group[] rendered as "num/code/decode"
get_by_variable_specs <- function(metadata, arm) {
  uuids <- split_uuids(arm$byVariables)
  vapply(uuids, function(u) {
    vg <- get_data(metadata, u)
    paste(
      if (is.null(vg$variableNum))    "NA" else vg$variableNum,
      if (is.null(vg$variableCode))   "NA" else vg$variableCode,
      if (is.null(vg$variableDecode)) "NA" else vg$variableDecode,
      sep = "/"
    )
  }, character(1), USE.NAMES = FALSE)
}

get_full_matrix_flags <- function(metadata, arm) {
  uuids <- split_uuids(arm$byVariables)
  vapply(uuids, function(u) {
    fm <- get_data(metadata, u)$fullMatrix
    if (is.null(fm)) NA_character_ else as.character(fm)
  }, character(1), USE.NAMES = FALSE)
}

# arm$methodGroupID -> methodgroup$methods -> method[]
get_section_methods <- function(metadata, arm) {
  mg <- get_data(metadata, arm$methodGroupID)
  lapply(split_uuids(mg$methods), function(u) get_data(metadata, u))
}

# section_aom$labels -> label_aom[]
get_section_labels <- function(metadata, section_number) {
  section_aom <- get_section_aom(metadata, section_number)
  lapply(split_uuids(section_aom$labels), function(u) get_data(metadata, u))
}

# Pattern 3: template labels carry no text — label_aom$value points at a
# var_group. Collect every variable reachable from this section's labels.
get_label_variables <- function(metadata, section_number) {
  labels <- get_section_labels(metadata, section_number)
  vars <- character(0)
  for (lbl in labels) {
    if (is.null(lbl$value)) next
    vg <- get_data(metadata, lbl$value)
    vars <- c(vars, unlist(list(vg$variableNum, vg$variableCode, vg$variableDecode)))
  }
  unique(vars[!is.na(vars) & vars != "NA"])
}

# Pattern 2: section_aom$resultFormat -> format_group$formats -> format$reportLabel
get_result_format_labels <- function(metadata, section_number) {
  section_aom <- get_section_aom(metadata, section_number)
  if (is.null(section_aom$resultFormat)) return(character(0))
  fg <- get_data(metadata, section_aom$resultFormat)
  vapply(split_uuids(fg$formats), function(u) {
    rl <- get_data(metadata, u)$reportLabel
    if (is.null(rl)) NA_character_ else as.character(rl)
  }, character(1), USE.NAMES = FALSE)
}

fmt <- function(x) {
  if (is.null(x) || length(x) == 0L) return("<NULL>")
  paste(as.character(x), collapse = ", ")
}
