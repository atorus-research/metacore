# ── ARMADA VALIDATION TESTS — DV_T01 ─────────────────────────────────────────
# Auto-generated from ADO requirements
# Generated from: https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276
#                 (dummy run — card body taken from "metadata requirements.txt")
# Requirements  : <run-dir>/requirements.json   (19 requirements, 3 sections)
# Metadata      : <run-dir>/metadata.json       (39 entities)
#
# Every assertion goes through expect_armada_*() (helper-armada-junit.R), which
# records requirement ID, test ID, expected, actual, metadata UUID and path into
# the JUnit XML as <testcase id=...><properties>. Stage 7 builds the traceability
# matrix from those properties.
#
# Test ID scheme: ARMADA-<TFL>-<SECTION>-<TYPE>-<INDEX>
#
# DO NOT EDIT MANUALLY — regenerate with agent if requirements change.
# ─────────────────────────────────────────────────────────────────────────────

metadata     <- load_armada_metadata()
requirements <- load_armada_requirements()

# ── Output-level requirements ────────────────────────────────────────────────

test_that("output-title: display title is the card's title", {
  expect_armada_equal(
    requirement_id = "output-title",
    test_id        = "ARMADA-DV_T01-OUTPUT-TITLE-01",
    expected       = "Summary of Important Protocol Deviations",
    actual         = get_main_aom(metadata)$outputLabel,
    metadata_path  = "main_aom$outputLabel",
    label          = "Output title mismatch."
  )

  # The card states the title twice — as MainAOM.outputLabel and as the
  # rendered title entity. Both must agree, or the PDF and the metadata differ.
  title_uuid <- split_uuids(get_main_aom(metadata)$titles)[1]
  expect_armada_equal(
    requirement_id = "output-title",
    test_id        = "ARMADA-DV_T01-OUTPUT-TITLE-02",
    expected       = "Summary of Important Protocol Deviations",
    actual         = get_data(metadata, title_uuid)$footnoteText,
    uuid           = title_uuid,
    metadata_path  = "main_aom$titles -> title_foot_aom$footnoteText",
    label          = "Rendered title does not match main_aom$outputLabel."
  )
})

test_that("output-analysis_set: analysis set is Enrolled, ENRLFL EQ \"Y\"", {
  main_aom <- get_main_aom(metadata)

  expect_armada_equal(
    requirement_id = "output-analysis_set",
    test_id        = "ARMADA-DV_T01-OUTPUT-ANALYSIS_SET-01",
    expected       = "Enrolled",
    actual         = main_aom$analysisSetLabel,
    metadata_path  = "main_aom$analysisSetLabel",
    label          = "Analysis set label mismatch."
  )

  expect_armada_match(
    requirement_id   = "output-analysis_set",
    test_id          = "ARMADA-DV_T01-OUTPUT-ANALYSIS_SET-02",
    pattern          = "ENRLFL.*EQ.*Y",
    actual           = get_data(metadata, main_aom$analysisSet)$whereClause,
    expected_display = "ENRLFL EQ \"Y\"",
    uuid             = main_aom$analysisSet,
    metadata_path    = "main_aom$analysisSet -> where_clause$whereClause",
    label            = "Analysis set filter mismatch."
  )
})

test_that("output-treatment: planned treatment with a full-matrix codelist of A and B", {
  # The card asks for three distinct things: planned (not actual) treatment
  # variables, a codelist with full matrix TRUE, and exactly Treatment A and B
  # in column order. Each is asserted separately so a failure names which.
  cg <- get_data(metadata, get_main_aom(metadata)$columnGroup)
  codelist_uuid <- cg$codelist
  codelist <- get_data(metadata, codelist_uuid)
  item_uuids <- split_uuids(codelist$items)
  items <- lapply(item_uuids, function(u) get_data(metadata, u))

  expect_armada_equal(
    requirement_id = "output-treatment",
    test_id        = "ARMADA-DV_T01-OUTPUT-TREATMENT-01",
    expected       = "TRUE",
    actual         = toupper(as.character(codelist$fullMatrix)),
    uuid           = codelist_uuid,
    metadata_path  = "column_group_aom$codelist -> codelist$fullMatrix",
    label          = "Treatment codelist is not full matrix."
  )

  expect_armada_equal(
    requirement_id = "output-treatment",
    test_id        = "ARMADA-DV_T01-OUTPUT-TREATMENT-02",
    expected       = c("Treatment A", "Treatment B"),
    actual         = vapply(items, function(i) as.character(i$decode), character(1)),
    uuid           = item_uuids,
    metadata_path  = "codelist$items -> codelistitem$decode",
    label          = "Treatment codelist decodes are not Treatment A and Treatment B."
  )

  # Numeric values must follow the order of the treatment columns.
  expect_armada_equal(
    requirement_id = "output-treatment",
    test_id        = "ARMADA-DV_T01-OUTPUT-TREATMENT-03",
    expected       = c("1", "2"),
    actual         = vapply(items, function(i) as.character(i$code), character(1)),
    uuid           = item_uuids,
    metadata_path  = "codelist$items -> codelistitem$code",
    label          = "Treatment codes are not aligned with column order."
  )

  # "No total column" — a parallel study takes no Total per display principle 400.
  decodes <- vapply(items, function(i) tolower(as.character(i$decode)), character(1))
  expect_armada_equal(
    requirement_id = "output-treatment",
    test_id        = "ARMADA-DV_T01-OUTPUT-TREATMENT-04",
    expected       = "0",
    actual         = as.character(sum(grepl("total|no treatment", decodes))),
    uuid           = codelist_uuid,
    metadata_path  = "codelist$items -> codelistitem$decode (Total / No Treatment)",
    label          = "A Total or No Treatment column is present; the card excludes both by default."
  )
})

test_that("output-column: two stub columns and two result columns", {
  cg <- get_data(metadata, get_main_aom(metadata)$columnGroup)
  col_uuids <- split_uuids(cg$columns)
  types <- vapply(col_uuids, function(u) as.character(get_data(metadata, u)$type),
                  character(1), USE.NAMES = FALSE)

  expect_armada_equal(
    requirement_id = "output-column",
    test_id        = "ARMADA-DV_T01-OUTPUT-COLUMN-01",
    expected       = "2",
    actual         = as.character(sum(types == "stub")),
    uuid           = col_uuids,
    metadata_path  = "main_aom$columnGroup -> column_group_aom$columns -> column_aom$type == 'stub'",
    label          = "Stub column count does not match the card."
  )

  expect_armada_equal(
    requirement_id = "output-column",
    test_id        = "ARMADA-DV_T01-OUTPUT-COLUMN-02",
    expected       = "2",
    actual         = as.character(sum(types == "result")),
    uuid           = col_uuids,
    metadata_path  = "column_group_aom$columns -> column_aom$type == 'result'",
    label          = "Result column count does not match the card (one per treatment subset)."
  )

  # The card states the stub columns are indented.
  stub_indents <- vapply(col_uuids, function(u) {
    d <- get_data(metadata, u)
    if (identical(as.character(d$type), "stub")) as.character(d$indent) else NA_character_
  }, character(1), USE.NAMES = FALSE)
  expect_armada_equal(
    requirement_id = "output-column",
    test_id        = "ARMADA-DV_T01-OUTPUT-COLUMN-03",
    expected       = c("0", "1"),
    actual         = stub_indents[!is.na(stub_indents)],
    uuid           = col_uuids,
    metadata_path  = "column_aom$indent (stub columns)",
    label          = "Stub columns are not indented as the card describes."
  )
})

test_that("output-sorting_order: descending by incidence, alphabetical on ties", {
  arm <- get_section_arm(metadata, 3)
  if (is.null(arm$rangeCheck)) {
    skip(paste("No sort specification is attached to the section 3 arm",
               "(arm$rangeCheck is absent), so sorting order cannot be asserted",
               "from the metadata. Confirm with the display owner whether sorting",
               "is applied downstream by the executor."))
  }
  rc <- get_data(metadata, arm$rangeCheck)

  expect_armada_equal(
    requirement_id = "output-sorting_order",
    test_id        = "ARMADA-DV_T01-OUTPUT-SORTING_ORDER-01",
    expected       = "DESCENDING",
    actual         = toupper(as.character(rc$sortOrder)),
    uuid           = arm$rangeCheck,
    metadata_path  = "arm$rangeCheck -> range_check$sortOrder",
    label          = "Sort order is not descending by total incidence."
  )

  expect_armada_equal(
    requirement_id = "output-sorting_order",
    test_id        = "ARMADA-DV_T01-OUTPUT-SORTING_ORDER-02",
    expected       = "ALPHABETICAL",
    actual         = toupper(as.character(rc$tieBreak)),
    uuid           = arm$rangeCheck,
    metadata_path  = "arm$rangeCheck -> range_check$tieBreak",
    label          = "Tie-break is not alphabetical."
  )
})

test_that("output-footnotes: the table must not display any footnotes", {
  main_aom <- get_main_aom(metadata)
  expect_false(is.null(main_aom), info = "main_aom not found in metadata")

  footnote_uuids <- split_uuids(main_aom$footnotes)
  actual <- if (length(footnote_uuids) == 0L) "<none>" else
    paste(vapply(footnote_uuids, function(u) {
      ft <- get_data(metadata, u)$footnoteText
      if (is.null(ft)) NA_character_ else as.character(ft)
    }, character(1), USE.NAMES = FALSE), collapse = " * ")

  expect_armada_equal(
    requirement_id = "output-footnotes",
    test_id        = "ARMADA-DV_T01-OUTPUT-FOOTNOTES-01",
    expected       = "<none>",
    actual         = actual,
    uuid           = if (length(footnote_uuids)) footnote_uuids else NULL,
    metadata_path  = "main_aom$footnotes -> title_foot_aom$footnoteText",
    label          = "Footnotes present where the card specifies none."
  )
})

# ── Section 1 — Any Important Protocol Deviations ────────────────────────────

test_that("section-1-display_label: display label is the literal card text", {
  # Pattern 1 — requirement text is literal, so match label_aom$displayLabel.
  section_aom <- get_section_aom(metadata, 1)
  label_uuid  <- split_uuids(section_aom$labels)[1]

  expect_armada_equal(
    requirement_id = "section-1-display_label",
    test_id        = "ARMADA-DV_T01-1-DISPLAY_LABEL-01",
    expected       = "Any Important Protocol Deviations",
    actual         = get_data(metadata, label_uuid)$displayLabel,
    uuid           = label_uuid,
    metadata_path  = "section_aom$labels -> label_aom$displayLabel",
    label          = "Display label mismatch in Section 1."
  )
})

test_that("section-1-method: method counts distinct subjects with >=1 important deviation", {
  arm         <- get_section_arm(metadata, 1)
  method_uuid <- get_section_method_uuid(metadata, arm)

  expect_armada_equal(
    requirement_id = "section-1-method",
    test_id        = "ARMADA-DV_T01-1-METHOD-01",
    expected       = "Number of distinct subjects (USUBJID) with at least one important protocol deviation, and percentage",
    actual         = get_data(metadata, method_uuid)$description,
    uuid           = method_uuid,
    metadata_path  = "arm$methodGroupID -> methodgroup$methods -> method$description",
    label          = "Method mismatch in Section 1."
  )
})

test_that("section-1-by_variable: stratified by TRT01PN/NA/TRT01P with full matrix", {
  arm      <- get_section_arm(metadata, 1)
  vg_uuids <- split_uuids(arm$byVariables)

  expect_armada_equal(
    requirement_id = "section-1-by_variable",
    test_id        = "ARMADA-DV_T01-1-BY_VARIABLE-01",
    expected       = c("TRT01PN/NA/TRT01P"),
    actual         = get_by_variable_specs(metadata, arm),
    uuid           = vg_uuids,
    metadata_path  = "arm$byVariables -> var_group$variableNum/Code/Decode",
    label          = "By-variable mismatch in Section 1."
  )

  expect_armada_equal(
    requirement_id = "section-1-by_variable",
    test_id        = "ARMADA-DV_T01-1-BY_VARIABLE-02",
    expected       = c("Yes"),
    actual         = get_full_matrix_flags(metadata, arm),
    uuid           = vg_uuids,
    metadata_path  = "arm$byVariables -> var_group$fullMatrix",
    label          = "Full-matrix flag mismatch in Section 1."
  )
})

test_that("section-1-domain: domain is ADDV", {
  expect_armada_equal(
    requirement_id = "section-1-domain",
    test_id        = "ARMADA-DV_T01-1-DOMAIN-01",
    expected       = "ADDV",
    actual         = get_section_arm(metadata, 1)$domain,
    uuid           = get_section_arm_uuid(metadata, 1),
    metadata_path  = "section_aom$analyses -> arm$domain",
    label          = "Domain mismatch in Section 1."
  )
})

test_that("section-1-subset: subset is ADIMPTFL EQ \"Y\"", {
  arm <- get_section_arm(metadata, 1)
  expect_false(is.null(arm$subSet), info = "subSet not defined for Section 1's arm")

  expect_armada_match(
    requirement_id   = "section-1-subset",
    test_id          = "ARMADA-DV_T01-1-SUBSET-01",
    pattern          = "ADIMPTFL.*EQ.*Y",
    actual           = get_data(metadata, arm$subSet)$whereClause,
    expected_display = "ADIMPTFL EQ \"Y\"",
    uuid             = arm$subSet,
    metadata_path    = "arm$subSet -> where_clause$whereClause",
    label            = "Subset filter does not match requirement in Section 1."
  )
})

test_that("section-1-denominator: denominator is Big N (analysis-set-enrolled-counts)", {
  arm <- get_section_arm(metadata, 1)
  denom_uuid <- if (!is.null(arm$denomID)) arm$denomID else get_main_aom(metadata)$bigNAnalysisID
  expect_false(is.null(denom_uuid),
    info = "Neither arm$denomID nor main_aom$bigNAnalysisID is set for Section 1")

  expect_armada_equal(
    requirement_id = "section-1-denominator",
    test_id        = "ARMADA-DV_T01-1-DENOMINATOR-01",
    expected       = "analysis-set-enrolled-counts",
    actual         = get_data(metadata, denom_uuid)$armID,
    uuid           = denom_uuid,
    metadata_path  = "arm$denomID -> arm$armID",
    label          = "Denominator mismatch in Section 1."
  )
})

# ── Section 2 — By Category ──────────────────────────────────────────────────

test_that("section-2-display_label: template label resolves to the ACAT1 variable group", {
  # Pattern 3 — requirement text is the template "<category name>", so the label
  # is validated by the variable group it references, not by text.
  section_aom <- get_section_aom(metadata, 2)

  expect_armada_in(
    requirement_id = "section-2-display_label",
    test_id        = "ARMADA-DV_T01-2-DISPLAY_LABEL-01",
    expected       = "ACAT1",
    actual_set     = get_label_variables(metadata, 2),
    uuid           = split_uuids(section_aom$labels),
    metadata_path  = "section_aom$labels -> label_aom$value -> var_group",
    label          = "Section 2 label does not reference the expected variable."
  )
})

test_that("section-2-method: method counts distinct subjects with >=1 deviation in the category", {
  arm         <- get_section_arm(metadata, 2)
  method_uuid <- get_section_method_uuid(metadata, arm)

  expect_armada_equal(
    requirement_id = "section-2-method",
    test_id        = "ARMADA-DV_T01-2-METHOD-01",
    expected       = "Number of distinct subjects (USUBJID) with at least one deviation in the category, and percentage",
    actual         = get_data(metadata, method_uuid)$description,
    uuid           = method_uuid,
    metadata_path  = "arm$methodGroupID -> methodgroup$methods -> method$description",
    label          = "Method mismatch in Section 2."
  )
})

test_that("section-2-by_variable: stratified by TRT01PN/NA/TRT01P (full) * NA/NA/ACAT1 (observed)", {
  arm      <- get_section_arm(metadata, 2)
  vg_uuids <- split_uuids(arm$byVariables)

  expect_armada_equal(
    requirement_id = "section-2-by_variable",
    test_id        = "ARMADA-DV_T01-2-BY_VARIABLE-01",
    expected       = c("TRT01PN/NA/TRT01P", "NA/NA/ACAT1"),
    actual         = get_by_variable_specs(metadata, arm),
    uuid           = vg_uuids,
    metadata_path  = "arm$byVariables -> var_group$variableNum/Code/Decode",
    label          = "By-variable mismatch in Section 2."
  )

  expect_armada_equal(
    requirement_id = "section-2-by_variable",
    test_id        = "ARMADA-DV_T01-2-BY_VARIABLE-02",
    expected       = c("Yes", "No"),
    actual         = get_full_matrix_flags(metadata, arm),
    uuid           = vg_uuids,
    metadata_path  = "arm$byVariables -> var_group$fullMatrix",
    label          = "Full-matrix flag mismatch in Section 2."
  )
})

test_that("section-2-domain: domain is ADDV", {
  expect_armada_equal(
    requirement_id = "section-2-domain",
    test_id        = "ARMADA-DV_T01-2-DOMAIN-01",
    expected       = "ADDV",
    actual         = get_section_arm(metadata, 2)$domain,
    uuid           = get_section_arm_uuid(metadata, 2),
    metadata_path  = "section_aom$analyses -> arm$domain",
    label          = "Domain mismatch in Section 2."
  )
})

test_that("section-2-subset: subset is ADIMPTFL EQ \"Y\"", {
  arm <- get_section_arm(metadata, 2)
  expect_false(is.null(arm$subSet), info = "subSet not defined for Section 2's arm")

  expect_armada_match(
    requirement_id   = "section-2-subset",
    test_id          = "ARMADA-DV_T01-2-SUBSET-01",
    pattern          = "ADIMPTFL.*EQ.*Y",
    actual           = get_data(metadata, arm$subSet)$whereClause,
    expected_display = "ADIMPTFL EQ \"Y\"",
    uuid             = arm$subSet,
    metadata_path    = "arm$subSet -> where_clause$whereClause",
    label            = "Subset filter does not match requirement in Section 2."
  )
})

test_that("section-2-denominator: denominator is Big N (analysis-set-enrolled-counts)", {
  arm <- get_section_arm(metadata, 2)
  denom_uuid <- if (!is.null(arm$denomID)) arm$denomID else get_main_aom(metadata)$bigNAnalysisID

  expect_armada_equal(
    requirement_id = "section-2-denominator",
    test_id        = "ARMADA-DV_T01-2-DENOMINATOR-01",
    expected       = "analysis-set-enrolled-counts",
    actual         = get_data(metadata, denom_uuid)$armID,
    uuid           = denom_uuid,
    metadata_path  = "arm$denomID -> arm$armID",
    label          = "Denominator mismatch in Section 2."
  )
})

# ── Section 3 — By Category and Coded Term ───────────────────────────────────

test_that("section-3-display_label: template label resolves to the ADECOD variable group", {
  # Pattern 3 — "<coded term>" is a template. Section 3 carries multiple label
  # tiers (category, coded term, .missing); the coded-term tier must reference
  # ADECOD.
  section_aom <- get_section_aom(metadata, 3)

  expect_armada_in(
    requirement_id = "section-3-display_label",
    test_id        = "ARMADA-DV_T01-3-DISPLAY_LABEL-01",
    expected       = "ADECOD",
    actual_set     = get_label_variables(metadata, 3),
    uuid           = split_uuids(section_aom$labels),
    metadata_path  = "section_aom$labels -> label_aom$value -> var_group",
    label          = "Section 3 label does not reference the expected variable."
  )
})

test_that("section-3-method: method counts distinct subjects matching category and coded term", {
  arm         <- get_section_arm(metadata, 3)
  method_uuid <- get_section_method_uuid(metadata, arm)

  expect_armada_equal(
    requirement_id = "section-3-method",
    test_id        = "ARMADA-DV_T01-3-METHOD-01",
    expected       = "Number of distinct subjects (USUBJID) with at least one deviation matching the category and coded term, and percentage",
    actual         = get_data(metadata, method_uuid)$description,
    uuid           = method_uuid,
    metadata_path  = "arm$methodGroupID -> methodgroup$methods -> method$description",
    label          = "Method mismatch in Section 3."
  )
})

test_that("section-3-by_variable: stratified by treatment * ACAT1 * ADECOD", {
  arm      <- get_section_arm(metadata, 3)
  vg_uuids <- split_uuids(arm$byVariables)

  expect_armada_equal(
    requirement_id = "section-3-by_variable",
    test_id        = "ARMADA-DV_T01-3-BY_VARIABLE-01",
    expected       = c("TRT01PN/NA/TRT01P", "NA/NA/ACAT1", "NA/NA/ADECOD"),
    actual         = get_by_variable_specs(metadata, arm),
    uuid           = vg_uuids,
    metadata_path  = "arm$byVariables -> var_group$variableNum/Code/Decode",
    label          = "By-variable mismatch in Section 3."
  )

  expect_armada_equal(
    requirement_id = "section-3-by_variable",
    test_id        = "ARMADA-DV_T01-3-BY_VARIABLE-02",
    expected       = c("Yes", "No", "No"),
    actual         = get_full_matrix_flags(metadata, arm),
    uuid           = vg_uuids,
    metadata_path  = "arm$byVariables -> var_group$fullMatrix",
    label          = "Full-matrix flag mismatch in Section 3."
  )
})

test_that("section-3-domain: domain is ADDV", {
  expect_armada_equal(
    requirement_id = "section-3-domain",
    test_id        = "ARMADA-DV_T01-3-DOMAIN-01",
    expected       = "ADDV",
    actual         = get_section_arm(metadata, 3)$domain,
    uuid           = get_section_arm_uuid(metadata, 3),
    metadata_path  = "section_aom$analyses -> arm$domain",
    label          = "Domain mismatch in Section 3."
  )
})

test_that("section-3-subset: subset is ADIMPTFL EQ \"Y\"", {
  arm <- get_section_arm(metadata, 3)
  expect_false(is.null(arm$subSet), info = "subSet not defined for Section 3's arm")

  expect_armada_match(
    requirement_id   = "section-3-subset",
    test_id          = "ARMADA-DV_T01-3-SUBSET-01",
    pattern          = "ADIMPTFL.*EQ.*Y",
    actual           = get_data(metadata, arm$subSet)$whereClause,
    expected_display = "ADIMPTFL EQ \"Y\"",
    uuid             = arm$subSet,
    metadata_path    = "arm$subSet -> where_clause$whereClause",
    label            = "Subset filter does not match requirement in Section 3."
  )
})

test_that("section-3-denominator: denominator is Big N (analysis-set-enrolled-counts)", {
  arm <- get_section_arm(metadata, 3)
  denom_uuid <- if (!is.null(arm$denomID)) arm$denomID else get_main_aom(metadata)$bigNAnalysisID

  expect_armada_equal(
    requirement_id = "section-3-denominator",
    test_id        = "ARMADA-DV_T01-3-DENOMINATOR-01",
    expected       = "analysis-set-enrolled-counts",
    actual         = get_data(metadata, denom_uuid)$armID,
    uuid           = denom_uuid,
    metadata_path  = "arm$denomID -> arm$armID",
    label          = "Denominator mismatch in Section 3."
  )
})
