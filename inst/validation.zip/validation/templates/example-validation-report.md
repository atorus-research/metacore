<!--
  EXAMPLE ONLY — not evidence for any real validation run.

  A reference rendering of the Stage 7 validation report, produced by
  unified_report_generator.py from a synthetic DV_T01 run directory. Read it
  alongside validation-report-template.md: the template is the contract, this
  is what conformance looks like.

  The scenario deliberately exercises the machinery rather than showing an
  all-green page:
    - by_variable and denominator fail in all three sections
      (metadata has TRT01AN/TRT01A and safety-counts; the spec asks for
       TRT01PN/TRT01P and enrolled-counts)
    - section-3-subset is skipped, with a stated reason
    - output-footnotes has no test at all
    - execution succeeded and the working tree was clean

  Two criteria therefore fail and the verdict is FAIL, despite a 63% pass
  rate — an untested requirement is a coverage failure however well the
  executed tests did.

  Run directory path and timestamps have been normalised for stability.
-->
# ARMADA Validation Report: Complete Pipeline Evidence

This document consolidates all validation and execution evidence for regulatory submission.

**Run directory:** `/mnt/code/validation_runs/dv_t01_20260818-091420`
**Report generated:** 2026-08-18T09:15:44

---

## 1. COMMIT INFORMATION

**Commit Hash:** `76e481fb597096a40b995a0801b3f43f96f56f3f`
**Author:** Liam Hobby (liam.hobby@example.com)
**Date:** 2026-08-18T08:52:11+00:00
**Repository:** /mnt/code
**Branch:** pa_01
**Validated At:** 2026-08-18T09:14:20+00:00

**Working tree:** clean ✅

**Related TFL:** Summary of Important Protocol Deviations
**Output ID:** `dv_t01_sum_impo_prot_dev_armada`


---

## 2. REQUIREMENTS SUMMARY

**Total Requirements:** 20
**Output-level:** 2
**Section-level:** 18, across 3 section(s)

### Overview by Type

| Type | Count | Description |
|------|-------|-------------|
| `by_variable` | 3 | Grouping/stratification variables |
| `denominator` | 3 | Denominator dataset definitions |
| `display_label` | 3 | Section display labels (human-readable names) |
| `domain` | 3 | SDTM domain source mappings |
| `footnotes` | 1 | Explanatory text displayed below the table |
| `method` | 3 | Statistical methods (calculations) |
| `subset` | 3 | Filtering logic (inclusion/exclusion) |
| `title` | 1 | Output title displayed above the table |


---

## 3. TRACEABILITY MATRIX: Validation Evidence

**Test Framework:** testthat (R)
**Overall Result:** ❌ FAIL — 12/19 passed (63%)

### Test Outcomes

| Metric | Value |
|--------|-------|
| Tests executed | 19 |
| Passed | 12 |
| Failed | 6 |
| Skipped | 1 |

### Requirement Coverage

**19/20 requirement(s) exercised by at least one test.**

| Requirement | Tests | Result |
|---|---|---|
| `output-title` | 1 | ✅ PASS |
| `output-footnotes` | 0 | ❌ NO TEST |
| `section-1-display_label` | 1 | ✅ PASS |
| `section-1-method` | 1 | ✅ PASS |
| `section-1-by_variable` | 1 | ❌ FAIL |
| `section-1-domain` | 1 | ✅ PASS |
| `section-1-subset` | 1 | ✅ PASS |
| `section-1-denominator` | 1 | ❌ FAIL |
| `section-2-display_label` | 1 | ✅ PASS |
| `section-2-method` | 1 | ✅ PASS |
| `section-2-by_variable` | 1 | ❌ FAIL |
| `section-2-domain` | 1 | ✅ PASS |
| `section-2-subset` | 1 | ✅ PASS |
| `section-2-denominator` | 1 | ❌ FAIL |
| `section-3-display_label` | 1 | ✅ PASS |
| `section-3-method` | 1 | ✅ PASS |
| `section-3-by_variable` | 1 | ❌ FAIL |
| `section-3-domain` | 1 | ✅ PASS |
| `section-3-subset` | 1 | ⏭️ SKIPPED — subSet is optional for this arm and is absent from the metadata |
| `section-3-denominator` | 1 | ❌ FAIL |

### Failures

- **`section_1_by_variable_by_variable_matches_requirement`** — Expected "TRT01AN" to equal "TRT01PN". ('test-armada-dv_t01.R')
- **`section_1_denominator_denominator_matches_requirement`** — Expected "analysis-set-safety-counts" to equal "analysis-set-enrolled-counts". ('test-armada-dv_t01.R')
- **`section_2_by_variable_by_variable_matches_requirement`** — Expected "TRT01AN" to equal "TRT01PN". ('test-armada-dv_t01.R')
- **`section_2_denominator_denominator_matches_requirement`** — Expected "analysis-set-safety-counts" to equal "analysis-set-enrolled-counts". ('test-armada-dv_t01.R')
- **`section_3_by_variable_by_variable_matches_requirement`** — Expected "TRT01AN" to equal "TRT01PN". ('test-armada-dv_t01.R')
- **`section_3_denominator_denominator_matches_requirement`** — Expected "analysis-set-safety-counts" to equal "analysis-set-enrolled-counts". ('test-armada-dv_t01.R')


---

## 4. EXECUTION VERIFICATION: Operational Evidence

**Execution Date:** 2026-08-18T09:15:44
**Total Duration:** 24.4 seconds
**Overall Status:** ✅ SUCCESS

### Phase Summary

- **arm_conversion:** ✅ (1.7s)
- **arm_execution:** ✅ (13.7s)
- **aom_conversion:** ✅ (0.8s)
- **aom_execution:** ✅ (8.2s)

### Discovery Results

**ARM Files Discovered:** 4
**ARM Files Converted:** 4
**AOM Files Converted:** 1

### Execution Results

**LEDs Executed:** 5
- ✅ analysis-set-enrolled-counts
- ✅ dv-any-count
- ✅ dv-by-acat-count
- ✅ dv-by-acat-adecod-count
- ✅ dv_t01_sum_impo_prot_dev_armada


---

## 5. ENVIRONMENT

**R Version:** R version 4.3.1 (2023-06-16)
**Platform:** x86_64-pc-linux-gnu (64-bit)
**Running:** Ubuntu 22.04.3 LTS
**Captured At:** 2026-08-18T09:15:03+0000

**Loaded packages:** 8

| Package | Version |
|---------|---------|
| `arrow` | 15.0.1 |
| `dplyr` | 1.1.4 |
| `jsonlite` | 1.8.8 |
| `metacore` | 0.1.3 |
| `rlang` | 1.1.3 |
| `testthat` | 3.2.1 |
| `tidyr` | 1.3.1 |
| `yaml` | 2.3.8 |


---

## 6. VALIDATION CRITERIA

❌ **VALIDATION CRITERIA NOT MET**

| Criterion | Met | Detail |
|---|---|---|
| Evidence complete | ✅ | All expected stage artifacts present in the run directory |
| Tests executed | ✅ | 19 test(s) recorded |
| All tests passed | ❌ | 6 test(s) failed: section_1_by_variable_by_variable_matches_requirement, section_1_denominator_denominator_matches_requirement, section_2_by_variable_by_variable_matches_requirement, section_2_denominator_denominator_matches_requirement, section_3_by_variable_by_variable_matches_requirement … |
| Skips justified | ✅ | 1 skip(s), all with a stated reason |
| Requirement coverage | ❌ | 1 of 20 requirement(s) have no test: output-footnotes |
| Execution succeeded | ✅ | Status 'success', no failed commands |
| Working tree clean | ✅ | No uncommitted changes at validation time |

### Criteria not met

- **All tests passed** — 6 test(s) failed: section_1_by_variable_by_variable_matches_requirement, section_1_denominator_denominator_matches_requirement, section_2_by_variable_by_variable_matches_requirement, section_2_denominator_denominator_matches_requirement, section_3_by_variable_by_variable_matches_requirement …
- **Requirement coverage** — 1 of 20 requirement(s) have no test: output-footnotes

### Interpretation

One or more criteria are not met for TFL `dv_t01_sum_impo_prot_dev_armada`. The specifics are listed above. This run does not demonstrate that the metadata satisfies its specification.

**This report states findings only. It does not certify fitness for regulatory submission — that determination rests with the responsible reviewer, recorded outside this document.**

**Verdict:** FAIL
**Report Generated:** 2026-08-18T09:15:44
