# Validation Report Template

**This file is the contract for the Stage 7 validation report.** It defines the sections, their order, their sources and their rules. Any producer of a validation report — the `unified_report_generator.py` script, an agentic skill, or a human writing one by hand — must produce this structure and nothing else.

`unified_report_generator.py` is the reference implementation. **If the script and this template disagree, that is a defect in one of them, not licence to improvise.** Reconcile them before generating a report you intend to rely on.

See [`example-validation-report.md`](example-validation-report.md) for a conforming report rendered from a synthetic DV_T01 run — failing tests, a justified skip, an untested requirement, and a computed FAIL verdict.

---

## Rules that apply to the whole report

These are not stylistic preferences. Each one exists because its absence has previously produced a misleading document.

1. **Six sections, in this order, with these exact headings.** Do not add, remove, reorder or rename them. A reviewer comparing two reports must be able to find the same thing in the same place.
2. **Every fact comes from a run-directory artifact.** Nothing is inferred, remembered from an earlier run, or supplied by the producer. If an artifact is absent, say so — do not fill the gap.
3. **Never assert fitness for regulatory submission.** The report states findings. The fitness determination is a human one, recorded outside this document. This applies to every section, not only §6.
4. **The verdict is computed, never asserted.** §6 evaluates seven criteria against the loaded evidence. A report may not claim an outcome its own evidence does not support.
5. **Missing evidence is `INCOMPLETE`, not `FAIL`.** "The evidence shows a problem" and "the evidence is absent" have different remedies. Collapsing them lets a half-run pipeline read as a substantive failure.
6. **Status words must match their symbol.** Never `❌ PASS`. If the symbol is ❌ the word is FAIL.
7. **No placeholder survives into a generated report.** Every `<angle-bracket>` token below is substituted or the surrounding line is omitted.

### Placeholder conventions used in this template

| Token | Meaning |
|---|---|
| `<value>` | Substitute from the named source artifact |
| `<!-- repeat -->` | Emit one row/bullet per item |
| `<!-- omit if ... -->` | Drop the whole block when the condition holds |

### Source artifacts

Every section draws from exactly one artifact in the run directory, except §6 which draws from all of them.

| § | Section | Source |
|---|---|---|
| 1 | Commit Information | `git_metadata.json` |
| 2 | Requirements Summary | `requirements.json` |
| 3 | Traceability Matrix | `junit/*.xml` + `requirements.json` |
| 4 | Execution Verification | `execution.json` |
| 5 | Environment | `environment.json` |
| 6 | Validation Criteria | all of the above |

When a source is missing, the section renders its **absence line** (given in each section below) and the artifact is recorded in the header banner. It does not render an empty table or an optimistic default.

---

## The template

Everything from here to the end of this file is the report structure.

---

# ARMADA Validation Report: Complete Pipeline Evidence

This document consolidates all validation and execution evidence for regulatory submission.

**Run directory:** `<absolute path to the run directory>`
**Report generated:** `<ISO 8601 timestamp>`

<!-- omit the entire block below if no artifact is missing -->
> **⚠ INCOMPLETE — expected inputs were not found in the run directory:**
>
> - `<label>` (expected `<path>`)   <!-- repeat per missing artifact -->
>
> Sections below that depend on these inputs are empty. This report is not complete evidence until every stage has run against this run directory.

---

## 1. COMMIT INFORMATION

**Source:** `git_metadata.json` (Stage 6)
**Answers:** which version of the metadata was validated?

**Absence line:** `No git metadata available — stage 6 did not write to this run directory.`

**Commit Hash:** `<commit_hash>`
**Author:** `<author_name>` (`<author_email>`)
**Date:** `<commit_date>`
**Repository:** `<repository_root>`
**Branch:** `<branch>`
**Validated At:** `<validation_timestamp>`

<!-- exactly one of the following two lines, driven by has_uncommitted_changes -->
**Working tree:** clean ✅

**⚠ UNCOMMITTED CHANGES AT VALIDATION TIME — `<n>` file(s).** The commit hash above does not describe what was validated. This run is not reproducible and must not be used for submission.

**Related TFL:** `<schema_title from requirements.json>`
**Output ID:** `<output_id>`

> Accept both key spellings: `author_name`/`author`, `commit_date`/`date`, `repository_root`/`repository`. Render `N/A` for any field genuinely absent — never invent one.

---

## 2. REQUIREMENTS SUMMARY

**Source:** `requirements.json` (Stage 1)
**Answers:** what had to be true?

**Absence line:** `No requirements data available.`

**Total Requirements:** `<count>`
**Grouped by:** `<n>` sections

### Overview by Type

| Type | Count | Description |
|------|-------|-------------|
| `<type>` | `<count>` | `<description>` |   <!-- repeat per requirement type -->

> A total of 0 is a finding, not an empty section. Stage 1 fails silently on a card it cannot parse, so 0 requirements means the pipeline validated nothing — §6's coverage criterion will catch it.

---

## 3. TRACEABILITY MATRIX: Validation Evidence

**Source:** every `junit/*.xml` (Stage 4), matched against `requirements.json`
**Answers:** what was tested, and did it pass?

**Absence line:** `No test results available.`

**Test Framework:** testthat (R)
**Overall Result:** `<✅ PASS | ❌ FAIL>` — `<passed>`/`<total>` passed (`<pct>`%)

### Test Outcomes

| Metric | Value |
|--------|-------|
| Tests executed | `<total>` |
| Passed | `<passed>` |
| Failed | `<failed>` |
| Skipped | `<skipped>` |

### Requirement Coverage

**`<covered>`/`<total>` requirement(s) exercised by at least one test.**

| Requirement | Tests | Result |
|---|---|---|
| `<requirement id>` | `<n>` | `<result>` |   <!-- repeat per requirement, in requirements.json order -->

Permitted values for Result, in precedence order:

| Result | When |
|---|---|
| `❌ NO TEST` | No test matched this requirement |
| `❌ FAIL` | Any matching test failed or errored |
| `⏭️ SKIPPED — <reasons>` | All matching tests skipped; reasons joined with `; ` |
| `✅ PASS` | Otherwise |

<!-- omit when no assertion carries evidence properties (stock testthat output) -->
### Assertion Detail

One row per assertion, from the enriched JUnit properties (Stage 4). This is what makes a PASS auditable: without `Expected`/`Actual` a green row says only that a test ran, not that it compared the right things.

| Test ID | Requirement | Comparison | Expected | Actual | Metadata UUID | Path | Result |
|---|---|---|---|---|---|---|---|
| `<test id>` | `<requirement id>` | `<comparison>` | `<expected>` | `<actual>` | `<uuid>` | `<path>` | `<✅ \| ❌ \| ⏭️>` |

**`Comparison` is mandatory and states how `Expected` relates to `Actual`.** Only `equals` means the two should be identical, so it must be rendered — a table that omits it invites the reader to apply equality to every row and read a passing membership assertion as a contradiction.

| Comparison | `assertion` token | Passes when | `Actual` holds |
|---|---|---|---|
| `equals` | `equal` | `Actual` is exactly `Expected` | the value found |
| `matches` | `match` | `Actual` satisfies the pattern in `Expected` | the value found |
| `is one of` | `member` | `Expected` is present in `Actual` | the **set searched**, not a single value |
| `—` | absent | — | comparison not recorded; do not guess it |

<!-- omit if every assertion carried evidence properties -->
*`<n>` assertion(s) carried no evidence properties and are omitted from this table — they appear in the coverage table above.*

<!-- omit if every test traced to a requirement -->
**`<n>` test(s) could not be traced to a requirement.** Stage 3 names each test with its requirement ID as a prefix; these do not match any ID in the requirements file:

- `<test name>` (`<source xml>`)   <!-- repeat, cap at 10 -->

<!-- omit if no failures -->
### Failures

- **`<test id, or test name where the reporter emitted no id>`** — `<first line of the failure message>`   <!-- repeat per failure -->
  <!-- both sub-bullets omitted when the assertion carried no evidence properties -->
  - Requirement: `<requirement id>` (expected `<comparison>` actual) · Expected `<expected>` · Actual `<actual>`
  - Metadata: `<uuid>` via `<path>`

The relation is named here for the same reason as in the assertion table: "Expected X · Actual Y" alone reads as an equality claim whatever the assertion actually was.

> **Matching rule.** testthat rewrites the `test_that()` description into the JUnit `name` attribute, collapsing runs of non-alphanumeric characters into single underscores — `section-1-domain: passes` becomes `section_1_domain_passes`. Normalise **both** the requirement ID and the test name the same way (lowercase, `[^a-z0-9]+` → `_`, trim underscores), then match when the normalised test name equals the requirement ID or continues it after an underscore. The boundary check prevents `output-title` claiming `output-titles`' tests. Matching literally finds nothing and reports every requirement as untested.

---

## 4. EXECUTION VERIFICATION: Operational Evidence

**Source:** `execution.json` (Stage 5)
**Answers:** did the metadata actually run?

**Absence line:** `No execution results available.`

**Execution Date:** `<ISO 8601 timestamp>`
**Total Duration:** `<seconds>` seconds
**Overall Status:** `<✅ SUCCESS | ❌ FAILED>`

### Phase Summary

- **`<phase name>`:** `<✅|❌>` (`<duration>`s)   <!-- repeat per phase, in execution order -->

### Discovery Results

**ARM Files Discovered:** `<n>`
**ARM Files Converted:** `<n>`
**AOM Files Converted:** `<0|1>`

### Execution Results

**LEDs Executed:** `<n>`
- ✅ `<led name>`   <!-- repeat -->

> Phases are reported in the order the executor runs them: ARM conversion → ARM execution → AOM conversion → AOM execution. Do not reorder to match the phase-number labels in the log.

---

## 5. ENVIRONMENT

**Source:** `environment.json` (Stage 6)
**Answers:** what was it run with?

**Absence line:** `No environment capture available — stage 6 did not write to this run directory.`

**R Version:** `<r_version>`
**Platform:** `<platform>`
**Running:** `<running>`
**Captured At:** `<captured_at>`

**Loaded packages:** `<count>`

| Package | Version |
|---------|---------|
| `<package>` | `<version>` |   <!-- repeat, sorted case-insensitively by name -->

> Omit any of the four labelled lines whose value is absent, rather than rendering `N/A`.

---

## 6. VALIDATION CRITERIA

**Source:** all sections above
**Answers:** which criteria are met?

<!-- exactly one headline, determined by the rules below -->
✅ **ALL VALIDATION CRITERIA MET**
❌ **VALIDATION CRITERIA NOT MET**
⚠️ **EVIDENCE INCOMPLETE — CRITERIA COULD NOT BE ASSESSED**

| Criterion | Met | Detail |
|---|---|---|
| Evidence complete | `<✅❌⚠️>` | `<detail>` |
| Tests executed | `<✅❌⚠️>` | `<detail>` |
| All tests passed | `<✅❌⚠️>` | `<detail>` |
| Skips justified | `<✅❌⚠️>` | `<detail>` |
| Requirement coverage | `<✅❌⚠️>` | `<detail>` |
| Execution succeeded | `<✅❌⚠️>` | `<detail>` |
| Working tree clean | `<✅❌⚠️>` | `<detail>` |

<!-- omit if none -->
### Criteria not met

- **`<criterion>`** — `<detail>`   <!-- repeat -->

<!-- omit if none -->
### Criteria that could not be assessed

- **`<criterion>`** — `<detail>`   <!-- repeat -->

### Interpretation

`<one paragraph, selected by verdict — see below>`

**This report states findings only. It does not certify fitness for regulatory submission — that determination rests with the responsible reviewer, recorded outside this document.**

**Verdict:** `<PASS | FAIL | INCOMPLETE>`
**Report Generated:** `<ISO 8601 timestamp>`

### The seven criteria

Each is `✅` met, `❌` not met, or `⚠️` could not be assessed. The Detail column always states the reasoning, including when met.

| # | Criterion | Met when | ⚠️ when |
|---|---|---|---|
| 1 | Evidence complete | Every stage wrote its artifact to the run directory | — |
| 2 | Tests executed | At least one test ran. An empty suite is **not** a pass | — |
| 3 | All tests passed | No failures or errors | — |
| 4 | Skips justified | Every skipped test carries a stated reason | — |
| 5 | Requirement coverage | Every requirement has ≥1 matching test | No requirements loaded |
| 6 | Execution succeeded | Status `success` **and** `failed_commands` empty | No execution results |
| 7 | Working tree clean | `has_uncommitted_changes` is false | Absent or unrecorded |

Criterion 5 counts a requirement as covered when a test **exists** for it, whatever the outcome. A failing test still counts as coverage; it fails criterion 3 instead. The two concerns are kept separate deliberately.

### Determining the verdict

Evaluate in this order — the first match wins:

| Order | Condition | Verdict |
|---|---|---|
| 1 | Any artifact missing, **or** any criterion `⚠️` | `INCOMPLETE` |
| 2 | Any criterion `❌` | `FAIL` |
| 3 | Otherwise | `PASS` |

`INCOMPLETE` deliberately outranks `FAIL`: with evidence missing, no determination is possible, and reporting FAIL would assert a conclusion the report cannot support.

### Interpretation paragraph

One paragraph, matching the verdict:

| Verdict | Text |
|---|---|
| `PASS` | Every criterion above is met for TFL `<output_id>`: the requirements were extracted, each is exercised by at least one test, all tests passed, the metadata converted and executed, and the repository was clean at validation time. |
| `FAIL` | One or more criteria are not met for TFL `<output_id>`. The specifics are listed above. This run does not demonstrate that the metadata satisfies its specification. |
| `INCOMPLETE` | The evidence gathered for TFL `<output_id>` is insufficient to assess every criterion. Run the missing stages against this run directory and regenerate this report. |

### Exit code

A producer that runs as a program must exit with the code matching its verdict, so the report can gate a pipeline:

| Verdict | Exit |
|---|---|
| `PASS` | 0 |
| `FAIL` | 1 |
| `INCOMPLETE` | 3 |
| Usage error (run directory missing or not given) | 2 |

---

## Conformance checklist

Check a report against this before relying on it:

- [ ] Six sections, correct order, exact headings
- [ ] Header carries run directory and generation timestamp
- [ ] Incomplete-evidence banner present if and only if an artifact is missing
- [ ] No `<placeholder>` tokens remain
- [ ] Every status word agrees with its symbol — no `❌ PASS`
- [ ] §3 lists every requirement from `requirements.json`, in file order
- [ ] §6 shows all seven criteria, each with reasoning in the Detail column
- [ ] Verdict follows the precedence rules, not the producer's impression
- [ ] The findings-only statement is present and unaltered
- [ ] Nowhere does the report assert fitness for regulatory submission
