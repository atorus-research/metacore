# TFL Specification Template

The shape Stage 1 expects in an ADO card. Copy this into the card body and fill it in.

> **Two parser constraints — get these wrong and Stage 1 silently produces zero requirements:**
>
> 1. Section headings **must** use an em-dash: `Section 1 — Title`. A hyphen or en-dash will not match.
> 2. Field names inside a section must be exactly one of the recognised keys listed below. Anything else is dropped without warning.
>
> Recognised keys: `Display label`, `Method`, `By Variable`, `Domain`, `Subset`, `Denominator`, `Title`, `Rationale`, `Footnote`, `Analysis set`.
>
> Always run Stage 1's acceptance checks against the card before proceeding.

---

**Table/Figure/Listing ID:** [Fill in]
**Study:** [Fill in]
**Date Created:** [Fill in]
**Mockshell:** [Link or attachment reference]

---

## Display

| Field | Value |
|-------|-------|
| ID | [e.g. DV_T01] |
| Title | [Displayed above the output] |
| Type | [Table / Listing / Figure] |
| Study Design | [e.g. Parallel] |

---

## Analysis Set

**Analysis Set Name:** [e.g. Enrolled]

**Population Filter:** [e.g. ENRLFL EQ "Y"]

---

## Treatment

**Treatment Variable:** [e.g. TRT01PN/TRT01P]

**Treatment Columns:**
- [Column 1]
- [Column 2]

**Include Total Column:** [true / false]

**Include No-Treatment Column:** [true / false]

---

## Column Structure

### Stub Columns (Row Labels)
- [Label, and the variable it derives from]

### Result Columns (Data)
- [Column, and the statistics shown]

**Big N Source:** [e.g. analysis-set-enrolled-counts]

---

## Footnotes

[One per line, or "No footnotes defined". Footnotes become an output-level requirement; if there are none, state so explicitly so the requirement asserts their absence.]

---

## Sections

One block per section of the output. Numbering must be contiguous from 1 and must match the number of `section_aom` entities in the metadata — Stage 2's acceptance check compares them.

### Section 1 — [Title]

| Field | Value |
|-------|-------|
| Display label | [Literal text, or a `<template>` placeholder — see note below] |
| Method | [The statistic, precisely enough to assert on] |
| By Variable | [e.g. TRT01PN/NA/TRT01P (Full Matrix: Yes)] |
| Domain | [e.g. ADDV] |
| Subset | [e.g. ADIMPTFL EQ "Y"] |
| Denominator | [e.g. Big N (analysis-set-enrolled-counts)] |

### Section 2 — [Title]

| Field | Value |
|-------|-------|
| Display label | |
| Method | |
| By Variable | |
| Domain | |
| Subset | |
| Denominator | |

> **Display label** takes one of three forms, and the form determines how it is validated:
>
> - **Literal text** — `Any Important Protocol Deviations`. Asserted by exact match.
> - **A standard format label** — `n (%)`, `n (Range)`. Resolved through the report format definition.
> - **A runtime template** — `<category name>`, `<coded term>`. Asserted by checking the label links to the right variable group, not by text match. Use angle brackets so Stage 3 recognises it.
>
> See `skills/03-generate-tests.md` for the full pattern rules.

> **Method** must be specific enough to test. "Counts subjects" is not assertable; "Number of distinct subjects (USUBJID) with at least one important protocol deviation, and percentage" is.

---

## Data Handling

**Missing Values:** [How missing categories are represented]

**Sort Order:** [e.g. Descending by total incidence, then alphabetical]

**Subject Counting:** [e.g. Counted once per category regardless of multiplicity]

---

## Known Issues

Discrepancies between this specification and the mockshell, and anything deferred. Each should be resolved or explicitly accepted before the validation summary is finalised.

- [ ] [Issue]
