# DV_T01 — Summary of Important Protocol Deviations

The same specification as `metadata requirements.txt`, written in the
machine-readable format defined by `tfl-requirement-schema.yaml`.

**Fenced blocks are what Stage 1 reads. Prose is for people and is never
parsed** — it travels through as the requirement's description, so write as much
of it as you like.

Lint before running the pipeline:

```
python .github/scripts/armada_lint_card.py templates/example-dv_t01-card.md
```

---

## Display

```yaml
requirement: title
text: Summary of Important Protocol Deviations
rationale: The title is as written in the mock shell, with no option to select.
```

The title is fixed by the mock shell. Note the conflict recorded at the foot of
this card: the analysis set arguably belongs in the title, which would change
this value.

```yaml
context: study_design
text: Parallel
```

---

## Footnotes

```yaml
requirement: footnotes
items: []
```

No footnotes are defined in the mock shell for this display. The empty list is
deliberate — it makes their absence something the pipeline asserts rather than
assumes.

---

## Analysis Set

```yaml
requirement: analysis_set
name: Enrolled
filter: ENRLFL EQ "Y"
```

---

## Treatment

```yaml
requirement: treatment
variables: TRT01PN/NA/TRT01P
codelist_full_matrix: true
columns: [Treatment A, Treatment B]
codes: [1, 2]
include_total: false
include_no_treatment: false
rationale: >
  Display principle 400 — in parallel studies with more than one treatment
  group, a total column is not included unless specifically deemed appropriate.
  The mock shell's developer note restricts Total to crossover studies. The
  No Treatment column is optional and is omitted by default, since not all
  studies encounter an untreated subject with an important protocol deviation.
```

Planned treatment, not actual. The codelist items follow the values displayed,
with numeric codes aligned to the order of the treatment columns.

---

## Columns

```yaml
requirement: column
stub_columns: 2
result_columns: 2
stub_indents: [0, 1]
```

As displayed in the PNG: two stub columns, the second indented, and one result
column per treatment subset.

```yaml
requirement: big_n
source: analysis-set-enrolled-counts
placement: column_header
```

The analysis-set-enrolled-counts row provides the treatment N (Big N)
denominator. It is displayed in the column headers, **not** as a body section —
which is why this table has three sections rather than four.

---

## Sorting

```yaml
requirement: sorting_order
sort_by: total incidence
direction: descending
tie_break: alphabetical
```

Deviation categories sort by descending total incidence; coded terms sort the
same way within each category. Equal incidence falls back to alphabetical.

---

## Sections

### Section 1 — Any Important Protocol Deviations

```yaml
requirement: display_label
form: literal
value: Any Important Protocol Deviations
```

```yaml
requirement: method
description: Number of distinct subjects (USUBJID) with at least one important protocol deviation, and percentage
statistic: COUNT_DISTINCT
```

A subject is counted once regardless of how many deviations they have.

```yaml
requirement: by_variable
variables:
  - {variable: TRT01PN/NA/TRT01P, full_matrix: true}
```

```yaml
requirement: domain
value: ADDV
```

```yaml
requirement: subset
value: ADIMPTFL EQ "Y"
```

```yaml
requirement: denominator
value: analysis-set-enrolled-counts
```

### Section 2 — By Category

```yaml
requirement: display_label
form: template
value: ACAT1
```

One row per observed deviation category, e.g. "NOT WITHDRAWN AFTER DEVELOPING
WITHDRAWAL CRITERIA".

```yaml
requirement: method
description: Number of distinct subjects (USUBJID) with at least one deviation in the category, and percentage
statistic: COUNT_DISTINCT
```

```yaml
requirement: by_variable
variables:
  - {variable: TRT01PN/NA/TRT01P, full_matrix: true}
  - {variable: NA/NA/ACAT1, full_matrix: false}
```

Full matrix is false for ACAT1, so only observed categories appear.

```yaml
requirement: domain
value: ADDV
```

```yaml
requirement: subset
value: ADIMPTFL EQ "Y"
```

```yaml
requirement: denominator
value: analysis-set-enrolled-counts
```

### Section 3 — By Category and Coded Term

```yaml
requirement: display_label
form: template
value: ADECOD
```

One row per observed coded term, indented under its category, e.g. "NOT
DISCONTINUED FROM STUDY TREATMENT".

```yaml
requirement: method
description: Number of distinct subjects (USUBJID) with at least one deviation matching the category and coded term, and percentage
statistic: COUNT_DISTINCT
```

```yaml
requirement: by_variable
variables:
  - {variable: TRT01PN/NA/TRT01P, full_matrix: true}
  - {variable: NA/NA/ACAT1, full_matrix: false}
  - {variable: NA/NA/ADECOD, full_matrix: false}
```

```yaml
requirement: domain
value: ADDV
```

```yaml
requirement: subset
value: ADIMPTFL EQ "Y"
```

```yaml
requirement: denominator
value: analysis-set-enrolled-counts
```

---

## Data handling

```yaml
context: missing
text: >
  Important protocol deviations should have been coded and categorised prior to
  analysis, so missing coded terms in ADDV are unexpected. If any are
  encountered, a ".missing" row is displayed with count and percentage to alert
  the reviewer.
```

---

## Known issues

```yaml
context: known_conflicts
text: >
  1. The column header should be two lines, with Coded Term indented, rather
     than Category/Coded Term.
  2. The first row reads "Any important protocol deviations" and should be
     "Any Important Protocol Deviations".
  3. The analysis set should be included in the title — which conflicts with
     the title stated above on this same card. Resolve before finalising.
```

---

## Mock shell

```yaml
context: notes
text: Mock shell extracted from DSB, version 1.0.
```
