#!/usr/bin/env python3
"""
ARMADA LED Execution Orchestrator

Automates the conversion of ARMADA metadata (ARM and AOM) to Linked Executable
Definitions (LEDs) and executes them through Mercury Executor to generate
Analysis Result Datasets (ARDs) and PDF outputs.

Usage:
    python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada --run-dir /path/to/run
    python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada --run-dir /path/to/run --dry-run true

Writes <run-dir>/execution.json and <run-dir>/execution.log. The run directory is
the shared area every pipeline stage reads and writes; stage 7 reads
execution.json from it to build the validation summary.

Author: Copilot
Version: 1.0
"""

import sys
import os
import json
import argparse
import subprocess
import time
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime
import re
import yaml

# ============================================================================
# Logging Setup
# ============================================================================

def setup_logger(name: str, log_file: Optional[str] = None, verbose: bool = False) -> logging.Logger:
    """Configure logging to stdout and optional file."""
    logger = logging.getLogger(name)
    level = logging.DEBUG if verbose else logging.INFO
    logger.setLevel(level)
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_format = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    console_handler.setFormatter(console_format)
    logger.addHandler(console_handler)
    
    # File handler (if specified)
    if log_file:
        os.makedirs(os.path.dirname(log_file) or '.', exist_ok=True)
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(level)
        file_format = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_format)
        logger.addHandler(file_handler)
    
    return logger


# ============================================================================
# Data Classes
# ============================================================================

@dataclass
class ExecutionPhaseResult:
    """Result of a single execution phase."""
    status: str          # 'success', 'failed', 'skipped'
    duration: float      # seconds
    message: str = ""
    items_processed: int = 0
    items_failed: int = 0
    details: Dict = None
    
    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        result = asdict(self)
        if self.details is None:
            result['details'] = {}
        return result


@dataclass
class ExecutionResult:
    """Result of complete execution pipeline."""
    status: str                    # 'success', 'failed'
    output_id: str
    total_duration: float
    
    # Details
    arms_discovered: int = 0
    arms_converted: List[str] = None
    aom_converted: str = ""
    leds_created: List[str] = None
    leds_executed: List[str] = None
    failed_commands: List[str] = None
    
    # Phase results
    phases: Dict[str, ExecutionPhaseResult] = None
    
    def __post_init__(self):
        if self.arms_converted is None:
            self.arms_converted = []
        if self.leds_created is None:
            self.leds_created = []
        if self.leds_executed is None:
            self.leds_executed = []
        if self.failed_commands is None:
            self.failed_commands = []
        if self.phases is None:
            self.phases = {}
    
    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            'status': self.status,
            'output_id': self.output_id,
            'total_duration': self.total_duration,
            'arms_discovered': self.arms_discovered,
            'arms_converted': self.arms_converted,
            'aom_converted': self.aom_converted,
            'leds_created': self.leds_created,
            'leds_executed': self.leds_executed,
            'failed_commands': self.failed_commands,
            'phases': {k: v.to_dict() if isinstance(v, ExecutionPhaseResult) else v 
                      for k, v in self.phases.items()},
        }


# ============================================================================
# ARMADA Executor
# ============================================================================

class ARMADAExecutor:
    """Orchestrates ARM/AOM conversion and LED execution."""
    
    def __init__(self,
                 output_id: str,
                 work_dir: str = "/mnt/code",
                 dry_run: bool = False,
                 verbose: bool = False,
                 log_file: Optional[str] = None,
                 stop_on_error: bool = True):
        """
        Initialize the executor.
        
        Args:
            output_id: Target AOM output ID (e.g., 'dv_t01_sum_impo_prot_dev_armada')
            work_dir: Root directory containing metadata and Makefile (default: /mnt/code)
            dry_run: If True, print commands without executing (default: False)
            verbose: If True, print detailed progress (default: False)
            log_file: Optional file path for log output (default: None)
            stop_on_error: If True, stop on first error (default: True)
        """
        self.output_id = output_id
        self.work_dir = Path(work_dir)
        self.dry_run = dry_run
        self.verbose = verbose
        self.stop_on_error = stop_on_error
        
        self.logger = setup_logger(__name__, log_file=log_file, verbose=verbose)
        
        # Verify work directory
        if not self.work_dir.exists():
            raise FileNotFoundError(f"Work directory not found: {self.work_dir}")
        
        # Metadata paths
        self.metadata_dir = self.work_dir / 'executor' / 'metadata'
        self.aom_dir = self.metadata_dir / 'main_aom'
        self.arm_dir = self.metadata_dir / 'arm'
        self.led_dir = self.metadata_dir / 'led'
        self.section_aom_dir = self.metadata_dir / 'section_aom'
        
        # Target AOM file
        self.aom_file = self.aom_dir / f"{output_id}.yaml"
        
        # Check if target AOM exists
        if not self.aom_file.exists():
            raise FileNotFoundError(f"Target AOM not found: {self.aom_file}")
        
        # Verify Makefile exists
        makefile = self.work_dir / 'Makefile'
        if not makefile.exists():
            raise FileNotFoundError(f"Makefile not found: {makefile}")
        
        # Check environment variables
        self._verify_env_vars()
        
        # State
        self.arms_discovered: List[str] = []
        self.arms_converted: List[str] = []
        self.aom_converted: Optional[str] = None
        self.leds_created: List[str] = []
        self.leds_executed: List[str] = []
        self.failed_commands: List[str] = []
    
    def _verify_env_vars(self) -> None:
        """Verify required environment variables are set."""
        required_vars = [
            'MERCURY_EXECUTOR_PATH',
            'LED_TOOLING_PATH',
            'MERCURY_METADATA_PATH',
            'DOMINO_PROJECT_NAME'
        ]
        
        missing = [var for var in required_vars if not os.environ.get(var)]
        if missing:
            self.logger.warning(f"Missing environment variables: {', '.join(missing)}")
            self.logger.info("These should be set in your Domino environment or .env file")
    
    def _run_command(self, cmd: List[str], cwd: Optional[Path] = None) -> Tuple[bool, str, str]:
        """
        Run a shell command and return success status and output.
        
        Args:
            cmd: Command as list of strings
            cwd: Working directory (default: self.work_dir)
        
        Returns:
            Tuple of (success, stdout, stderr)
        """
        if cwd is None:
            cwd = self.work_dir
        
        cmd_str = ' '.join(cmd)
        self.logger.debug(f"Running: {cmd_str}")
        
        if self.dry_run:
            self.logger.info(f"[DRY-RUN] {cmd_str}")
            return True, "", ""
        
        try:
            result = subprocess.run(
                cmd,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=300  # 5 minutes
            )
            
            if result.returncode == 0:
                self.logger.debug(f"✓ Command succeeded")
                return True, result.stdout, result.stderr
            else:
                self.logger.error(f"✗ Command failed with code {result.returncode}")
                self.logger.error(f"  stdout: {result.stdout[:200]}")
                self.logger.error(f"  stderr: {result.stderr[:200]}")
                return False, result.stdout, result.stderr
        
        except subprocess.TimeoutExpired:
            self.logger.error(f"✗ Command timed out after 300 seconds")
            return False, "", "Command timed out"
        except Exception as e:
            self.logger.error(f"✗ Command failed with exception: {e}")
            return False, "", str(e)
    
    def discover_arms(self) -> List[str]:
        """
        Discover ARM files linked to the target AOM by traversing section metadata.
        
        Collects ARMs from two sources:
        1. Section analyses: From section_aom 'analyses' field (for display sections)
        2. BigN Analysis: From main_aom 'bigNAnalysisID' field (for denominator dataset)
        
        Workflow:
        1. Load main_aom YAML
        2. Extract bigNAnalysisID if present (denominator dataset ARM)
        3. Extract section UUIDs from 'sections' field
        4. For each section UUID, load section_aom file
        5. Extract 'analyses' field to get ARM file name
        6. Return unique set of all ARM files
        
        Returns:
            List of ARM file names (without .yaml extension)
        """
        self.logger.info("=" * 80)
        self.logger.info("PHASE 1: Discover ARM Files Linked to Target AOM")
        self.logger.info("=" * 80)
        
        try:
            # Step 1: Load target AOM
            self.logger.info(f"Reading target AOM: {self.aom_file.name}")
            with open(self.aom_file, 'r') as f:
                aom_list = yaml.safe_load(f)
            
            if not isinstance(aom_list, list) or not aom_list:
                self.logger.error("Invalid AOM file format")
                return []
            
            aom_data = aom_list[0]  # AOM is a list with one element
            
            # Step 2: Collect ARMs from bigNAnalysisID (denominator dataset)
            arm_files = set()
            big_n_analysis = aom_data.get('bigNAnalysisID')
            if big_n_analysis:
                arm_files.add(big_n_analysis)
                self.logger.info(f"Found bigNAnalysisID (denominator): {big_n_analysis}")
            
            # Step 3: Extract section UUIDs
            sections_field = aom_data.get('sections', '')
            if not sections_field:
                self.logger.warning("No sections found in AOM")
                if not arm_files:
                    return []
                # Continue if we have bigNAnalysisID
            else:
                # Sections are separated by asterisks (*)
                section_uuids = [uuid.strip() for uuid in sections_field.split('*') if uuid.strip()]
                self.logger.info(f"Found {len(section_uuids)} section(s) in AOM")
                
                # Step 4 & 5: For each section, extract ARM file name
                for section_uuid in section_uuids:
                    section_file = self.section_aom_dir / f"{section_uuid}.yaml"
                    
                    if not section_file.exists():
                        self.logger.warning(f"Section file not found: {section_file}")
                        continue
                    
                    try:
                        with open(section_file, 'r') as f:
                            section_list = yaml.safe_load(f)
                        
                        if not isinstance(section_list, list) or not section_list:
                            self.logger.warning(f"Invalid section file format: {section_file}")
                            continue
                        
                        section_data = section_list[0]
                        analyses = section_data.get('analyses')
                        
                        if analyses:
                            arm_files.add(analyses)
                            self.logger.debug(f"Section {section_uuid[:8]}... → ARM: {analyses}")
                    
                    except Exception as e:
                        self.logger.warning(f"Failed to read section {section_uuid}: {e}")
                        continue
            
            if not arm_files:
                self.logger.warning("No ARM files discovered")
                return []
            
            # Step 6: Return sorted list
            arm_files_sorted = sorted(arm_files)
            self.arms_discovered = arm_files_sorted
            
            self.logger.info(f"✓ Discovered {len(arm_files_sorted)} ARM file(s) linked to target AOM:")
            for arm in arm_files_sorted:
                self.logger.info(f"  - {arm}")
            
            return arm_files_sorted
        
        except Exception as e:
            self.logger.error(f"✗ Discovery failed: {e}")
            import traceback
            self.logger.debug(traceback.format_exc())
            return []
    
    def convert_arms(self) -> ExecutionPhaseResult:
        """
        Convert all discovered ARM files to LEDs.
        
        Note: The arm2led.py tool is database-driven and requires analysisID to be
        in the LSDD database. It makes an API call to fetch and convert metadata.
        If the ID isn't found, the command fails but still exits with code 0 (bug in
        arm2led.py error handling). We check stderr for error indicators.
        
        Runs: make convert_1arm args='--analysisID <aom_name> --branch default'
        
        Returns:
            ExecutionPhaseResult with conversion details
        """
        self.logger.info("\n" + "=" * 80)
        self.logger.info("PHASE 2: Convert ARM → LED")
        self.logger.info("=" * 80)
        
        start_time = time.time()
        result = ExecutionPhaseResult(status='success', duration=0, details={})
        
        if not self.arms_discovered:
            self.logger.warning("No ARM files to convert")
            result.status = 'skipped'
            result.duration = time.time() - start_time
            return result
        
        converted = []
        failed = []
        failed_details = {}
        
        for arm in self.arms_discovered:
            self.logger.info(f"\nConverting ARM: {arm}")
            
            cmd = [
                'make', 'convert_1arm',
                f"args=--analysisID {arm} --branch default"
            ]
            
            success, stdout, stderr = self._run_command(cmd)
            
            # Check stderr for error indicators (arm2led.py has a bug where it exits 0 on error)
            has_error = 'Error raised during processing' in stderr or 'not found in database' in stderr
            
            if success and not has_error:
                self.logger.info(f"✓ Converted: {arm}")
                converted.append(arm)
                # Try to find created LED files
                led_pattern = f"adam_arm_{arm.replace('-', '_')}_*.yaml"
                created = list(self.led_dir.glob(led_pattern))
                self.leds_created.extend([f.stem for f in created])
            else:
                self.logger.error(f"✗ Failed to convert ARM: {arm}")
                if has_error:
                    # Extract first error line from stderr
                    error_lines = stderr.split('\n')
                    error_msg = next((line for line in error_lines if 'Error raised' in line or 'not found' in line), stderr[:200])
                    failed_details[arm] = {
                        'command': ' '.join(cmd),
                        'error': error_msg
                    }
                failed.append(arm)
                self.failed_commands.append(f"make convert_1arm args='--analysisID {arm} --branch default'")
                
                if self.stop_on_error:
                    result.status = 'failed'
                    result.duration = time.time() - start_time
                    result.items_processed = len(converted)
                    result.items_failed = len(failed)
                    result.details = failed_details
                    return result
        
        self.arms_converted = converted
        result.status = 'success' if not failed else 'partial'
        result.duration = time.time() - start_time
        result.items_processed = len(converted)
        result.items_failed = len(failed)
        result.details = failed_details
        
        self.logger.info(f"\n✓ ARM conversion complete: {len(converted)}/{len(self.arms_discovered)} succeeded")
        
        return result
    
    def convert_aom(self) -> ExecutionPhaseResult:
        """
        Convert the target AOM to LED.
        
        Note: The aom2led.py tool is database-driven and requires outputID to be
        in the LSDD database. It makes an API call to fetch and convert metadata.
        If the ID isn't found, the command fails but still exits with code 0 (bug in
        aom2led.py error handling). We check stderr for error indicators.
        
        Runs: make convert_1aom args='--outputID <aom_name> --branch default'
        
        Returns:
            ExecutionPhaseResult with conversion details
        """
        self.logger.info("\n" + "=" * 80)
        self.logger.info("PHASE 4: Convert AOM → LED")
        self.logger.info("=" * 80)
        
        start_time = time.time()
        result = ExecutionPhaseResult(status='success', duration=0, details={})
        
        self.logger.info(f"Converting AOM: {self.output_id}")
        
        cmd = [
            'make', 'convert_1aom',
            f"args=--outputID {self.output_id} --branch default"
        ]
        
        success, stdout, stderr = self._run_command(cmd)
        
        # Check stderr for error indicators (aom2led.py has a bug where it exits 0 on error)
        has_error = 'Error raised during processing' in stderr or 'No ARMs found' in stderr
        
        if success and not has_error:
            self.logger.info(f"✓ Converted: {self.output_id}")
            self.aom_converted = self.output_id
            # Try to find created LED file
            led_pattern = f"adam_aom_{self.output_id.replace('-', '_')}_*.yaml"
            created = list(self.led_dir.glob(led_pattern))
            self.leds_created.extend([f.stem for f in created])
            
            result.status = 'success'
            result.items_processed = 1
        else:
            self.logger.error(f"✗ Failed to convert AOM: {self.output_id}")
            if has_error:
                # Extract first error line from stderr
                error_lines = stderr.split('\n')
                error_msg = next((line for line in error_lines if 'Error raised' in line or 'No ARMs' in line), stderr[:200])
                result.details['command'] = ' '.join(cmd)
                result.details['error'] = error_msg
            result.status = 'failed'
            result.items_failed = 1
            self.failed_commands.append(f"make convert_1aom args='--outputID {self.output_id} --branch default'")
        
        result.duration = time.time() - start_time
        return result
    
    def execute_arms(self) -> ExecutionPhaseResult:
        """
        Execute all ARM LEDs (creates ARDs needed by AOM).
        
        For each ARM, run: make run args='--what <arm_name>'
        
        Returns:
            ExecutionPhaseResult with execution details
        """
        self.logger.info("\n" + "=" * 80)
        self.logger.info("PHASE 3: Execute ARM LEDs")
        self.logger.info("=" * 80)
        
        start_time = time.time()
        result = ExecutionPhaseResult(status='success', duration=0, details={})
        
        if not self.arms_converted:
            self.logger.warning("No ARM files to execute")
            result.status = 'skipped'
            result.duration = time.time() - start_time
            return result
        
        executed = []
        failed = []
        failed_details = {}
        
        for arm in self.arms_converted:
            self.logger.info(f"\nExecuting ARM: {arm}")
            
            arm_start = time.time()
            cmd = ['make', 'run', f"args=--what {arm}"]
            
            success, stdout, stderr = self._run_command(cmd)
            arm_duration = time.time() - arm_start
            
            if success:
                self.logger.info(f"✓ Executed: {arm} ({arm_duration:.1f}s)")
                executed.append(arm)
                self.leds_executed.append(arm)
            else:
                self.logger.error(f"✗ Failed to execute ARM: {arm}")
                failed.append(arm)
                failed_details[arm] = {
                    'command': ' '.join(cmd),
                    'error': stderr if stderr else stdout
                }
                self.failed_commands.append(f"make run args='--what {arm}'")
                
                if self.stop_on_error:
                    result.status = 'failed'
                    result.duration = time.time() - start_time
                    result.items_processed = len(executed)
                    result.items_failed = len(failed)
                    result.details = failed_details
                    return result
        
        result.status = 'success' if not failed else 'partial'
        result.duration = time.time() - start_time
        result.items_processed = len(executed)
        result.items_failed = len(failed)
        result.details = failed_details
        
        self.logger.info(f"\n✓ ARM execution complete: {len(executed)}/{len(self.arms_converted)} succeeded")
        
        return result
    
    def execute_aom(self) -> ExecutionPhaseResult:
        """
        Execute the AOM to create final table and PDF.
        
        Note: Mercury executor may exit with FileNotFoundError for PDF if there's a
        backend issue, but the PDF is usually created in the prod/output directory.
        We validate success by checking if the output file exists, not just exit code.
        
        Runs: make run args='--what <aom_name>'
        
        Returns:
            ExecutionPhaseResult with execution details
        """
        self.logger.info("\n" + "=" * 80)
        self.logger.info("PHASE 5: Execute AOM")
        self.logger.info("=" * 80)
        
        start_time = time.time()
        result = ExecutionPhaseResult(status='success', duration=0, details={})
        
        if not self.aom_converted:
            self.logger.warning("No AOM to execute")
            result.status = 'skipped'
            result.duration = time.time() - start_time
            return result
        
        self.logger.info(f"Executing AOM: {self.aom_converted}")
        
        cmd = ['make', 'run', f"args=--what {self.aom_converted}"]
        
        success, stdout, stderr = self._run_command(cmd)
        
        # Check if output file was created (ignoring spurious FileNotFoundError from mercury executor)
        # The PDF is created in prod/output/ by mercury executor even if it exits with an error
        output_patterns = [
            f"prod/output/{self.aom_converted}.pdf",
            f"output/{self.aom_converted}.pdf"
        ]
        
        output_found = False
        for pattern in output_patterns:
            # Search in /mnt/data subdirectories
            for path in Path('/mnt/data').rglob(f"{self.aom_converted}.pdf"):
                if pattern.split('/')[-1] in str(path):
                    output_found = True
                    self.logger.info(f"✓ Output file created: {path}")
                    break
            if output_found:
                break
        
        if success or output_found:
            self.logger.info(f"✓ Executed: {self.aom_converted}")
            self.leds_executed.append(self.aom_converted)
            result.status = 'success'
            result.items_processed = 1
            
            # Log warning if command failed but output exists
            if not success and output_found:
                self.logger.warning("Command exited with error but output file was created (backend issue)")
                result.details['note'] = "Output generated despite mercury executor error (false negative)"
        else:
            self.logger.error(f"✗ Failed to execute AOM: {self.aom_converted}")
            result.status = 'failed'
            result.items_failed = 1
            result.details['command'] = ' '.join(cmd)
            result.details['error'] = stderr if stderr else stdout
            self.failed_commands.append(f"make run args='--what {self.aom_converted}'")
        
        result.duration = time.time() - start_time
        return result
    
    def execute(self) -> ExecutionResult:
        """
        Execute the full pipeline (discovery → conversion → execution).
        
        Returns:
            ExecutionResult with complete details
        """
        self.logger.info("\n" + "=" * 80)
        self.logger.info(f"ARMADA LED Execution Pipeline")
        self.logger.info(f"Output ID: {self.output_id}")
        self.logger.info(f"Dry-run: {self.dry_run}")
        self.logger.info(f"Stop on error: {self.stop_on_error}")
        self.logger.info("=" * 80 + "\n")
        
        start_time = time.time()
        phases = {}
        
        # Phase 1: Discover
        self.discover_arms()
        
        # Phase 2: Convert ARMs
        phases['arm_conversion'] = self.convert_arms()
        
        # Phase 3: Execute ARMs (must complete before AOM conversion)
        phases['arm_execution'] = self.execute_arms()
        
        # Phase 4: Convert AOM (after ARM execution creates output datasets)
        phases['aom_conversion'] = self.convert_aom()
        
        # Phase 5: Execute AOM
        phases['aom_execution'] = self.execute_aom()
        
        total_duration = time.time() - start_time
        
        # Determine overall status
        overall_status = 'success' if not self.failed_commands else 'failed'
        
        # Log summary
        self.logger.info("\n" + "=" * 80)
        self.logger.info("EXECUTION SUMMARY")
        self.logger.info("=" * 80)
        self.logger.info(f"Status: {overall_status.upper()}")
        self.logger.info(f"Total Duration: {total_duration:.1f}s")
        self.logger.info(f"ARM files discovered: {len(self.arms_discovered)}")
        self.logger.info(f"ARM files converted: {len(self.arms_converted)}")
        self.logger.info(f"AOM files converted: {1 if self.aom_converted else 0}")
        self.logger.info(f"LEDs created: {len(self.leds_created)}")
        self.logger.info(f"LEDs executed: {len(self.leds_executed)}")
        
        if self.failed_commands:
            self.logger.error(f"Failed commands: {len(self.failed_commands)}")
            for cmd in self.failed_commands:
                self.logger.error(f"  - {cmd}")
        
        self.logger.info("=" * 80 + "\n")
        
        result = ExecutionResult(
            status=overall_status,
            output_id=self.output_id,
            total_duration=total_duration,
            arms_discovered=len(self.arms_discovered),
            arms_converted=self.arms_converted,
            aom_converted=self.aom_converted,
            leds_created=self.leds_created,
            leds_executed=self.leds_executed,
            failed_commands=self.failed_commands,
            phases=phases
        )
        
        return result


# ============================================================================
# Main Entry Point
# ============================================================================

def main():
    """Parse arguments and execute."""
    parser = argparse.ArgumentParser(
        description='ARMADA LED Execution Orchestrator',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic execution
  python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada \\
    --run-dir /mnt/code/validation_runs/dv_t01

  # Dry-run mode
  python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada \\
    --run-dir /mnt/code/validation_runs/dv_t01 --dry-run true

  # Verbose, with the log written somewhere other than the run directory
  python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada \\
    --run-dir /mnt/code/validation_runs/dv_t01 --verbose true --log-file /tmp/execution.log
        """
    )
    
    parser.add_argument(
        '--output-id',
        required=True,
        help='Target AOM output ID (e.g., dv_t01_sum_impo_prot_dev_armada)'
    )

    parser.add_argument(
        '--run-dir',
        required=True,
        help=('Shared validation run directory that every pipeline stage reads '
              'and writes. This stage writes <run-dir>/execution.json and, '
              'unless --log-file overrides it, <run-dir>/execution.log')
    )
    
    parser.add_argument(
        '--work-dir',
        default='/mnt/code',
        help='Root directory containing metadata and Makefile (default: /mnt/code)'
    )
    
    parser.add_argument(
        '--dry-run',
        choices=['true', 'false'],
        default='false',
        help='Print commands without executing (default: false)'
    )
    
    parser.add_argument(
        '--verbose',
        choices=['true', 'false'],
        default='false',
        help='Print detailed progress (default: false)'
    )
    
    parser.add_argument(
        '--log-file',
        default=None,
        help='Override the log path (default: <run-dir>/execution.log)'
    )
    
    parser.add_argument(
        '--stop-on-error',
        choices=['true', 'false'],
        default='true',
        help='Stop on first error (default: true)'
    )
    
    args = parser.parse_args()

    # Convert string booleans to actual booleans
    dry_run = args.dry_run.lower() == 'true'
    verbose = args.verbose.lower() == 'true'
    stop_on_error = args.stop_on_error.lower() == 'true'

    # Shared validation run directory. Every stage reads and writes here, and
    # stage 7 reads execution.json from it to build the summary.
    run_dir = os.path.abspath(args.run_dir)
    os.makedirs(run_dir, exist_ok=True)

    log_file = args.log_file or os.path.join(run_dir, 'execution.log')
    result_file = os.path.join(run_dir, 'execution.json')

    try:
        executor = ARMADAExecutor(
            output_id=args.output_id,
            work_dir=args.work_dir,
            dry_run=dry_run,
            verbose=verbose,
            log_file=log_file,
            stop_on_error=stop_on_error
        )

        result = executor.execute()

        # Output result as JSON for programmatic use
        result_json = json.dumps(result.to_dict(), indent=2)

        # Always persist the result, success or failure — a failed run is
        # evidence too, and stage 7 must be able to report on it.
        with open(result_file, 'w') as f:
            f.write(result_json)

        if result.status == 'success':
            print("\n" + result_json)
            executor.logger.info(f"Result saved to: {result_file}")

            # Generate unified validation report
            try:
                script_dir = os.path.dirname(os.path.abspath(__file__))
                report_gen_path = os.path.join(script_dir, 'unified_report_generator.py')
                if os.path.exists(report_gen_path):
                    subprocess.run(
                        [sys.executable, report_gen_path, args.output_id, '--run-dir', run_dir],
                        check=False
                    )
            except Exception as e:
                executor.logger.warning(f"Could not generate unified report: {e}")

            sys.exit(0)
        else:
            print("\n" + result_json, file=sys.stderr)
            executor.logger.error(f"Result saved to: {result_file}")
            sys.exit(1)

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
