#!/usr/bin/env python3
"""
Generate unified validation report from all 7 pipeline stages.

Every input is read from the shared validation run directory (--run-dir), the
same area each stage writes to:

    <run-dir>/requirements.json    Stage 1
    <run-dir>/metadata.json        Stage 2
    <run-dir>/junit/*.xml          Stage 4
    <run-dir>/execution.json       Stage 5
    <run-dir>/git_metadata.json    Stage 6
    <run-dir>/environment.json     Stage 6

Output: Single comprehensive markdown report for regulatory submission
"""

import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional


def normalise_id(text: str) -> str:
    """Collapse a requirement ID or test name to a comparable form.

    testthat's JunitReporter rewrites the test_that() description into the
    testcase @name attribute, replacing every run of non-alphanumeric
    characters with a single underscore:

        test_that("section-1-display_label: ...")  ->  section_1_display_label_...

    Requirement IDs use hyphens, so both sides must be normalised before they
    can be compared.
    """
    return re.sub(r'[^a-z0-9]+', '_', (text or '').lower()).strip('_')

class UnifiedReportGenerator:
    def __init__(self, output_id: str, run_dir: str):
        self.output_id = output_id
        self.run_dir = Path(run_dir)

        # Data holders
        self.requirements = {}
        self.metadata = {}
        self.test_results = {}
        self.git_metadata = {}
        self.environment = {}
        self.execution_results = {}

        # Records which expected inputs were absent, so the report can say so
        # rather than silently rendering an empty section.
        self.missing_inputs: List[str] = []

    def _load_json(self, name: str, label: str) -> Dict[str, Any]:
        """Load a JSON artifact from the run directory, recording it if absent."""
        path = self.run_dir / name
        if not path.exists():
            self.missing_inputs.append(f"{label} (expected {path})")
            return {}
        with open(path) as f:
            return json.load(f)

    def load_all_data(self):
        """Load data from all pipeline stages."""
        self.load_requirements()
        self.load_metadata()
        self.load_test_results()
        self.load_git_metadata()
        self.load_environment()
        self.load_execution_results()

    def load_requirements(self):
        """Stage 1 — <run-dir>/requirements.json"""
        self.requirements = self._load_json('requirements.json', 'Stage 1 requirements')

    def load_metadata(self):
        """Stage 2 — <run-dir>/metadata.json"""
        self.metadata = self._load_json('metadata.json', 'Stage 2 metadata')

    def load_test_results(self):
        """Stage 4 — every JUnit XML in <run-dir>/junit/

        run_tests.R writes one XML per test script, so results are aggregated
        across all of them.
        """
        junit_dir = self.run_dir / 'junit'
        xml_files = sorted(junit_dir.glob('*.xml')) if junit_dir.is_dir() else []

        if not xml_files:
            self.missing_inputs.append(f"Stage 4 JUnit XML (expected {junit_dir}/*.xml)")
            return

        self.test_results = {'total': 0, 'passed': 0, 'failed': 0, 'skipped': 0, 'tests': []}

        for xml_file in xml_files:
            try:
                root = ET.parse(xml_file).getroot()
            except ET.ParseError as e:
                self.missing_inputs.append(f"Stage 4 JUnit XML unreadable: {xml_file} ({e})")
                continue

            for testcase in root.findall('.//testcase'):
                failure_el = testcase.find('failure')
                error_el = testcase.find('error')
                skipped_el = testcase.find('skipped')

                failed = failure_el is not None or error_el is not None
                skipped = skipped_el is not None

                self.test_results['total'] += 1
                if skipped:
                    self.test_results['skipped'] += 1
                elif failed:
                    self.test_results['failed'] += 1
                else:
                    self.test_results['passed'] += 1

                # A skip must carry a justification. testthat puts skip()'s
                # reason in the message attribute; an empty one is unjustified.
                skip_reason = ''
                if skipped:
                    skip_reason = (skipped_el.get('message')
                                   or (skipped_el.text or '')).strip()

                detail = ''
                if failed:
                    el = failure_el if failure_el is not None else error_el
                    detail = (el.get('message') or (el.text or '')).strip()

                # Enriched output from ArmadaJunitReporter (stage 4). Stock
                # testthat emits neither, so both stay empty for un-enriched XML
                # and traceability falls back to name-prefix matching.
                props = {p.get('name'): p.get('value')
                         for p in testcase.findall('./properties/property')
                         if p.get('name')}

                name = testcase.get('name') or ''
                self.test_results['tests'].append({
                    'name': name,
                    'normalised': normalise_id(name),
                    'test_id': testcase.get('id') or '',
                    'requirement_id': props.get('requirement_id', ''),
                    'assertion': props.get('assertion', ''),
                    'expected': props.get('expected', ''),
                    'actual': props.get('actual', ''),
                    'metadata_uuid': props.get('metadata_uuid', ''),
                    'metadata_path': props.get('metadata_path', ''),
                    'classname': testcase.get('classname'),
                    'passed': not failed and not skipped,
                    'failed': failed,
                    'skipped': skipped,
                    'skip_reason': skip_reason,
                    'detail': detail,
                    'time': float(testcase.get('time', 0) or 0),
                    'source': xml_file.name
                })

    def load_git_metadata(self):
        """Stage 6 — <run-dir>/git_metadata.json"""
        self.git_metadata = self._load_json('git_metadata.json', 'Stage 6 git metadata')

    def load_environment(self):
        """Stage 6 — <run-dir>/environment.json"""
        self.environment = self._load_json('environment.json', 'Stage 6 environment capture')

    def load_execution_results(self):
        """Stage 5 — <run-dir>/execution.json"""
        self.execution_results = self._load_json('execution.json', 'Stage 5 execution results')
    
    # ------------------------------------------------------------------
    # Evidence evaluation
    # ------------------------------------------------------------------

    def all_requirements(self) -> List[Dict[str, Any]]:
        """Every requirement declared by stage 1, output-level and section-level.

        Stage 1 writes a pre-flattened 'requirements' list; fall back to walking
        the structure if it is absent. Both §2 and §3 must count the same set,
        or the report contradicts itself.
        """
        flat = [r for r in self.requirements.get('requirements', []) if r.get('id')]
        if flat:
            return flat
        flat = [r for r in self.requirements.get('output_requirements', []) if r.get('id')]
        for section in self.requirements.get('sections', []):
            flat += [r for r in section.get('requirements', []) if r.get('id')]
        return flat

    def requirement_ids(self) -> List[str]:
        """Every requirement ID declared by stage 1."""
        return [r['id'] for r in self.all_requirements()]

    @staticmethod
    def requirement_type(req: Dict[str, Any]) -> str:
        """The requirement's type, derived from its ID when not stated.

        Stage 1 does not currently emit a 'type' key, but its IDs encode one:
        'section-1-display_label' -> display_label, 'output-title' -> title.
        """
        stated = req.get('type')
        if stated:
            return stated
        rid = req.get('id', '')
        derived = re.sub(r'^section-\d+-', '', rid)
        derived = re.sub(r'^output-', '', derived)
        return derived or 'unknown'

    def coverage(self) -> Dict[str, List[Dict[str, Any]]]:
        """Map each requirement ID to the tests that exercise it.

        Two mechanisms, in order of reliability:

        1. The `requirement_id` property emitted by ArmadaJunitReporter. Exact,
           and independent of how testthat rewrites the test description.
        2. Name-prefix matching, for XML produced by the stock reporter. Stage 3
           names each test with its requirement ID as a prefix; both sides are
           normalised first (see normalise_id). A test matches when its
           normalised name equals the normalised requirement ID or continues it
           at an underscore boundary, which stops 'output-title' from claiming
           'output-titles' tests.

        A test carrying a requirement_id property is matched by that alone — it
        has stated its requirement, so guessing from its name could only
        contradict it.
        """
        tests = self.test_results.get('tests', [])
        declared = [t for t in tests if t.get('requirement_id')]
        undeclared = [t for t in tests if not t.get('requirement_id')]

        result = {}
        for req_id in self.requirement_ids():
            key = normalise_id(req_id)
            matched = [t for t in declared if t['requirement_id'] == req_id]
            matched += [
                t for t in undeclared
                if t['normalised'] == key or t['normalised'].startswith(key + '_')
            ]
            result[req_id] = matched
        return result

    def evaluate(self) -> Dict[str, Any]:
        """Derive the verdict from the evidence.

        Returns a status of PASS, FAIL or INCOMPLETE plus the criteria that
        produced it. INCOMPLETE is distinct from FAIL: it means the evidence
        needed to judge is absent, not that the evidence shows a problem.
        """
        criteria: List[Dict[str, Any]] = []

        def add(name: str, met: Optional[bool], detail: str):
            criteria.append({'name': name, 'met': met, 'detail': detail})

        # 1 — Evidence complete
        complete = not self.missing_inputs
        add('Evidence complete', complete,
            'All expected stage artifacts present in the run directory' if complete
            else f"{len(self.missing_inputs)} expected input(s) missing: "
                 + '; '.join(self.missing_inputs))

        tests = self.test_results.get('tests', [])
        total = self.test_results.get('total', 0)

        # 2 — Tests were actually executed
        add('Tests executed', total > 0,
            f'{total} test(s) recorded' if total > 0
            else 'No tests recorded — an empty suite is not a pass')

        # 3 — No failures
        failed = [t for t in tests if t['failed']]
        add('All tests passed', not failed,
            'No failures or errors' if not failed
            else f"{len(failed)} test(s) failed: "
                 + ', '.join(t['name'] for t in failed[:5])
                 + (' …' if len(failed) > 5 else ''))

        # 4 — Skips are permitted, but each must carry a justification
        skipped = [t for t in tests if t['skipped']]
        unjustified = [t for t in skipped if not t['skip_reason']]
        add('Skips justified', not unjustified,
            (f'{len(skipped)} skip(s), all with a stated reason' if skipped
             else 'No skipped tests') if not unjustified
            else f"{len(unjustified)} skip(s) with no stated reason: "
                 + ', '.join(t['name'] for t in unjustified[:5]))

        # 5 — Every requirement exercised by at least one test
        req_ids = self.requirement_ids()
        if not req_ids:
            add('Requirement coverage', None,
                'No requirements available — cannot assess coverage')
        else:
            cov = self.coverage()
            untested = [rid for rid, ts in cov.items() if not ts]
            add('Requirement coverage', not untested,
                f'All {len(req_ids)} requirement(s) have at least one test' if not untested
                else f"{len(untested)} of {len(req_ids)} requirement(s) have no test: "
                     + ', '.join(untested[:5]) + (' …' if len(untested) > 5 else ''))

        # 6 — Execution succeeded
        if not self.execution_results:
            add('Execution succeeded', None, 'No execution results available')
        else:
            status = self.execution_results.get('status')
            failed_cmds = self.execution_results.get('failed_commands') or []
            ok = status == 'success' and not failed_cmds
            add('Execution succeeded', ok,
                f"Status '{status}', no failed commands" if ok
                else f"Status '{status}'"
                     + (f", {len(failed_cmds)} failed command(s)" if failed_cmds else ''))

        # 7 — Reproducible working tree
        if not self.git_metadata:
            add('Working tree clean', None, 'No git metadata available')
        else:
            dirty = self.git_metadata.get('has_uncommitted_changes')
            if dirty is None:
                add('Working tree clean', None, 'Git metadata did not record tree state')
            else:
                files = self.git_metadata.get('uncommitted_files') or []
                add('Working tree clean', not dirty,
                    'No uncommitted changes at validation time' if not dirty
                    else f'{len(files)} uncommitted file(s) — the commit hash does '
                         'not describe what was validated')

        unmet = [c for c in criteria if c['met'] is False]
        unknown = [c for c in criteria if c['met'] is None]

        # Missing evidence dominates. If a stage never wrote its artifact, or a
        # criterion could not be assessed, the honest answer is that no
        # determination can be made — not that the metadata failed. Reporting
        # FAIL here would conflate "the evidence shows a problem" with "the
        # evidence is absent", which are different situations with different
        # remedies.
        if not complete or unknown:
            status = 'INCOMPLETE'
        elif unmet:
            status = 'FAIL'
        else:
            status = 'PASS'

        return {'status': status, 'criteria': criteria,
                'unmet': unmet, 'unknown': unknown}

    def generate(self) -> str:
        """Generate the unified report."""
        sections = []
        
        # Section 1: Commit Information
        sections.append(self._section_commit())
        
        # Section 2: Requirements Summary
        sections.append(self._section_requirements())
        
        # Section 3: Traceability Matrix
        sections.append(self._section_traceability())
        
        # Section 4: Execution Verification
        sections.append(self._section_execution())

        # Section 5: Environment
        sections.append(self._section_environment())

        # Section 6: Combined Summary
        sections.append(self._section_summary())

        # Combine all sections
        report = "# ARMADA Validation Report: Complete Pipeline Evidence\n\n"
        report += "This document consolidates all validation and execution evidence for regulatory submission.\n\n"
        report += f"**Run directory:** `{self.run_dir}`\n"
        report += f"**Report generated:** {datetime.now().isoformat()}\n\n"

        if self.missing_inputs:
            report += "> **⚠ INCOMPLETE — expected inputs were not found in the run directory:**\n>\n"
            for item in self.missing_inputs:
                report += f"> - {item}\n"
            report += (">\n> Sections below that depend on these inputs are empty. "
                       "This report is not complete evidence until every stage has run "
                       "against this run directory.\n\n")

        report += "---\n\n"
        report += "\n\n---\n\n".join(sections)

        return report
    
    @staticmethod
    def _first(d: Dict[str, Any], *keys, default='N/A'):
        """Return the first present, non-empty key. Tolerates both the documented
        schema (author_name, commit_date, repository_root) and the shorter
        spellings this generator originally assumed."""
        for key in keys:
            value = d.get(key)
            if value not in (None, ''):
                return value
        return default

    def _section_commit(self) -> str:
        """Generate commit information section."""
        git = self.git_metadata
        req = self.requirements.get('schema_title', 'Unknown TFL')

        section = "## 1. COMMIT INFORMATION\n\n"

        if not git:
            section += "No git metadata available — stage 6 did not write to this run directory.\n"
            return section

        author = self._first(git, 'author_name', 'author')
        email = self._first(git, 'author_email', default='')
        if email and email != 'N/A':
            author = f"{author} ({email})"

        section += f"**Commit Hash:** `{self._first(git, 'commit_hash')}`\n"
        section += f"**Author:** {author}\n"
        section += f"**Date:** {self._first(git, 'commit_date', 'date')}\n"
        section += f"**Repository:** {self._first(git, 'repository_root', 'repository')}\n"
        section += f"**Branch:** {self._first(git, 'branch')}\n"
        section += f"**Validated At:** {self._first(git, 'validation_timestamp')}\n\n"

        dirty = git.get('has_uncommitted_changes')
        if dirty is True:
            files = git.get('uncommitted_files') or []
            section += (f"**⚠ UNCOMMITTED CHANGES AT VALIDATION TIME — {len(files)} file(s).** "
                        "The commit hash above does not describe what was validated. "
                        "This run is not reproducible and must not be used for submission.\n\n")
        elif dirty is False:
            section += "**Working tree:** clean ✅\n\n"

        section += f"**Related TFL:** {req}\n"
        section += f"**Output ID:** `{self.output_id}`\n"
        return section

    def _section_environment(self) -> str:
        """Generate environment section from stage 6 capture."""
        section = "## 5. ENVIRONMENT\n\n"

        env = self.environment
        if not env:
            section += "No environment capture available — stage 6 did not write to this run directory.\n"
            return section

        for label, key in (("R Version", "r_version"),
                           ("Platform", "platform"),
                           ("Running", "running"),
                           ("Captured At", "captured_at")):
            if env.get(key):
                section += f"**{label}:** {env[key]}\n"

        packages = env.get('packages') or []
        section += f"\n**Loaded packages:** {len(packages)}\n\n"

        if packages:
            section += "| Package | Version |\n|---------|---------|\n"
            for pkg in sorted(packages, key=lambda p: str(p.get('package', '')).lower()):
                section += f"| `{pkg.get('package', '?')}` | {pkg.get('version', '?')} |\n"

        return section
    
    def _section_requirements(self) -> str:
        """Generate requirements summary section."""
        section = "## 2. REQUIREMENTS SUMMARY\n\n"
        
        if not self.requirements:
            section += "No requirements data available.\n"
            return section
        
        # Count the same set §3 traces, so the two sections agree
        all_reqs = self.all_requirements()
        sections = self.requirements.get('sections', [])
        n_output = len(self.requirements.get('output_requirements', []))
        n_section = len(all_reqs) - n_output

        section += f"**Total Requirements:** {len(all_reqs)}\n"
        section += f"**Output-level:** {n_output}\n"
        section += f"**Section-level:** {n_section}, across {len(sections)} section(s)\n\n"

        # Overview by type
        section += "### Overview by Type\n\n"
        section += "| Type | Count | Description |\n"
        section += "|------|-------|-------------|\n"

        req_types = {}
        for r in all_reqs:
            req_type = self.requirement_type(r)
            req_types[req_type] = req_types.get(req_type, 0) + 1

        type_descriptions = {
            'display_label': 'Section display labels (human-readable names)',
            'method': 'Statistical methods (calculations)',
            'by_variable': 'Grouping/stratification variables',
            'domain': 'SDTM domain source mappings',
            'subset': 'Filtering logic (inclusion/exclusion)',
            'denominator': 'Denominator dataset definitions',
            'title': 'Output title displayed above the table',
            'footnotes': 'Explanatory text displayed below the table',
            'footnote': 'Explanatory text displayed below the table',
            'analysis_set': 'Analysis set / population definition',
            'rationale': 'Rationale recorded on the specification',
            'treatment': 'Treatment variables, codelist and columns displayed',
            'column': 'Column structure (stub and result columns)',
            'study_design': 'Study design the display assumes',
            'sorting_order': 'Row ordering and tie-breaking rules',
            'missing': 'Handling of missing or uncoded values',
            'known_conflicts': 'Conflicts with the mock shell — human resolution required',
        }
        
        for req_type, count in sorted(req_types.items()):
            desc = type_descriptions.get(req_type, req_type)
            section += f"| `{req_type}` | {count} | {desc} |\n"
        
        return section
    
    @staticmethod
    def _truncate(value: str, limit: int = 60) -> str:
        """Keep the matrix readable without hiding a mismatch.

        Truncation is marked, and only bites well past the point where two
        values differ visibly.
        """
        value = (value or '').replace('|', '\\|').replace('\n', ' ')
        return value if len(value) <= limit else value[:limit - 1] + '…'

    # How each assertion token reads in the matrix. Only 'equal' means Expected
    # and Actual should be identical; for the others they legitimately differ on
    # a passing row, so the relation has to be stated or the table misleads.
    ASSERTION_DISPLAY = {
        'equal': 'equals',
        'match': 'matches',
        'member': 'is one of',
    }

    def _assertion_matrix(self, cov: Dict[str, List[Dict[str, Any]]]) -> str:
        """Per-assertion traceability, from the enriched JUnit properties.

        One row per assertion rather than per requirement: what was expected,
        what the metadata actually held, and the UUID of the entity it came
        from. This is what makes a PASS auditable — without expected/actual, a
        green row only says a test ran, not that it compared the right things.

        Rendered only when Stage 4 produced enriched XML. Stock testthat output
        has no properties, and an empty table would be worse than none.
        """
        rows = []
        for rid, tests in cov.items():
            for t in tests:
                if not (t.get('test_id') or t.get('expected') or t.get('actual')):
                    continue
                if t['failed']:
                    mark = '❌'
                elif t['skipped']:
                    mark = '⏭️'
                else:
                    mark = '✅'
                rows.append((t.get('test_id') or '—', rid,
                             self.ASSERTION_DISPLAY.get(t.get('assertion', ''), '—'),
                             self._truncate(t.get('expected', '')),
                             self._truncate(t.get('actual', '')),
                             t.get('metadata_uuid', ''),
                             t.get('metadata_path', ''),
                             mark))

        if not rows:
            return ''

        section = "\n### Assertion Detail\n\n"
        section += ("Each row is one assertion, linked to its requirement by the "
                    "`requirement_id` property emitted with the test result. "
                    "`Metadata UUID` identifies the entity in `metadata.json` "
                    "(and the corresponding file under `metadata_snapshot/`).\n\n")
        section += ("`Comparison` states how `Expected` relates to `Actual`, and **only "
                    "`equals` means the two should be identical**:\n\n"
                    "| Comparison | Passes when | `Actual` holds |\n"
                    "|---|---|---|\n"
                    "| `equals` | `Actual` is exactly `Expected` | the value found |\n"
                    "| `matches` | `Actual` satisfies the pattern in `Expected` | the value found |\n"
                    "| `is one of` | `Expected` is present in `Actual` | the **set searched**, not a single value |\n"
                    "| `—` | — | comparison not recorded (pre-`assertion` XML) |\n\n"
                    "So a passing `is one of` or `matches` row where the two columns "
                    "differ textually is correct, not a contradiction.\n\n")
        section += ("| Test ID | Requirement | Comparison | Expected | Actual | Metadata UUID | Path | Result |\n"
                    "|---|---|---|---|---|---|---|---|\n")
        for test_id, rid, comparison, expected, actual, uuid, path, mark in rows:
            uuid_cell = f"`{self._truncate(uuid, 80)}`" if uuid else '—'
            path_cell = f"`{self._truncate(path, 55)}`" if path else '—'
            comparison_cell = f"`{comparison}`" if comparison != '—' else '—'
            section += (f"| `{test_id}` | `{rid}` | {comparison_cell} | `{expected}` | `{actual}` | "
                        f"{uuid_cell} | {path_cell} | {mark} |\n")

        unenriched = [t for ts in cov.values() for t in ts
                      if not (t.get('test_id') or t.get('expected') or t.get('actual'))]
        if unenriched:
            section += (f"\n*{len(unenriched)} assertion(s) carried no evidence properties "
                        f"and are omitted from this table — they appear in the coverage "
                        f"table above. Regenerate them through `expect_armada_*()` "
                        f"(Stage 3) to make them auditable.*\n")

        return section

    def _section_traceability(self) -> str:
        """Generate traceability matrix section."""
        section = "## 3. TRACEABILITY MATRIX: Validation Evidence\n\n"
        
        if not self.test_results:
            section += "No test results available.\n"
            return section
        
        total = self.test_results['total']
        passed = self.test_results['passed']
        failed = self.test_results['failed']
        skipped = self.test_results.get('skipped', 0)
        pct = (passed / total * 100) if total > 0 else 0

        outcome = 'PASS' if failed == 0 and total > 0 else 'FAIL'
        mark = '✅' if outcome == 'PASS' else '❌'

        section += f"**Test Framework:** testthat (R)\n"
        section += f"**Overall Result:** {mark} {outcome} — {passed}/{total} passed ({pct:.0f}%)\n\n"

        section += "### Test Outcomes\n\n"
        section += "| Metric | Value |\n|--------|-------|\n"
        section += f"| Tests executed | {total} |\n"
        section += f"| Passed | {passed} |\n"
        section += f"| Failed | {failed} |\n"
        section += f"| Skipped | {skipped} |\n"

        # Requirement-to-test mapping, matched on normalised names
        req_ids = self.requirement_ids()
        if req_ids:
            cov = self.coverage()
            covered = sum(1 for ts in cov.values() if ts)
            section += (f"\n### Requirement Coverage\n\n"
                        f"**{covered}/{len(req_ids)} requirement(s) exercised by at least "
                        f"one test.**\n\n")
            section += "| Requirement | Tests | Result |\n|---|---|---|\n"
            for rid, ts in cov.items():
                if not ts:
                    section += f"| `{rid}` | 0 | ❌ NO TEST |\n"
                    continue
                if any(t['failed'] for t in ts):
                    result = '❌ FAIL'
                elif all(t['skipped'] for t in ts):
                    reasons = '; '.join(t['skip_reason'] or 'no reason given' for t in ts)
                    result = f'⏭️ SKIPPED — {reasons}'
                else:
                    result = '✅ PASS'
                section += f"| `{rid}` | {len(ts)} | {result} |\n"

            section += self._assertion_matrix(cov)

        # Any test that matched no requirement is untraceable
        matched = {t['normalised'] for ts in (self.coverage().values() if req_ids else [])
                   for t in ts}
        untraced = [t for t in self.test_results['tests'] if t['normalised'] not in matched]
        if untraced and req_ids:
            section += (f"\n**{len(untraced)} test(s) could not be traced to a requirement.** "
                        "Stage 3 names each test with its requirement ID as a prefix; these "
                        "do not match any ID in the requirements file:\n\n")
            for t in untraced[:10]:
                section += f"- `{t['name']}` ({t['source']})\n"

        if failed:
            section += "\n### Failures\n\n"
            for t in (x for x in self.test_results['tests'] if x['failed']):
                first_line = (t['detail'] or '').splitlines()[0] if t['detail'] else ''
                # Cite the stable test ID where the reporter emitted one; the
                # name attribute is testthat's rewritten description.
                label = t.get('test_id') or t['name']
                section += f"- **`{label}`** — {first_line}\n"
                if t.get('test_id') and t.get('expected'):
                    # Name the relation here too — "Expected X, Actual Y" alone
                    # reads as an equality claim whatever the assertion was.
                    rel = self.ASSERTION_DISPLAY.get(t.get('assertion', ''))
                    rel_note = f" (expected {rel} actual)" if rel else ''
                    section += (f"  - Requirement: `{t.get('requirement_id', '?')}`{rel_note} · "
                                f"Expected `{self._truncate(t['expected'], 80)}` · "
                                f"Actual `{self._truncate(t.get('actual', ''), 80)}`\n")
                    if t.get('metadata_uuid'):
                        section += (f"  - Metadata: `{t['metadata_uuid']}` "
                                    f"via `{t.get('metadata_path', '')}`\n")

        return section
    
    def _section_execution(self) -> str:
        """Generate execution verification section."""
        section = "## 4. EXECUTION VERIFICATION: Operational Evidence\n\n"
        
        if not self.execution_results:
            section += "No execution results available.\n"
            return section
        
        exec_res = self.execution_results
        status = exec_res.get('status', 'unknown')
        status_emoji = '✅' if status == 'success' else '❌'
        
        section += f"**Execution Date:** {datetime.now().isoformat()}\n"
        section += f"**Total Duration:** {exec_res.get('total_duration', 0):.1f} seconds\n"
        section += f"**Overall Status:** {status_emoji} {status.upper()}\n\n"
        
        # Phase summaries
        phases = exec_res.get('phases', {})
        section += "### Phase Summary\n\n"
        for phase_name, phase_data in phases.items():
            phase_status = '✅' if phase_data.get('status') == 'success' else '❌'
            section += f"- **{phase_name}:** {phase_status} ({phase_data.get('duration', 0):.1f}s)\n"
        
        # Discovery details
        section += f"\n### Discovery Results\n\n"
        section += f"**ARM Files Discovered:** {exec_res.get('arms_discovered', 0)}\n"
        section += f"**ARM Files Converted:** {len(exec_res.get('arms_converted', []))}\n"
        section += f"**AOM Files Converted:** {'1' if exec_res.get('aom_converted') else '0'}\n\n"
        
        # Execution details
        section += f"### Execution Results\n\n"
        section += f"**LEDs Executed:** {len(exec_res.get('leds_executed', []))}\n"
        for led in exec_res.get('leds_executed', []):
            section += f"- ✅ {led}\n"
        
        return section
    
    def _section_summary(self) -> str:
        """Generate combined evidence summary."""
        verdict = self.evaluate()

        symbol = {True: '✅', False: '❌', None: '⚠️'}
        headline = {
            'PASS': '✅ **ALL VALIDATION CRITERIA MET**',
            'FAIL': '❌ **VALIDATION CRITERIA NOT MET**',
            'INCOMPLETE': '⚠️ **EVIDENCE INCOMPLETE — CRITERIA COULD NOT BE ASSESSED**',
        }[verdict['status']]

        section = "## 6. VALIDATION CRITERIA\n\n"
        section += f"{headline}\n\n"
        section += "| Criterion | Met | Detail |\n|---|---|---|\n"
        for c in verdict['criteria']:
            detail = c['detail'].replace('|', '\\|')
            section += f"| {c['name']} | {symbol[c['met']]} | {detail} |\n"

        if verdict['unmet']:
            section += "\n### Criteria not met\n\n"
            for c in verdict['unmet']:
                section += f"- **{c['name']}** — {c['detail']}\n"

        if verdict['unknown']:
            section += "\n### Criteria that could not be assessed\n\n"
            for c in verdict['unknown']:
                section += f"- **{c['name']}** — {c['detail']}\n"

        section += "\n### Interpretation\n\n"
        if verdict['status'] == 'PASS':
            section += (
                f"Every criterion above is met for TFL `{self.output_id}`: the requirements "
                "were extracted, each is exercised by at least one test, all tests passed, "
                "the metadata converted and executed, and the repository was clean at "
                "validation time.\n\n")
        elif verdict['status'] == 'FAIL':
            section += (
                f"One or more criteria are not met for TFL `{self.output_id}`. The "
                "specifics are listed above. This run does not demonstrate that the "
                "metadata satisfies its specification.\n\n")
        else:
            section += (
                f"The evidence gathered for TFL `{self.output_id}` is insufficient to "
                "assess every criterion. Run the missing stages against this run "
                "directory and regenerate this report.\n\n")

        section += (
            "**This report states findings only. It does not certify fitness for "
            "regulatory submission — that determination rests with the responsible "
            "reviewer, recorded outside this document.**\n\n")

        section += f"**Verdict:** {verdict['status']}\n"
        section += f"**Report Generated:** {datetime.now().isoformat()}\n"

        return section


if __name__ == '__main__':
    import argparse
    import sys

    parser = argparse.ArgumentParser(
        description='Generate the unified ARMADA validation summary (stage 7)',
        epilog=("All inputs are read from --run-dir, the shared area every "
                "pipeline stage writes to. The report is written to "
                "<run-dir>/validation-report.md unless --output is given.")
    )
    parser.add_argument('output_id', help='Target AOM output ID')
    parser.add_argument(
        '--run-dir',
        required=True,
        help='Shared validation run directory containing every stage\'s artifacts'
    )
    parser.add_argument(
        '--output',
        default=None,
        help='Override the report path (default: <run-dir>/validation-report.md)'
    )

    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    if not run_dir.is_dir():
        print(f"Error: run directory not found: {run_dir}", file=sys.stderr)
        sys.exit(2)

    output_file = Path(args.output) if args.output else run_dir / 'validation-report.md'

    generator = UnifiedReportGenerator(args.output_id, str(run_dir))
    generator.load_all_data()
    report = generator.generate()
    verdict = generator.evaluate()

    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(report, encoding='utf-8')

    print(f"Report generated: {output_file}")
    print(f"Verdict: {verdict['status']}")

    for c in verdict['unmet']:
        print(f"  NOT MET      {c['name']} — {c['detail']}", file=sys.stderr)
    for c in verdict['unknown']:
        print(f"  UNASSESSED   {c['name']} — {c['detail']}", file=sys.stderr)

    # Exit code follows the verdict so this can gate a pipeline.
    sys.exit({'PASS': 0, 'FAIL': 1, 'INCOMPLETE': 3}[verdict['status']])
