#!/bin/bash
#
# CLI wrapper for ARMADA metadata collection
#
# Usage:
#   ./armada_collect_metadata.sh <output_id> [--summary] [--graph FILE] [--by-type DIR]
#
# Examples:
#   ./armada_collect_metadata.sh dv_t01_sum_impo_prot_dev_armada
#   ./armada_collect_metadata.sh dv_t01_sum_impo_prot_dev_armada --summary
#   ./armada_collect_metadata.sh dv_t01_sum_impo_prot_dev_armada --graph /tmp/graph.json
#

set -e

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_MODULE="${SCRIPT_DIR}/armada_metadata_collector.py"

# Check if metadata path is set
METADATA_PATH="${MERCURY_ARMAOM_METADATA_PATH:-/mnt/code/executor/metadata}"

if [ ! -f "$PYTHON_MODULE" ]; then
    echo "Error: armada_metadata_collector.py not found at $PYTHON_MODULE" >&2
    exit 1
fi

if [ -z "$1" ]; then
    echo "Usage: $(basename "$0") <output_id> [--summary] [--graph FILE] [--by-type DIR]" >&2
    echo "" >&2
    echo "Examples:" >&2
    echo "  $(basename "$0") dv_t01_sum_impo_prot_dev_armada" >&2
    echo "  $(basename "$0") dv_t01_sum_impo_prot_dev_armada --summary" >&2
    echo "  $(basename "$0") dv_t01_sum_impo_prot_dev_armada --graph /tmp/graph.json" >&2
    exit 1
fi

# Parse arguments
output_id="$1"
shift || true

# Forward all remaining arguments to Python
python3 "$PYTHON_MODULE" "$output_id" --metadata-path "$METADATA_PATH" "$@"
