#!/bin/bash
# armada_validate.sh - Extract ARMADA metadata requirements from ADO work item
#
# Usage:
#   ./armada_validate.sh <ADO_WORKITEM_URL> [output_format] [output_file]
#   
# Example:
#   ./armada_validate.sh "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276"
#   ./armada_validate.sh "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" json /tmp/requirements.json
#   ./armada_validate.sh "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" csv /tmp/requirements.csv
#   ./armada_validate.sh "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" java /tmp/DvT01ValidationTest.java

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Check for required arguments
if [[ $# -lt 1 ]]; then
    cat << EOF
Usage: $0 <ADO_WORKITEM_URL> [output_format] [output_file]

Arguments:
    ADO_WORKITEM_URL   Full URL to the ADO work item
    output_format      Output format: json (default), csv, or java
    output_file        Path to save output file (optional; prints to stdout if not specified)

Environment:
    ADO_PAT            Azure DevOps Personal Access Token (required)

Examples:
    # Print to stdout
    $0 "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276"
    
    # Save JSON to file
    $0 "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" json /tmp/requirements.json
    
    # Save CSV to file
    $0 "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" csv /tmp/requirements.csv
    
    # Save Java test class to file
    $0 "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" java /tmp/DvT01ValidationTest.java

EOF
    exit 1
fi

ADO_URL="$1"
OUTPUT_FORMAT="${2:-json}"
OUTPUT_FILE="${3:-}"

# Check for ADO_PAT
if [[ -z "${ADO_PAT:-}" ]]; then
    echo "ERROR: ADO_PAT environment variable not set"
    echo ""
    echo "Set it in your Domino profile:"
    echo "  Account Settings → Environment Variables → Add Variable"
    echo ""
    echo "Or temporarily in this session:"
    echo "  export ADO_PAT='your-personal-access-token'"
    exit 1
fi

# Run Python script
python3 << EOF
import sys
import json
sys.path.insert(0, '$REPO_ROOT/.github/scripts')

from armada_validator import (
    fetch_ado_workitem,
    parse_armada_schema,
    generate_junit_template,
    requirements_to_csv
)

try:
    # Fetch and parse
    wi = fetch_ado_workitem("$ADO_URL")
    schema = parse_armada_schema(wi['description'])
    
    # Generate output
    if "$OUTPUT_FORMAT" == "json":
        output = json.dumps(schema, indent=2)
    
    elif "$OUTPUT_FORMAT" == "csv":
        output = requirements_to_csv(schema)
    
    elif "$OUTPUT_FORMAT" == "java":
        java_template = generate_junit_template(schema)
        output = java_template['java_source']
    
    else:
        print(f"ERROR: Unknown format '$OUTPUT_FORMAT'", file=sys.stderr)
        sys.exit(1)
    
    # Save or print
    if "$OUTPUT_FILE":
        with open("$OUTPUT_FILE", "w") as f:
            f.write(output)
        print(f"✓ Saved to: $OUTPUT_FILE", file=sys.stderr)
        print(f"  Format: $OUTPUT_FORMAT")
        print(f"  Size: {len(output)} bytes", file=sys.stderr)
    else:
        print(output, end='')

except Exception as e:
    print(f"ERROR: {e}", file=sys.stderr)
    sys.exit(1)
EOF
