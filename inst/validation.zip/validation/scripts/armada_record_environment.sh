#!/bin/bash
#
# CLI wrapper for ARMADA Stage 6 — record environment.
#
# Runs both captures against one run directory:
#   armada_record_git.py  ->  <run-dir>/git_metadata.json
#   armada_record_env.R   ->  <run-dir>/environment.json + renv.lock
#
# Usage:
#   ./armada_record_environment.sh --run-dir "$RUN" [--repo PATH] [--project PATH] [--no-renv]
#
# Examples:
#   ./armada_record_environment.sh --run-dir "$RUN"
#   ./armada_record_environment.sh --run-dir "$RUN" --repo /mnt/code/metadata-repo
#
# Exit codes:
#   0  both captures clean
#   2  usage error
#   3  captured, but the evidence is not submittable — dirty/commitless tree,
#      or no lockfile. Details on stderr from whichever step raised it.
#
# Never captures ADO_PAT or any other credential.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GIT_SCRIPT="${SCRIPT_DIR}/armada_record_git.py"
ENV_SCRIPT="${SCRIPT_DIR}/armada_record_env.R"

run_dir=""
repo="."
project="."
extra=()

while [ $# -gt 0 ]; do
    case "$1" in
        --run-dir) run_dir="$2"; shift 2 ;;
        --repo)    repo="$2";    shift 2 ;;
        --project) project="$2"; shift 2 ;;
        --no-renv) extra+=("--no-renv"); shift ;;
        *) echo "Unknown argument: $1" >&2; exit 2 ;;
    esac
done

if [ -z "$run_dir" ]; then
    echo "Usage: $(basename "$0") --run-dir PATH [--repo PATH] [--project PATH] [--no-renv]" >&2
    exit 2
fi

for f in "$GIT_SCRIPT" "$ENV_SCRIPT"; do
    if [ ! -f "$f" ]; then
        echo "Error: $(basename "$f") not found at $f" >&2
        exit 2
    fi
done

# Both steps run even if the first reports a problem: a dirty tree is a finding
# to record, not a reason to skip capturing the environment. The worst exit code
# is carried to the end so the caller still sees it.
worst=0

echo "── commit provenance ──────────────────────────────────────────"
python3 "$GIT_SCRIPT" --run-dir "$run_dir" --repo "$repo"
status=$?
[ $status -eq 2 ] && exit 2
[ $status -gt $worst ] && worst=$status

echo
echo "── R environment ──────────────────────────────────────────────"
Rscript "$ENV_SCRIPT" --run-dir "$run_dir" --project "$project" "${extra[@]}"
status=$?
[ $status -eq 2 ] && exit 2
[ $status -gt $worst ] && worst=$status

echo
if [ $worst -eq 0 ]; then
    echo "Stage 6 complete — evidence captured and submittable."
else
    echo "Stage 6 captured, but the evidence is NOT submittable. See above." >&2
fi

exit $worst
