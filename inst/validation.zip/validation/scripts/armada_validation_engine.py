#!/usr/bin/env python3
"""
ARMADA Validation Engine — Phase 2A Implementation

Validates ARMADA metadata against requirements extracted from ADO work items.
Implements 4 core validators: DisplayLabel, Method, Domain, Subset.
"""

import json
import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional, Dict, List, Any
from datetime import datetime
import re
import yaml


@dataclass
class ValidationRequirement:
    """A single requirement extracted from ADO card"""
    requirement_id: str           # e.g., "section-1-display_label"
    requirement_type: str          # e.g., "display_label"
    section_number: int            # 1, 2, or 3
    expected_value: str           # from ADO
    description: str = ""         # context from ADO


@dataclass
class ValidationEvidence:
    """Evidence for a validation result"""
    expected: Optional[str] = None
    actual: Optional[str] = None
    location: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)
    metadata_paths: List[str] = field(default_factory=list)


@dataclass
class ValidationResult:
    """Result of validating one requirement"""
    requirement_id: str
    requirement_type: str
    section_number: int
    passed: bool
    error_message: str = ""
    evidence: ValidationEvidence = field(default_factory=ValidationEvidence)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'requirement_id': self.requirement_id,
            'requirement_type': self.requirement_type,
            'section_number': self.section_number,
            'passed': self.passed,
            'error_message': self.error_message,
            'evidence': asdict(self.evidence)
        }


class ValidationValidator(ABC):
    """Base class for all validators"""
    
    requirement_type: str
    
    @abstractmethod
    def validate(
        self, 
        requirement: ValidationRequirement, 
        metadata_graph: Dict[str, Any],
        metadata_root: Path
    ) -> ValidationResult:
        """Validate a single requirement. Return ValidationResult."""
        pass
    
    def _get_section_aom(
        self, 
        metadata_graph: Dict[str, Any],
        section_number: int
    ) -> Optional[Dict[str, Any]]:
        """Helper: Get section_aom entity for given section number"""
        by_type = metadata_graph.get('by_type', {})
        section_aoms = by_type.get('section_aom', [])
        for section_aom in section_aoms:
            if section_aom.get('section_number') == section_number:
                return section_aom
        return None
    
    def _resolve_uuid(
        self, 
        uuid: str, 
        metadata_graph: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Helper: Resolve UUID to entity in metadata graph"""
        full_graph = metadata_graph.get('graph', {})
        return full_graph.get(uuid)
    
    def _load_yaml_file(self, filepath: Path) -> Optional[Dict[str, Any]]:
        """Helper: Load YAML file"""
        try:
            if not filepath.exists():
                return None
            with open(filepath, 'r') as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return None


class DisplayLabelValidator(ValidationValidator):
    """Validator for display_label requirement type"""
    
    requirement_type = "display_label"
    
    def validate(
        self, 
        requirement: ValidationRequirement, 
        metadata_graph: Dict[str, Any],
        metadata_root: Path
    ) -> ValidationResult:
        """
        Rule 1: Check main_aom.outputLabel (table-wide)
        Rule 2: Check section_aom.sectionLabel (per-section)
        """
        result = ValidationResult(
            requirement_id=requirement.requirement_id,
            requirement_type=self.requirement_type,
            section_number=requirement.section_number,
            passed=False
        )
        
        # Rule 1: Check main AOM label (only on first requirement)
        if requirement.section_number == 1:
            main_aom = metadata_graph.get('main_aom', {})
            output_label = main_aom.get('outputLabel', '').strip() if main_aom.get('outputLabel') else None
            
            if not output_label or output_label != requirement.expected_value:
                result.error_message = f"Main AOM outputLabel mismatch"
                result.evidence = ValidationEvidence(
                    expected=requirement.expected_value,
                    actual=output_label,
                    location=metadata_graph.get('main_aom_path', 'unknown'),
                    details={'validation_rule': 'Rule 1: Main AOM outputLabel check'}
                )
                return result
        
        # Rule 2: Check section AOM label
        section_aom = self._get_section_aom(metadata_graph, requirement.section_number)
        if not section_aom:
            result.error_message = f"Section {requirement.section_number} not found in metadata"
            return result
        
        section_label = section_aom.get('sectionLabel', '').strip() if section_aom.get('sectionLabel') else None
        
        if not section_label or section_label != requirement.expected_value:
            result.error_message = f"Section {requirement.section_number} sectionLabel mismatch"
            result.evidence = ValidationEvidence(
                expected=requirement.expected_value,
                actual=section_label,
                location=section_aom.get('path', 'unknown'),
                details={'validation_rule': 'Rule 2: Section AOM sectionLabel check'}
            )
            return result
        
        result.passed = True
        result.evidence = ValidationEvidence(
            expected=requirement.expected_value,
            actual=section_label,
            location=section_aom.get('path', 'unknown'),
            details={'validation_rule': 'Rule 2: Section AOM sectionLabel check'}
        )
        return result


class MethodValidator(ValidationValidator):
    """Validator for method requirement type"""
    
    requirement_type = "method"
    
    def validate(
        self, 
        requirement: ValidationRequirement, 
        metadata_graph: Dict[str, Any],
        metadata_root: Path
    ) -> ValidationResult:
        """
        Rule 1: Method group existence
        Rule 2: Method group not empty
        Rule 3: Method completeness
        Rule 4: Arm-level methods
        """
        result = ValidationResult(
            requirement_id=requirement.requirement_id,
            requirement_type=self.requirement_type,
            section_number=requirement.section_number,
            passed=False
        )
        
        section_aom = self._get_section_aom(metadata_graph, requirement.section_number)
        if not section_aom:
            result.error_message = f"Section {requirement.section_number} not found"
            return result
        
        # Rule 1: Check method group exists
        method_group_uuid = section_aom.get('methodGroup')
        if not method_group_uuid:
            result.error_message = "methodGroup UUID not found in section_aom"
            return result
        
        method_group = self._resolve_uuid(method_group_uuid, metadata_graph)
        if not method_group:
            result.error_message = f"methodGroup UUID {method_group_uuid} does not resolve"
            result.evidence = ValidationEvidence(
                details={'validation_rule': 'Rule 1: Method group existence', 'uuid': method_group_uuid}
            )
            return result
        
        # Rule 2: Check method group not empty
        methods = method_group.get('methods', [])
        if not methods:
            result.error_message = "Method group contains no methods"
            result.evidence = ValidationEvidence(
                details={'validation_rule': 'Rule 2: Method group not empty', 'method_count': 0}
            )
            return result
        
        # Rule 3: Check method completeness
        valid_methods = 0
        invalid_methods = []
        
        for method_uuid in methods:
            method = self._resolve_uuid(method_uuid, metadata_graph)
            if not method:
                invalid_methods.append({'uuid': method_uuid, 'issue': 'UUID does not resolve'})
                continue
            
            label = method.get('label', '').strip() if method.get('label') else None
            package_name = method.get('packageName', '').strip() if method.get('packageName') else None
            function_name = method.get('functionName', '').strip() if method.get('functionName') else None
            
            if label and package_name and function_name:
                valid_methods += 1
            else:
                invalid_methods.append({
                    'uuid': method_uuid,
                    'label': label,
                    'packageName': package_name,
                    'functionName': function_name,
                    'issues': [k for k, v in [('label', label), ('packageName', package_name), ('functionName', function_name)] if not v]
                })
        
        if valid_methods == 0:
            result.error_message = f"No valid methods found (0/{len(methods)})"
            result.evidence = ValidationEvidence(
                details={
                    'validation_rule': 'Rule 3: Method completeness',
                    'total_methods': len(methods),
                    'valid_methods': valid_methods,
                    'invalid_methods': invalid_methods
                }
            )
            return result
        
        # Rule 4: Check arm-level methods
        arms = section_aom.get('arms', [])
        for arm_uuid in arms:
            arm = self._resolve_uuid(arm_uuid, metadata_graph)
            if not arm:
                result.error_message = f"Arm UUID {arm_uuid} does not resolve"
                return result
            
            arm_method_group = arm.get('methodGroup')
            if not arm_method_group:
                result.error_message = f"Arm missing methodGroup"
                return result
        
        result.passed = True
        result.evidence = ValidationEvidence(
            details={
                'validation_rule': 'All method checks passed',
                'total_methods': len(methods),
                'valid_methods': valid_methods,
                'invalid_methods': len(invalid_methods)
            }
        )
        return result


class DomainValidator(ValidationValidator):
    """Validator for domain requirement type"""
    
    requirement_type = "domain"
    
    def validate(
        self, 
        requirement: ValidationRequirement, 
        metadata_graph: Dict[str, Any],
        metadata_root: Path
    ) -> ValidationResult:
        """
        Rule 1: Domain requirement matching
        Rule 2: Domain required for all arms
        """
        result = ValidationResult(
            requirement_id=requirement.requirement_id,
            requirement_type=self.requirement_type,
            section_number=requirement.section_number,
            passed=False
        )
        
        section_aom = self._get_section_aom(metadata_graph, requirement.section_number)
        if not section_aom:
            result.error_message = f"Section {requirement.section_number} not found"
            return result
        
        # Get arms for this section
        arms = section_aom.get('arms', [])
        if not arms:
            result.error_message = f"No arms found in section {requirement.section_number}"
            return result
        
        # Rule 1 & 2: Check domain for all arms
        invalid_arms = []
        found_matching_domain = False
        
        for arm_uuid in arms:
            arm = self._resolve_uuid(arm_uuid, metadata_graph)
            if not arm:
                invalid_arms.append({'uuid': arm_uuid, 'issue': 'UUID does not resolve'})
                continue
            
            domain = arm.get('domain', '').strip() if arm.get('domain') else None
            
            if not domain:
                invalid_arms.append({
                    'uuid': arm_uuid,
                    'issue': 'domain is null or empty',
                    'arm_id': arm.get('armID', 'unknown')
                })
                continue
            
            if domain == requirement.expected_value:
                found_matching_domain = True
            else:
                invalid_arms.append({
                    'uuid': arm_uuid,
                    'arm_id': arm.get('armID', 'unknown'),
                    'expected': requirement.expected_value,
                    'actual': domain,
                    'match': False
                })
        
        if not found_matching_domain:
            result.error_message = f"No arm with domain '{requirement.expected_value}' found in section {requirement.section_number}"
            result.evidence = ValidationEvidence(
                expected=requirement.expected_value,
                details={
                    'validation_rule': 'Rule 1: Domain requirement matching',
                    'arms_checked': len(arms),
                    'invalid_arms': invalid_arms
                }
            )
            return result
        
        result.passed = True
        result.evidence = ValidationEvidence(
            expected=requirement.expected_value,
            actual=requirement.expected_value,
            details={
                'validation_rule': 'Rule 1: Domain requirement matching',
                'arms_checked': len(arms),
                'matching_arms': sum(1 for a in arms if self._resolve_uuid(a, metadata_graph) and self._resolve_uuid(a, metadata_graph).get('domain', '').strip() == requirement.expected_value)
            }
        )
        return result


class SubsetValidator(ValidationValidator):
    """Validator for subset requirement type"""
    
    requirement_type = "subset"
    VALID_OPERATORS = {'EQ', 'NE', 'GT', 'LT', 'GE', 'LE', 'IN', 'NOTIN'}
    
    def validate(
        self, 
        requirement: ValidationRequirement, 
        metadata_graph: Dict[str, Any],
        metadata_root: Path
    ) -> ValidationResult:
        """
        Rule 1: Subset presence and UUID resolution
        Rule 2: Where clause validity
        Rule 3: Range check validity
        """
        result = ValidationResult(
            requirement_id=requirement.requirement_id,
            requirement_type=self.requirement_type,
            section_number=requirement.section_number,
            passed=False
        )
        
        section_aom = self._get_section_aom(metadata_graph, requirement.section_number)
        if not section_aom:
            result.error_message = f"Section {requirement.section_number} not found"
            return result
        
        arms = section_aom.get('arms', [])
        if not arms:
            result.error_message = f"No arms found in section {requirement.section_number}"
            return result
        
        # Rule 1: Check subset presence and UUID resolution
        subset_found = False
        subset_issues = []
        
        for arm_uuid in arms:
            arm = self._resolve_uuid(arm_uuid, metadata_graph)
            if not arm:
                subset_issues.append({'uuid': arm_uuid, 'issue': 'Arm UUID does not resolve'})
                continue
            
            subset_uuid = arm.get('subSet')
            
            if not subset_uuid:
                # Subset is optional
                continue
            
            where_clause = self._resolve_uuid(subset_uuid, metadata_graph)
            if not where_clause:
                subset_issues.append({
                    'arm_id': arm.get('armID', 'unknown'),
                    'subSet': subset_uuid,
                    'issue': 'subSet UUID does not resolve'
                })
                continue
            
            # Rule 2: Validate where clause structure
            where_clause_id = where_clause.get('whereClauseID')
            where_clause_label = where_clause.get('whereClauseLabel', '').strip() if where_clause.get('whereClauseLabel') else None
            where_clause_role = where_clause.get('whereClauseRole')
            range_checks = where_clause.get('rangeChecks', [])
            
            if not where_clause_id:
                subset_issues.append({'issue': 'where_clause missing whereClauseID'})
                continue
            
            if not where_clause_label:
                subset_issues.append({'where_clause_id': where_clause_id, 'issue': 'whereClauseLabel is null or empty'})
                continue
            
            if where_clause_role != 'SubSet':
                subset_issues.append({
                    'where_clause_id': where_clause_id,
                    'expected': 'SubSet',
                    'actual': where_clause_role,
                    'issue': 'whereClauseRole mismatch'
                })
                continue
            
            if not range_checks:
                subset_issues.append({'where_clause_id': where_clause_id, 'issue': 'No range checks found'})
                continue
            
            # Rule 3: Validate range checks
            valid_range_checks = 0
            invalid_range_checks = []
            
            for range_check_uuid in range_checks:
                range_check = self._resolve_uuid(range_check_uuid, metadata_graph)
                if not range_check:
                    invalid_range_checks.append({'uuid': range_check_uuid, 'issue': 'UUID does not resolve'})
                    continue
                
                range_check_id = range_check.get('rangeCheckID')
                range_check_label = range_check.get('rangeCheckLabel', '').strip() if range_check.get('rangeCheckLabel') else None
                range_check_logic = range_check.get('rangeCheck', '').strip() if range_check.get('rangeCheck') else None
                
                if not range_check_id or not range_check_label or not range_check_logic:
                    invalid_range_checks.append({
                        'uuid': range_check_uuid,
                        'issues': [f for f, v in [('rangeCheckID', range_check_id), ('rangeCheckLabel', range_check_label), ('rangeCheck', range_check_logic)] if not v]
                    })
                    continue
                
                # Check operators
                operators = re.findall(r'\b(EQ|NE|GT|LT|GE|LE|IN|NOTIN)\b', range_check_logic)
                invalid_operators = [op for op in operators if op not in self.VALID_OPERATORS]
                
                if invalid_operators:
                    invalid_range_checks.append({
                        'uuid': range_check_uuid,
                        'range_check_logic': range_check_logic,
                        'invalid_operators': invalid_operators
                    })
                    continue
                
                valid_range_checks += 1
            
            if valid_range_checks > 0:
                subset_found = True
                result.evidence = ValidationEvidence(
                    details={
                        'validation_rule': 'All subset checks passed',
                        'where_clause_id': where_clause_id,
                        'range_check_count': len(range_checks),
                        'valid_range_checks': valid_range_checks,
                        'invalid_range_checks': len(invalid_range_checks)
                    }
                )
        
        if subset_found:
            result.passed = True
            return result
        
        # If no subset found and we have issues, report them
        if subset_issues:
            result.error_message = f"Subset validation failed for section {requirement.section_number}"
            result.evidence = ValidationEvidence(
                details={
                    'validation_rule': 'Rule 1-3: Subset validation',
                    'arms_checked': len(arms),
                    'subset_issues': subset_issues
                }
            )
        else:
            # Subset is optional - if not found, pass
            result.passed = True
        
        return result


class ARMADAValidationEngine:
    """Orchestrates all validators"""
    
    def __init__(self, metadata_root: Path = Path('/mnt/code/executor/metadata')):
        self.metadata_root = metadata_root
        self.validators = {
            'display_label': DisplayLabelValidator(),
            'method': MethodValidator(),
            'domain': DomainValidator(),
            'subset': SubsetValidator(),
        }
    
    def validate_tfl(
        self, 
        requirements: List[ValidationRequirement], 
        metadata_graph: Dict[str, Any]
    ) -> List[ValidationResult]:
        """
        Main entry point: validate all requirements against metadata graph.
        
        Returns list of ValidationResult objects (one per requirement).
        """
        results = []
        
        for requirement in requirements:
            requirement_type = requirement.requirement_type
            
            if requirement_type not in self.validators:
                # Skip unknown requirement types
                continue
            
            validator = self.validators[requirement_type]
            result = validator.validate(requirement, metadata_graph, self.metadata_root)
            results.append(result)
        
        return results
    
    def get_summary(self, results: List[ValidationResult]) -> Dict[str, Any]:
        """Generate summary statistics from validation results"""
        total = len(results)
        passed = sum(1 for r in results if r.passed)
        failed = total - passed
        
        by_section = {}
        for result in results:
            section = result.section_number
            if section not in by_section:
                by_section[section] = {'passed': 0, 'failed': 0}
            if result.passed:
                by_section[section]['passed'] += 1
            else:
                by_section[section]['failed'] += 1
        
        by_type = {}
        for result in results:
            req_type = result.requirement_type
            if req_type not in by_type:
                by_type[req_type] = {'passed': 0, 'failed': 0}
            if result.passed:
                by_type[req_type]['passed'] += 1
            else:
                by_type[req_type]['failed'] += 1
        
        return {
            'total_requirements': total,
            'passed': passed,
            'failed': failed,
            'by_section': by_section,
            'by_type': by_type,
            'overall_status': 'PASS' if failed == 0 else 'FAIL'
        }


def _convert_metadata_format(metadata_raw: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert metadata_collector output format to validation engine format.
    
    metadata_collector produces:
        {
            "entities": {
                "uuid1": {"entity_type": "...", "data": {...}},
                ...
            }
        }
    
    validation_engine expects:
        {
            "graph": {
                "uuid1": {...entity data...},
                ...
            },
            "by_type": {
                "main_aom": [entity1, entity2, ...],
                ...
            }
        }
    """
    graph = {}
    
    # First pass: build graph
    for entity_id, entity in metadata_raw.get('entities', {}).items():
        entity_type = entity.get('entity_type', 'unknown')
        entity_data = entity.get('data', {})
        
        graph[entity_id] = {
            **entity_data,
            'uuid': entity.get('uuid', entity_id),
            'type': entity_type,
            'file_path': entity.get('file_path'),
        }
    
    # Second pass: add section_number to section_aom entities based on order in main_aom
    main_aom = None
    for uuid, entity in graph.items():
        if entity.get('type') == 'main_aom':
            main_aom = entity
            break
    
    if main_aom and 'sections' in main_aom:
        section_uuids = [s.strip() for s in str(main_aom['sections']).split('*')]
        for idx, section_uuid in enumerate(section_uuids, start=1):
            if section_uuid in graph:
                graph[section_uuid]['section_number'] = idx
    
    # Third pass: populate by_type with updated entities
    by_type = {}
    for entity_id, entity in graph.items():
        entity_type = entity.get('type', 'unknown')
        if entity_type not in by_type:
            by_type[entity_type] = []
        by_type[entity_type].append(entity)
    
    return {
        'graph': graph,
        'by_type': by_type,
        'output_id': metadata_raw.get('output_id'),
        'root_file': metadata_raw.get('root_file'),
    }


def main():
    """CLI entry point"""
    if len(sys.argv) < 3:
        print("Usage: python armada_validation_engine.py <requirements_json> <metadata_json> [output_format]")
        print("  requirements_json: JSON file from armada_validator.py")
        print("  metadata_json: JSON file from armada_metadata_collector.py")
        print("  output_format: json, html, or both (default: json)")
        sys.exit(1)
    
    requirements_file = Path(sys.argv[1])
    metadata_file = Path(sys.argv[2])
    output_format = sys.argv[3] if len(sys.argv) > 3 else 'json'
    
    # Load requirements
    with open(requirements_file) as f:
        requirements_data = json.load(f)
    
    requirements = []
    
    # Handle nested section structure from armada_validator.py
    if isinstance(requirements_data, dict) and 'sections' in requirements_data:
        # New format: nested sections
        for section in requirements_data.get('sections', []):
            section_number = section.get('number', 0)
            section_title = section.get('title', '')
            
            for req in section.get('requirements', []):
                req_id = req.get('id', '')
                requirement_type = req_id.split('-')[-1] if '-' in req_id else 'unknown'
                
                requirements.append(ValidationRequirement(
                    requirement_id=req_id,
                    requirement_type=requirement_type,
                    section_number=section_number,
                    expected_value=req.get('documentation', ''),
                    description=req.get('description', '')
                ))
    else:
        # Legacy format: flat dictionary
        for req_id, req_value in requirements_data.items():
            # Parse requirement ID: section-{N}-{type}
            parts = req_id.split('-')
            if len(parts) >= 3:
                section_number = int(parts[1])
                requirement_type = '-'.join(parts[2:])
                requirements.append(ValidationRequirement(
                    requirement_id=req_id,
                    requirement_type=requirement_type,
                    section_number=section_number,
                    expected_value=str(req_value),
                    description=''
                ))
    
    # Load metadata graph
    with open(metadata_file) as f:
        metadata_raw = json.load(f)
    
    # Convert metadata_collector format to validation engine format
    metadata_graph = _convert_metadata_format(metadata_raw)
    
    # Run validation
    engine = ARMADAValidationEngine()
    results = engine.validate_tfl(requirements, metadata_graph)
    summary = engine.get_summary(results)
    
    # Output results
    output_data = {
        'timestamp': datetime.now().isoformat(),
        'summary': summary,
        'results': [r.to_dict() for r in results]
    }
    
    print(json.dumps(output_data, indent=2))


if __name__ == '__main__':
    main()
