#!/bin/bash
#
# ARMADA LED Execution CLI Wrapper
#
# Simple wrapper around armada_executor.py for command-line usage
#
# Usage:
#   ./armada_execute.sh dv_t01_sum_impo_prot_dev_armada
#   ./armada_execute.sh dv_t01_sum_impo_prot_dev_armada --dry-run true --verbose true
#   ./armada_execute.sh dv_t01_sum_impo_prot_dev_armada --log-file /tmp/exec.log
#

set -e

# Resolve script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXECUTOR_SCRIPT="$SCRIPT_DIR/armada_executor.py"

# Check if executor script exists
if [ ! -f "$EXECUTOR_SCRIPT" ]; then
    echo "Error: armada_executor.py not found at $EXECUTOR_SCRIPT" >&2
    exit 1
fi

# Parse arguments
OUTPUT_ID="${1:?Error: output-id required. Usage: $0 <output-id> [options]}"
shift || true

# Prepare arguments for Python script
PYTHON_ARGS=(
    "--output-id" "$OUTPUT_ID"
)

# Pass through remaining arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        --dry-run|--verbose|--stop-on-error)
            PYTHON_ARGS+=("$1" "$2")
            shift 2
            ;;
        --work-dir|--log-file)
            PYTHON_ARGS+=("$1" "$2")
            shift 2
            ;;
        -h|--help)
            echo "ARMADA LED Execution CLI"
            echo ""
            echo "Usage:"
            echo "  $0 <output-id> [OPTIONS]"
            echo ""
            echo "Arguments:"
            echo "  output-id              Target AOM output ID (e.g., dv_t01_sum_impo_prot_dev_armada)"
            echo ""
            echo "Options:"
            echo "  --work-dir <path>      Root directory containing metadata and Makefile (default: /mnt/code)"
            echo "  --dry-run true|false   Print commands without executing (default: false)"
            echo "  --verbose true|false   Print detailed progress (default: false)"
            echo "  --log-file <path>      Optional file path for log output"
            echo "  --stop-on-error true|false  Stop on first error (default: true)"
            echo "  -h, --help            Show this help message"
            echo ""
            echo "Examples:"
            echo "  $0 dv_t01_sum_impo_prot_dev_armada"
            echo "  $0 dv_t01_sum_impo_prot_dev_armada --dry-run true --verbose true"
            echo "  $0 dv_t01_sum_impo_prot_dev_armada --log-file /tmp/exec.log"
            exit 0
            ;;
        *)
            echo "Error: Unknown option: $1" >&2
            echo "Use --help for usage information" >&2
            exit 1
            ;;
    esac
done

# Run executor
python3 "$EXECUTOR_SCRIPT" "${PYTHON_ARGS[@]}"
