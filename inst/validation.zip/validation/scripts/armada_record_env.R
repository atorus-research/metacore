#!/usr/bin/env Rscript
# Stage 6 — record the R environment for a validation run.
#
# Writes two things into the run directory:
#   environment.json  R version, platform, and the packages loaded in this
#                     session. Stage 7 renders this as §5 of the report.
#   renv.lock         The project's dependency lock — the primary environment
#                     evidence. Falls back to renv-not-used.txt, recording why,
#                     when the project cannot produce one.
#
# Usage:
#   Rscript armada_record_env.R --run-dir "$RUN" [--project PATH] [--no-renv]
#
# Run this AFTER Stage 5, so the session reflects what actually ran.
#
# Exit codes:
#   0  environment.json and renv.lock both written
#   2  usage error
#   3  environment.json written, but no lockfile — absence recorded in
#      renv-not-used.txt. Fallback evidence only.

args <- commandArgs(trailingOnly = TRUE)

arg_value <- function(flag, default = NULL) {
  idx <- match(flag, args)
  if (!is.na(idx) && idx < length(args)) args[idx + 1L] else default
}

run_dir  <- arg_value("--run-dir")
project  <- arg_value("--project", ".")
skip_renv <- "--no-renv" %in% args

if (is.null(run_dir)) {
  cat("Error: --run-dir <path> is required\n",
      "  Usage: Rscript armada_record_env.R --run-dir \"$RUN\" [--project PATH] [--no-renv]\n",
      sep = "", file = stderr())
  quit(status = 2L)
}
if (!dir.exists(run_dir)) {
  cat("Error: run directory not found: ", run_dir, "\n", sep = "", file = stderr())
  quit(status = 2L)
}

# ── environment.json ─────────────────────────────────────────────────────────
# Load what the Stage 4 suite uses first, so sessionInfo() is a closer proxy for
# the run session than a bare Rscript would be. Missing packages are not fatal —
# the capture should still record whatever IS present.
for (pkg in c("testthat", "jsonlite", "R6", "xml2")) {
  suppressWarnings(suppressPackageStartupMessages(
    try(library(pkg, character.only = TRUE), silent = TRUE)
  ))
}

si <- sessionInfo()

# unname() is REQUIRED, not cosmetic. si$otherPkgs and si$loadedOnly are NAMED
# lists, so lapply() keeps the names and jsonlite emits
# "packages": {"jsonlite": {...}} — a JSON object. Stage 7 does
# sorted(packages, key=lambda p: p.get('package')), which iterates an object's
# KEYS (strings) and dies with AttributeError. unname() makes it the array
# Stage 7 expects.
pkgs <- unname(c(si$otherPkgs, si$loadedOnly))

env_path <- file.path(run_dir, "environment.json")
jsonlite::write_json(list(
  r_version   = R.version.string,
  platform    = si$platform,
  running     = si$running,
  packages    = lapply(pkgs, function(p) list(package = p$Package, version = p$Version)),
  captured_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z")
), env_path, auto_unbox = TRUE, pretty = TRUE)

cat("wrote ", env_path, "\n", sep = "")
cat("  packages captured = ", length(pkgs), "\n", sep = "")

# ── renv.lock ────────────────────────────────────────────────────────────────
# sessionInfo() records what this session happened to load. The lockfile records
# what the PROJECT uses, plus recursive dependencies, pinned to exact versions.
# The gap is real: on this framework sessionInfo captured 11 packages against
# the lockfile's 26, missing xml2 — the package Stage 4's reporter is built on.

record_absence <- function(reason) {
  # Remove any lockfile left by an earlier invocation against this run
  # directory. Leaving it would let a stale lockfile stand as this run's
  # evidence — the acceptance check tests renv.lock first, and would never
  # reach renv-not-used.txt. Same failure mode as the stale-PDF defect (D10).
  if (file.exists(lock_path)) {
    unlink(lock_path)
    cat("removed stale ", lock_path, " (superseded by this capture)\n", sep = "")
  }
  path <- file.path(run_dir, "renv-not-used.txt")
  writeLines(c(
    "No renv.lock captured for this run.",
    "",
    paste0("Reason: ", reason),
    "Fallback evidence: environment.json (sessionInfo of the capturing session)",
    paste0("Recorded at: ", format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"))
  ), path)
  cat("wrote ", path, "\n", sep = "")
  cat("  NO LOCKFILE — fallback evidence only.\n")
}

lock_path <- file.path(run_dir, "renv.lock")
unlink(file.path(run_dir, "renv-not-used.txt"))

if (skip_renv) {
  record_absence("--no-renv was passed explicitly by the operator.")
  quit(status = 3L)
}

if (!requireNamespace("renv", quietly = TRUE)) {
  record_absence("renv is not installed in this R library.")
  quit(status = 3L)
}

# renv::snapshot() needs an renv-managed project, and renv::init() would write
# an renv/ library and .Rprofile into the repository — too large a side effect
# for a capture step. lockfile_create() produces the same artifact with none.
# type = "implicit" scans the project's sources for what it actually uses,
# rather than locking everything installed.
ok <- tryCatch({
  lf <- renv::lockfile_create(project = project, type = "implicit", prompt = FALSE)
  renv::lockfile_write(lf, file = lock_path)
  TRUE
}, error = function(e) {
  record_absence(paste0("renv::lockfile_create() failed: ", conditionMessage(e)))
  FALSE
})

if (!ok) quit(status = 3L)

n_locked <- length(jsonlite::read_json(lock_path)$Packages)
cat("wrote ", lock_path, "\n", sep = "")
cat("  packages locked   = ", n_locked, "\n", sep = "")

if (n_locked == 0L) {
  cat("\nWARNING: the lockfile is empty. renv found no dependencies in '", project,
      "'.\n  A lockfile that does not describe a working library is worse than none,\n",
      "  because it looks like evidence. Check --project points at the package root.\n",
      sep = "", file = stderr())
  quit(status = 3L)
}

# The lockfile belongs in the repository as well as the run directory, so a
# future checkout can restore the environment this run used.
cat("\nCopy the lockfile into the project root as well:\n")
cat("  cp ", lock_path, " ", file.path(project, "renv.lock"), "\n", sep = "")

quit(status = 0L)
