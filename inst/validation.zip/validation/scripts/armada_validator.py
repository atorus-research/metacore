"""
armada_validator.py

Functions for validating ARMADA metadata against requirements defined in Azure DevOps work items.
"""

import json
import os
import re
from html.parser import HTMLParser
from typing import Dict, List, Any, Optional

import requests


class HTMLTextExtractor(HTMLParser):
    """Convert HTML to plain text, preserving structure with newlines."""
    
    def __init__(self):
        super().__init__()
        self.text = []
        self.in_code = False
    
    def handle_starttag(self, tag, attrs):
        if tag == 'code':
            self.in_code = True
        elif tag in ['p', 'div', 'h3', 'h4', 'li', 'tr']:
            if self.text and self.text[-1] != '\n':
                self.text.append('\n')
    
    def handle_data(self, data):
        self.text.append(data.strip() if not self.in_code else data)
    
    def handle_endtag(self, tag):
        if tag == 'code':
            self.in_code = False
        elif tag in ['p', 'div', 'h3', 'h4', 'li', 'tr']:
            if self.text and self.text[-1] != '\n':
                self.text.append('\n')
    
    def get_text(self):
        return ''.join(self.text)


def fetch_ado_workitem(url: str, pat: Optional[str] = None) -> Dict[str, Any]:
    """
    Fetch an ADO work item by URL and return parsed metadata.
    
    Parameters:
        url (str): Full ADO work item URL
        pat (str, optional): Azure DevOps PAT (defaults to ADO_PAT env var)
    
    Returns:
        dict: Work item metadata with keys:
            - id (int): Work item ID
            - title (str): Work item title
            - description (str): Plain-text description (HTML converted)
            - type (str): Work item type
            - state (str): Work item state
            - assigned_to (str): Assignee display name
    
    Raises:
        ValueError: If ADO_PAT is not set and pat is None
        requests.HTTPError: If API call fails
    """
    
    # Resolve PAT
    if pat is None:
        pat = os.environ.get('ADO_PAT')
        if not pat:
            raise ValueError(
                "ADO_PAT environment variable not set. "
                "Set it as a personal environment variable in your Domino profile. "
                "Never commit the PAT to source control."
            )
    
    # Parse URL to extract project and ID
    # Example: https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276
    match = re.search(r'/([^/]+)/([^/]+)/_workitems/edit/(\d+)', url)
    if not match:
        raise ValueError(f"Invalid ADO work item URL: {url}")
    
    org, project, item_id = match.groups()
    
    # Build API URL
    api_url = (
        f"https://dev.azure.com/{org}/{project}/_apis/wit/workitems/{item_id}"
        "?$expand=relations&api-version=7.1"
    )
    
    # Create auth header
    auth_str = f":{pat}"
    import base64
    auth_b64 = base64.b64encode(auth_str.encode()).decode()
    
    # Fetch work item
    headers = {
        "Authorization": f"Basic {auth_b64}",
        "Content-Type": "application/json"
    }
    
    response = requests.get(api_url, headers=headers)
    response.raise_for_status()
    
    data = response.json()
    fields = data.get('fields', {})
    
    # Convert HTML description to plain text
    html_desc = fields.get('System.Description', '')
    extractor = HTMLTextExtractor()
    extractor.feed(html_desc)
    plain_desc = extractor.get_text()
    
    # Clean up extra whitespace
    plain_desc = re.sub(r'\n+', '\n', plain_desc).strip()
    
    # Extract assignee
    assigned_to_obj = fields.get('System.AssignedTo', {})
    assigned_to = (
        assigned_to_obj.get('displayName', 'Unassigned')
        if isinstance(assigned_to_obj, dict)
        else str(assigned_to_obj)
    )
    
    return {
        'id': data.get('id'),
        'title': fields.get('System.Title', ''),
        'description': plain_desc,
        'type': fields.get('System.WorkItemType', ''),
        'state': fields.get('System.State', ''),
        'assigned_to': assigned_to
    }


def parse_armada_schema(description_text: str) -> Dict[str, Any]:
    """
    Parse an ARMADA schema description and extract structured requirements.
    
    Detects "Section N — Title" patterns to properly organize multi-section schemas.
    Extracts output-level requirements (title and footnotes) before sections.
    
    Parameters:
        description_text (str): Plain-text schema description
    
    Returns:
        dict: Parsed schema with keys:
            - schema_title (str): Display/table title
            - schema_type (str): "table", "listing", or "figure"
            - display_name (str): Short display name (extracted from schema)
            - output_requirements (list): Output-level requirements:
                - output-title: The table title/display name
                - output-footnotes: All footnotes or "no footnotes" requirement
            - sections (list): Section definitions, each with:
                - id (str): Section ID (e.g., section-1)
                - number (int): Section number
                - title (str): Section title
                - requirements (list): 6 section-level requirements
            - requirements (list): Top-level requirements (flattened, all output + section level)
    """
    
    schema = {
        'schema_title': '',
        'schema_type': 'table',  # default
        'display_name': '',
        'output_requirements': [],
        'sections': [],
        'requirements': []
    }
    
    lines = description_text.split('\n')
    
    # Extract title (usually near the start, after "Display Description")
    for i, line in enumerate(lines):
        if 'Display Description' in line or 'Display' in line and i < 10:
            if i + 1 < len(lines):
                schema['schema_title'] = lines[i + 1].strip()
            break
    
    # Extract output-level requirements (title and footnotes) before sections
    title_extracted = False
    footnotes_list = []
    section_start_idx = None
    
    for i, line in enumerate(lines):
        # Find where sections start
        if re.match(r'Section\s+\d+\s*—', line.strip()):
            section_start_idx = i
            break
        
        line_stripped = line.strip()
        
        # Extract display/output title
        if not title_extracted and any(kw in line_stripped for kw in ['Display Name:', 'Output Title:', 'Table Title:']):
            if ':' in line_stripped:
                key, value = line_stripped.split(':', 1)
                if value.strip():
                    schema['display_name'] = value.strip()
                    schema['output_requirements'].append({
                        'id': 'output-title',
                        'documentation': f"Table title: {value.strip()}",
                        'description': "The table's main title displayed above the table",
                        'test_code': f'assertEquals("{value.strip()}", metadata.outputLabel);'
                    })
                    title_extracted = True
        
        # Extract footnotes (before sections)
        if section_start_idx is None and ('Footnote' in line_stripped or 'Note:' in line_stripped):
            if ':' in line_stripped:
                key, value = line_stripped.split(':', 1)
                footnote_text = value.strip()
                if footnote_text and footnote_text.lower() not in ['none', 'n/a']:
                    footnotes_list.append(footnote_text)
    
    # Create footnotes requirement
    if footnotes_list:
        schema['output_requirements'].append({
            'id': 'output-footnotes',
            'documentation': footnotes_list,
            'description': "Explanatory text displayed below the table",
            'test_code': f'assertTrue(metadata.hasFootnotes() && metadata.footnotes.size() == {len(footnotes_list)});'
        })
    else:
        # If no footnotes found, create requirement that states "no footnotes expected"
        schema['output_requirements'].append({
            'id': 'output-footnotes',
            'documentation': "The table must NOT display any footnotes",
            'description': "No explanatory text should appear below the table",
            'test_code': 'assertTrue(!metadata.hasFootnotes() || metadata.footnotes.isEmpty());'
        })
    
    # Parse sections, looking specifically for "Section N — Title" pattern
    current_section_num = None
    current_section_title = None
    current_requirements = []
    
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        
        # Match "Section N — <Title>" pattern (e.g., "Section 1 — Any Important Protocol Deviations")
        section_match = re.match(r'Section\s+(\d+)\s*—\s*(.+)', line)
        if section_match:
            # Save previous section if exists
            if current_section_num is not None and current_requirements:
                schema['sections'].append({
                    'id': f'section-{current_section_num}',
                    'number': current_section_num,
                    'title': current_section_title,
                    'requirements': current_requirements
                })
            
            current_section_num = int(section_match.group(1))
            current_section_title = section_match.group(2).strip()
            current_requirements = []
        
        elif current_section_num is not None and line and ':' in line:
            # Extract Key: Value requirement pairs within sections
            key, value = line.split(':', 1)
            key = key.strip()
            value = value.strip()
            
            if value and key in [
                'Display label', 'Method', 'By Variable', 'Domain', 
                'Subset', 'Denominator', 'Title', 'Rationale', 'Footnote', 'Analysis set'
            ]:
                # Create unique ID: section-{number}-{key_type}
                req_type = _requirement_type_from_key(key)
                req_id = f'section-{current_section_num}-{req_type}'
                
                # Generate documentation
                documentation = _generate_documentation(req_type, key, value, f'Section {current_section_num}')
                
                # Generate test code
                test_code = _generate_test_code(req_type, key, value)
                
                req = {
                    'id': req_id,
                    'documentation': documentation,
                    'test_code': test_code,
                    'description': f"{key}: {value}"
                }
                
                current_requirements.append(req)
        
        i += 1
    
    # Save final section
    if current_section_num is not None and current_requirements:
        schema['sections'].append({
            'id': f'section-{current_section_num}',
            'number': current_section_num,
            'title': current_section_title,
            'requirements': current_requirements
        })
    
    # Flatten all requirements to top level for easier access
    schema['requirements'].extend(schema['output_requirements'])
    for section in schema['sections']:
        schema['requirements'].extend(section['requirements'])
    
    return schema


def _requirement_type_from_key(key: str) -> str:
    """Map a requirement key to its kebab-case type."""
    type_mapping = {
        'Domain': 'domain',
        'Method': 'method',
        'By Variable': 'by_variable',
        'Subset': 'subset',
        'Denominator': 'denominator',
        'Display label': 'display_label',
        'Rationale': 'rationale',
        'Footnote': 'footnote',
        'Title': 'title',
        'Analysis set': 'analysis_set',
    }
    return type_mapping.get(key, _kebab_case(key))


def _kebab_case(s: str) -> str:
    """Convert a string to kebab-case."""
    s = s.lower()
    s = re.sub(r'[^a-z0-9]+', '-', s)
    s = re.sub(r'^-|-$', '', s)
    return s


def _generate_documentation(req_type: str, key: str, value: str, section: str) -> str:
    """Generate human-readable documentation for a requirement."""
    
    templates = {
        'domain': f"Requirement uses {value} domain for data source.",
        'method': f"Statistical method: {value}",
        'by_variable': f"Table must present data stratified by: {value}",
        'subset': f"Data must be subset/filtered using: {value}",
        'denominator': f"Denominator for percentages and counts: {value}",
        'display_label': f"Display label must be: {value}",
        'rationale': f"Rationale: {value}",
        'footnote': f"Footnote requirement: {value}",
        'title': f"Display title must be: {value}",
        'analysis_set': f"Analysis set must be: {value}",
        'treatment': f"Treatment variable specification: {value}",
    }
    
    return templates.get(req_type, f"{key}: {value}")


def _generate_test_code(req_type: str, key: str, value: str) -> str:
    """Generate JUnit-style test pseudocode for a requirement."""
    
    templates = {
        'domain': f'assertEquals("{value}", metadata.domain);',
        'method': f'assertTrue(metadata.method.contains("{value}"));',
        'subset': f'assertTrue(metadata.subset.contains("{value}"));',
        'denominator': f'assertEquals("{value}", metadata.denominator);',
        'display_label': f'assertEquals("{value}", metadata.display_label);',
        'analysis_set': f'assertEquals("{value}", metadata.analysis_set);',
        'treatment': f'assertTrue(metadata.treatment.contains("{value}"));',
        'by_variable': f'assertTrue(metadata.by_variable.contains("{value}"));',
    }
    
    if req_type in templates:
        return templates[req_type]
    
    # Generic fallback
    return f'// Validate: {key}\nassertNotNull(metadata);'


def generate_junit_template(schema_dict: Dict[str, Any], package_name: str = "com.armada.validation") -> Dict[str, Any]:
    """
    Generate a JUnit test class template from parsed schema requirements.
    
    Note: Test generation is included for future extension; actual test execution
    and validation is out of scope for this skill.
    
    Parameters:
        schema_dict (dict): Output from parse_armada_schema
        package_name (str): Java package for generated test class
    
    Returns:
        dict: Test template with keys:
            - class_name (str): Generated test class name
            - package (str): Java package
            - imports (list): Required imports
            - test_methods (list): Test methods, each with name, code, requirement_id
            - java_source (str): Full JUnit class source code
    """
    
    class_name = _to_camel_case(schema_dict.get('schema_title', 'Schema')) + "ValidationTest"
    
    imports = [
        "import org.junit.Test;",
        "import org.junit.Before;",
        "import static org.junit.Assert.*;",
        "import java.util.Map;",
        "import com.armada.metadata.ArmadaMetadata;",
    ]
    
    test_methods = []
    
    for req in schema_dict.get('requirements', []):
        method_name = f"test_{req['id'].replace('-', '_')}"
        
        test_methods.append({
            'name': method_name,
            'code': req['test_code'],
            'requirement_id': req['id']
        })
    
    # Generate Java source
    java_source = _generate_java_source(
        class_name, package_name, imports, test_methods,
        schema_dict.get('schema_title', 'Unknown Schema')
    )
    
    return {
        'class_name': class_name,
        'package': package_name,
        'imports': imports,
        'test_methods': test_methods,
        'java_source': java_source
    }


def _to_camel_case(s: str) -> str:
    """Convert kebab-case or space-separated string to CamelCase."""
    words = re.split(r'[-\s]+', s.lower())
    return ''.join(w.capitalize() for w in words if w)


def _generate_java_source(class_name: str, package_name: str, imports: List[str],
                          test_methods: List[Dict[str, str]], schema_title: str) -> str:
    """Generate full JUnit test class source code."""
    
    source_lines = [
        f"package {package_name};",
        "",
        *imports,
        "",
        "/**",
        f" * Auto-generated test class for: {schema_title}",
        " *",
        " * This test class validates ARMADA metadata against the schema requirements",
        " * defined in the corresponding ADO work item.",
        " */",
        f"public class {class_name} {{",
        "",
        "    private ArmadaMetadata metadata;",
        "",
        "    @Before",
        "    public void setUp() {",
        "        // Load ARMADA metadata from configuration",
        "        metadata = ArmadaMetadata.loadFromConfig();",
        "    }",
        "",
    ]
    
    for method in test_methods:
        source_lines.extend([
            f"    @Test",
            f"    public void {method['name']}() {{",
            f"        // Requirement: {method['requirement_id']}",
            f"        {method['code']}",
            f"    }}",
            ""
        ])
    
    source_lines.append("}")
    
    return '\n'.join(source_lines)


def requirements_to_json(schema_dict: Dict[str, Any], indent: int = 2) -> str:
    """Convert parsed schema to formatted JSON string."""
    return json.dumps(schema_dict, indent=indent)


def requirements_to_csv(schema_dict: Dict[str, Any]) -> str:
    """Convert requirements to CSV format (id, documentation, test_code, description)."""
    import csv
    from io import StringIO
    
    output = StringIO()
    writer = csv.writer(output)
    
    writer.writerow(['requirement_id', 'documentation', 'test_code', 'description'])
    
    for req in schema_dict.get('requirements', []):
        writer.writerow([
            req.get('id', ''),
            req.get('documentation', ''),
            req.get('test_code', ''),
            req.get('description', '')
        ])
    
    return output.getvalue()


def save_requirements(schema_dict: Dict[str, Any], output_file: str, format: str = 'json') -> None:
    """
    Save requirements to a file in the specified format.
    
    Parameters:
        schema_dict (dict): Output from parse_armada_schema
        output_file (str): Path to output file (will be created/overwritten)
        format (str): Output format: json, csv, or java
    
    Raises:
        ValueError: If format is not recognized
        IOError: If file cannot be written
    """
    
    if format == 'json':
        content = requirements_to_json(schema_dict)
    elif format == 'csv':
        content = requirements_to_csv(schema_dict)
    elif format == 'java':
        template = generate_junit_template(schema_dict)
        content = template['java_source']
    else:
        raise ValueError(f"Unknown format: {format}")
    
    with open(output_file, 'w') as f:
        f.write(content)

