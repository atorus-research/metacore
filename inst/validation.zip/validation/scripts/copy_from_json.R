#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)

if (length(args) != 2) {
  cat("Usage: Rscript copy_from_json.R <json_file> <target_dir>\n", file = stderr())
  quit(status = 1)
}

json_file <- args[1]
target_dir <- args[2]
prefix <- "/mnt/code"

if (!file.exists(json_file)) {
  cat(sprintf("Error: JSON file not found: %s\n", json_file), file = stderr())
  quit(status = 1)
}

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  cat("Error: package 'jsonlite' is required but not installed.\n", file = stderr())
  cat("Install it with: install.packages('jsonlite')\n", file = stderr())
  quit(status = 1)
}

# Recursively extract all values of keys named "file_path"
extract_file_paths <- function(x) {
  paths <- character()
  
  if (is.list(x)) {
    if (!is.null(x$file_path) && is.character(x$file_path) && length(x$file_path) == 1) {
      paths <- c(paths, x$file_path)
    }
    
    for (item in x) {
      paths <- c(paths, extract_file_paths(item))
    }
  }
  
  paths
}

# Read JSON
data <- jsonlite::fromJSON(json_file, simplifyVector = FALSE)

# Extract unique file paths
file_paths <- unique(extract_file_paths(data))

if (length(file_paths) == 0) {
  cat("No file_path entries found in JSON.\n")
  quit(status = 0)
}

dir.create(target_dir, recursive = TRUE, showWarnings = FALSE)

prefix_slash <- paste0(prefix, "/")

for (src in file_paths) {
  if (!is.character(src) || length(src) != 1 || nchar(src) == 0) {
    next
  }
  
  if (!file.exists(src)) {
    cat(sprintf("Warning: source file not found, skipping: %s\n", src), file = stderr())
    next
  }
  
  if (!startsWith(src, prefix_slash)) {
    cat(sprintf("Warning: path does not start with %s, skipping: %s\n", prefix, src), file = stderr())
    next
  }
  
  rel_path <- substring(src, nchar(prefix_slash) + 1)
  dest <- file.path(target_dir, rel_path)
  
  dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
  
  ok <- file.copy(
    from = src,
    to = dest,
    overwrite = TRUE,
    copy.mode = TRUE,
    copy.date = TRUE
  )
  
  if (ok) {
    cat(sprintf("Copied: %s -> %s\n", src, dest))
  } else {
    cat(sprintf("Error: failed to copy %s -> %s\n", src, dest), file = stderr())
  }
}