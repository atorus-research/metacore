#!/usr/bin/env python3
"""Stage 6 — record commit provenance for a validation run.

Writes <run-dir>/git_metadata.json: which commit was validated, by whom, and
whether the working tree was clean at the time. Stage 7 reads this file for §1
of the report and for its "Working tree clean" criterion.

Capture this for the repository holding the metadata under validation. Where
the metadata and the validation framework live apart, the metadata commit is
the one that matters — pass --repo explicitly rather than relying on the
current directory.

Usage:
    python armada_record_git.py --run-dir "$RUN" [--repo PATH]

Exit codes:
    0  metadata captured
    2  usage error, or the path given is not a git repository
    3  captured, but the tree is dirty or has no commits — not submittable
"""

import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


def git(repo: str, *args: str):
    """Run a git command in `repo`, returning stripped stdout or None on failure.

    None rather than an exception: a fresh branch legitimately has no HEAD, and
    that must be recorded as a finding rather than crash the stage.
    """
    try:
        proc = subprocess.run(
            ["git", "-C", repo, *args],
            capture_output=True, text=True, check=False,
        )
    except FileNotFoundError:
        print("Error: git not found on PATH", file=sys.stderr)
        sys.exit(2)
    return proc.stdout.strip() if proc.returncode == 0 else None


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Stage 6 — record commit provenance into the run directory",
        epilog="Never captures ADO_PAT or any other credential.",
    )
    parser.add_argument("--run-dir", required=True,
                        help="Shared validation run directory")
    parser.add_argument("--repo", default=".",
                        help="Repository to capture (default: current directory). "
                             "Point this at the metadata repository.")
    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    if not run_dir.is_dir():
        print(f"Error: run directory not found: {run_dir}", file=sys.stderr)
        return 2

    if git(args.repo, "rev-parse", "--git-dir") is None:
        print(f"Error: not a git repository: {args.repo}", file=sys.stderr)
        return 2

    head = git(args.repo, "rev-parse", "HEAD")
    porcelain = git(args.repo, "status", "--porcelain") or ""

    # Strip the two status columns and any quoting git applies to paths with
    # spaces. Renames ("R  old -> new") keep the whole record; the file list is
    # evidence of what differed, not a machine-consumed path list.
    changed = [line[3:].strip().strip('"')
               for line in porcelain.splitlines() if line.strip()]

    meta = {
        "repository_root": git(args.repo, "rev-parse", "--show-toplevel"),
        "commit_hash": head,
        "commit_short": git(args.repo, "rev-parse", "--short", "HEAD"),
        "commit_message": git(args.repo, "log", "-1", "--pretty=%s"),
        "commit_date": git(args.repo, "log", "-1", "--pretty=%cI"),
        "author_name": git(args.repo, "log", "-1", "--pretty=%an"),
        "author_email": git(args.repo, "log", "-1", "--pretty=%ae"),
        "branch": git(args.repo, "rev-parse", "--abbrev-ref", "HEAD"),
        "has_uncommitted_changes": bool(changed),
        "uncommitted_files": changed,
        "validation_timestamp": datetime.now(timezone.utc)
                                        .astimezone()
                                        .isoformat(timespec="seconds"),
    }

    if head is None:
        meta["_capture_warning"] = (
            "Branch has NO COMMITS. There is no commit hash describing what was "
            "validated, so this run is not reproducible and must not be submitted. "
            "Commit the metadata and re-run the pipeline from Stage 1."
        )

    out = run_dir / "git_metadata.json"
    out.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    print(f"wrote {out}")
    print(f"  commit_hash             = {meta['commit_hash']}")
    print(f"  branch                  = {meta['branch']}")
    print(f"  has_uncommitted_changes = {str(meta['has_uncommitted_changes']).lower()}")
    print(f"  uncommitted_files       = {len(changed)}")

    # A dirty or commitless tree is captured honestly and flagged. The non-zero
    # exit lets a caller gate on it; Stage 7 reports it either way.
    if head is None or changed:
        print("\nNOT SUBMITTABLE — the commit hash does not describe what was "
              "validated. Commit and re-run from Stage 1.", file=sys.stderr)
        return 3

    return 0


if __name__ == "__main__":
    sys.exit(main())
