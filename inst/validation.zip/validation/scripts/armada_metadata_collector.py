#!/usr/bin/env python3
"""
ARMADA Metadata Collector

Recursively collects all linked metadata files for a given output_id (main_aom),
enabling comprehensive validation against requirements extracted from ADO work items.

This module replaces the R ARMADAValidation package functionality for the skill-based
validation approach, focusing on:
  1. Finding and loading all linked metadata for an output
  2. Organizing metadata by entity type
  3. Building a metadata graph for traceability
  4. Preparing metadata for validation against requirements
"""

import os
import json
import yaml
from pathlib import Path
from typing import Dict, List, Tuple, Any, Set, Optional
from dataclasses import dataclass, field, asdict
from collections import defaultdict


@dataclass
class MetadataEntity:
    """Represents a single metadata file and its content."""
    uuid: str
    entity_type: str
    file_path: str
    data: Dict[str, Any]
    id_field: Optional[str] = None
    entity_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, filtering sensitive fields."""
        return {
            'uuid': self.uuid,
            'entity_type': self.entity_type,
            'file_path': self.file_path,
            'entity_id': self.entity_id,
            'data': self.data
        }


@dataclass
class MetadataGraph:
    """Represents the complete linked metadata structure for an output."""
    output_id: str
    root_file: str
    entities: Dict[str, MetadataEntity] = field(default_factory=dict)
    links: Dict[str, List[str]] = field(default_factory=dict)  # uuid -> [linked_uuids]
    entity_type_index: Dict[str, List[str]] = field(default_factory=lambda: defaultdict(list))

    def add_entity(self, entity: MetadataEntity) -> None:
        """Add an entity to the graph."""
        self.entities[entity.uuid] = entity
        self.entity_type_index[entity.entity_type].append(entity.uuid)

    def add_link(self, from_uuid: str, to_uuids: List[str]) -> None:
        """Record a link relationship."""
        if from_uuid not in self.links:
            self.links[from_uuid] = []
        self.links[from_uuid].extend(to_uuids)

    def get_entities_by_type(self, entity_type: str) -> List[MetadataEntity]:
        """Get all entities of a specific type."""
        uuids = self.entity_type_index.get(entity_type, [])
        return [self.entities[uuid] for uuid in uuids if uuid in self.entities]

    def get_linked_entities(self, uuid: str) -> List[MetadataEntity]:
        """Get all entities linked from a given UUID."""
        linked_uuids = self.links.get(uuid, [])
        return [self.entities[uid] for uid in linked_uuids if uid in self.entities]

    def to_dict(self) -> Dict[str, Any]:
        """Convert graph to dictionary for JSON export."""
        return {
            'output_id': self.output_id,
            'root_file': self.root_file,
            'total_entities': len(self.entities),
            'entity_counts': {
                entity_type: len(uuids)
                for entity_type, uuids in self.entity_type_index.items()
            },
            'entities': {
                uuid: entity.to_dict()
                for uuid, entity in self.entities.items()
            },
            'links': self.links
        }


class ARMADAMetadataCollector:
    """Collects and organizes all linked metadata for a given ARMADA output."""

    # Map of entity types to their ID field names (for indexing)
    ENTITY_ID_FIELDS = {
        'main_aom': 'outputID',
        'section_aom': 'sectionID',
        'column_aom': 'columnID',
        'column_group_aom': 'columnGroupID',
        'title_foot_aom': 'titleFootnoteID',
        'label_aom': 'labelID',
        'format_aom': 'formatID',
        'format_group': 'formatGroupID',
        'range_check': 'rangeCheckID',
        'method': 'methodID',
        'methodgroup': 'methodGroupID',
        'var_group': 'varGroupID',
        'where_clause': 'whereClauseID',
        'duplication': 'duplicationID',
        'duplicationitem': 'duplicationItemID',
        'codelist': 'codelistID',
        'codelistitem': 'codelistItemID',
        'led': 'id',
        'arm': 'armID',
    }

    def __init__(self, metadata_path: str):
        """Initialize collector with metadata root path."""
        self.metadata_path = metadata_path
        self.uuid_to_file_cache = {}

    def find_file_by_uuid(self, uuid: str) -> Optional[str]:
        """Find a metadata file by UUID across all directories.
        
        Uses internal cache to avoid repeated filesystem traversals.
        """
        if uuid in self.uuid_to_file_cache:
            return self.uuid_to_file_cache[uuid]

        for root, dirs, files in os.walk(self.metadata_path):
            for file in files:
                if file.startswith(uuid) and file.endswith('.yaml'):
                    file_path = os.path.join(root, file)
                    self.uuid_to_file_cache[uuid] = file_path
                    return file_path

        self.uuid_to_file_cache[uuid] = None
        return None

    def parse_uuid_list(self, value: Any) -> List[str]:
        """Parse comma or star-separated UUIDs from a string value."""
        if not isinstance(value, str):
            return []
        # Handle both * and , as separators
        parts = value.replace(',', '*').split('*')
        return [p.strip() for p in parts if p.strip()]

    def get_entity_type(self, file_path: str) -> str:
        """Extract entity type from file path."""
        return os.path.basename(os.path.dirname(file_path))

    def read_yaml_file(self, file_path: str) -> Dict[str, Any]:
        """Read and parse a YAML file."""
        try:
            with open(file_path) as f:
                data = yaml.safe_load(f)
                if data is None:
                    return {}
                # Handle list format (single-entity lists)
                if isinstance(data, list) and len(data) > 0:
                    data = data[0]
                # Ensure dict format
                if not isinstance(data, dict):
                    return {'value': data}
                return data
        except Exception as e:
            print(f"Warning: Could not read {file_path}: {e}")
            return {}

    def extract_entity_id(self, entity_type: str, data: Dict[str, Any]) -> Optional[str]:
        """Extract the entity ID from metadata, using the appropriate id_field."""
        id_field = self.ENTITY_ID_FIELDS.get(entity_type)
        if id_field and id_field in data:
            value = data[id_field]
            if isinstance(value, str):
                return value
            return str(value)
        return None

    def collect_metadata_for_output(self, output_id: str) -> MetadataGraph:
        """Recursively collect all linked metadata for a given output_id.
        
        Args:
            output_id: The output ID (filename without .yaml extension)
                      from executor/metadata/main_aom/{output_id}.yaml
        
        Returns:
            MetadataGraph: Complete linked metadata structure
            
        Raises:
            FileNotFoundError: If main_aom file not found
        """
        main_aom_file = os.path.join(self.metadata_path, f"main_aom/{output_id}.yaml")

        if not os.path.exists(main_aom_file):
            raise FileNotFoundError(
                f"Output metadata not found: {main_aom_file}\n"
                f"Available outputs in {os.path.dirname(main_aom_file)}: "
                f"{', '.join(os.listdir(os.path.dirname(main_aom_file)))}"
            )

        graph = MetadataGraph(output_id=output_id, root_file=main_aom_file)
        visited: Set[str] = set()

        def traverse(file_path: str) -> None:
            """Recursively traverse metadata references."""
            if file_path in visited:
                return
            visited.add(file_path)

            uuid = Path(file_path).stem
            entity_type = self.get_entity_type(file_path)

            # Read and parse file
            data = self.read_yaml_file(file_path)
            entity_id = self.extract_entity_id(entity_type, data)

            # Create entity
            entity = MetadataEntity(
                uuid=uuid,
                entity_type=entity_type,
                file_path=file_path,
                data=data,
                id_field=self.ENTITY_ID_FIELDS.get(entity_type),
                entity_id=entity_id
            )
            graph.add_entity(entity)

            # Extract and follow UUID references
            if isinstance(data, dict):
                linked_uuids = []
                for key, value in data.items():
                    if isinstance(value, str):
                        uuids = self.parse_uuid_list(value)
                        linked_uuids.extend(uuids)

                if linked_uuids:
                    graph.add_link(uuid, linked_uuids)

                    # Recursively process linked entities
                    for ref_uuid in linked_uuids:
                        ref_file = self.find_file_by_uuid(ref_uuid)
                        if ref_file and ref_file not in visited:
                            traverse(ref_file)

        # Start traversal from main_aom
        traverse(main_aom_file)

        return graph

    def save_graph_to_json(self, graph: MetadataGraph, output_path: str) -> None:
        """Save metadata graph to JSON file."""
        os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
        with open(output_path, 'w') as f:
            json.dump(graph.to_dict(), f, indent=2, default=str)
        print(f"Metadata graph saved to {output_path}")

    def save_entities_by_type(self, graph: MetadataGraph, output_dir: str) -> None:
        """Save entities organized by type to separate JSON files."""
        os.makedirs(output_dir, exist_ok=True)

        for entity_type, uuids in graph.entity_type_index.items():
            entities_data = []
            for uuid in uuids:
                if uuid in graph.entities:
                    entity = graph.entities[uuid]
                    entities_data.append({
                        'uuid': entity.uuid,
                        'entity_id': entity.entity_id,
                        'file_path': entity.file_path,
                        'data': entity.data
                    })

            output_file = os.path.join(output_dir, f"{entity_type}.json")
            with open(output_file, 'w') as f:
                json.dump(entities_data, f, indent=2, default=str)

        print(f"Entities saved to {output_dir}/")

    def get_validation_summary(self, graph: MetadataGraph) -> Dict[str, Any]:
        """Generate a summary of metadata for validation reporting."""
        return {
            'output_id': graph.output_id,
            'root_file': graph.root_file,
            'total_entities': len(graph.entities),
            'entity_breakdown': {
                entity_type: len(uuids)
                for entity_type, uuids in graph.entity_type_index.items()
            },
            'sections': [
                {
                    'uuid': entity.uuid,
                    'id': entity.entity_id,
                    'label': entity.data.get('sectionLabel'),
                    'analyses': entity.data.get('analyses')
                }
                for entity in graph.get_entities_by_type('section_aom')
            ],
            'methods': [
                {
                    'uuid': entity.uuid,
                    'id': entity.entity_id,
                    'label': entity.data.get('methodLabel'),
                    'description': entity.data.get('description')
                }
                for entity in graph.get_entities_by_type('method')
            ]
        }


def main():
    """CLI entry point for metadata collection."""
    import sys
    import argparse

    parser = argparse.ArgumentParser(
        description='Collect linked ARMADA metadata for validation',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Collect metadata and show summary
  python armada_metadata_collector.py dv_t01_sum_impo_prot_dev_armada

  # Save to JSON
  python armada_metadata_collector.py dv_t01_sum_impo_prot_dev_armada \\
    --graph /tmp/metadata_graph.json

  # Save by entity type
  python armada_metadata_collector.py dv_t01_sum_impo_prot_dev_armada \\
    --by-type /tmp/metadata/by_type/
        """
    )
    parser.add_argument('output_id', help='Output ID to collect metadata for')
    parser.add_argument('--metadata-path', default='/mnt/code/executor/metadata',
                       help='Path to metadata root (default: /mnt/code/executor/metadata)')
    parser.add_argument('--graph', help='Save complete graph to JSON file')
    parser.add_argument('--by-type', help='Save entities organized by type to directory')
    parser.add_argument('--summary', action='store_true', help='Show validation summary')

    args = parser.parse_args()

    # Validate metadata path
    if not os.path.exists(args.metadata_path):
        print(f"Error: Metadata path not found: {args.metadata_path}", file=sys.stderr)
        sys.exit(1)

    try:
        collector = ARMADAMetadataCollector(args.metadata_path)
        graph = collector.collect_metadata_for_output(args.output_id)

        print(f"\n{'=' * 80}")
        print(f"ARMADA METADATA COLLECTION: {args.output_id}")
        print(f"{'=' * 80}\n")
        print(f"✓ Total entities collected: {len(graph.entities)}")
        print(f"\nBreakdown by entity type:")
        for entity_type in sorted(graph.entity_type_index.keys()):
            count = len(graph.entity_type_index[entity_type])
            print(f"  • {entity_type}: {count}")

        if args.summary:
            summary = collector.get_validation_summary(graph)
            print(f"\n{'=' * 80}")
            print("VALIDATION SUMMARY")
            print(f"{'=' * 80}\n")
            print(json.dumps(summary, indent=2, default=str))

        if args.graph:
            collector.save_graph_to_json(graph, args.graph)

        if args.by_type:
            collector.save_entities_by_type(graph, args.by_type)

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
