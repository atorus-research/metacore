#!/usr/bin/env python3
"""armada_lint_card.py — validate a TFL card before running the pipeline.

Reads a card written in the machine-readable format and checks it against
templates/tfl-requirement-schema.yaml, then prints the requirements Stage 1
would generate from it.

The point is to fail loudly here rather than silently in Stage 1. Today an
unrecognised heading on a card produces no requirement and no warning (gap D6),
and the run proceeds to report full coverage of an incomplete requirement set.
An unrecognised `requirement:` type is an error in this linter.

Usage:
    python armada_lint_card.py <card.md> [--schema <schema.yaml>] [--json <out>]

Exit codes:
    0  no errors (warnings may be present)
    1  errors found
    2  usage error — card or schema unreadable
"""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

# Only ```yaml fences are requirement blocks. An untagged ``` fence is an
# ordinary code sample — shell commands, examples — and is left alone.
FENCE_RE = re.compile(r'^```ya?ml\s*$')
FENCE_END_RE = re.compile(r'^```\s*$')
SECTION_RE = re.compile(r'^#{1,6}\s*Section\s+(\d+)\s*[—–-]\s*(.+?)\s*$')
VARIABLE_SPEC_RE = re.compile(r'^[A-Za-z0-9_.]+/[A-Za-z0-9_.]+/[A-Za-z0-9_.]+$')

RESERVED_KEYS = {'requirement', 'context', 'rationale'}


class Finding:
    """An error or warning, anchored to a line so the author can find it."""

    def __init__(self, level: str, line: int, message: str):
        self.level = level
        self.line = line
        self.message = message

    def __str__(self) -> str:
        return f"  {self.level.upper():<7} line {self.line:>4}  {self.message}"


class CardLinter:
    def __init__(self, schema: Dict[str, Any]):
        self.schema = schema
        self.types = schema.get('requirement_types', {})
        self.context_types = schema.get('context_types', {})
        self.section_rules = schema.get('sections', {})
        self.findings: List[Finding] = []
        self.requirements: List[Dict[str, Any]] = []
        self.context: List[Dict[str, Any]] = []
        self.sections_seen: Dict[int, str] = {}

    # ── reporting ──────────────────────────────────────────────────────────
    def error(self, line: int, message: str):
        self.findings.append(Finding('error', line, message))

    def warn(self, line: int, message: str):
        self.findings.append(Finding('warning', line, message))

    @property
    def errors(self) -> List[Finding]:
        return [f for f in self.findings if f.level == 'error']

    @property
    def warnings(self) -> List[Finding]:
        return [f for f in self.findings if f.level == 'warning']

    # ── extraction ─────────────────────────────────────────────────────────
    def extract_blocks(self, text: str) -> List[Tuple[int, str, Optional[int]]]:
        """Return (line_number, block_text, section_number) for each fenced block.

        A block belongs to the most recent "Section N — Title" heading above it;
        blocks before any such heading are output-level.
        """
        blocks = []
        current_section: Optional[int] = None
        in_fence = False
        fence_start = 0
        buffer: List[str] = []

        for i, raw in enumerate(text.splitlines(), start=1):
            if not in_fence:
                m = SECTION_RE.match(raw)
                if m:
                    current_section = int(m.group(1))
                    self.sections_seen[current_section] = m.group(2)
                    continue
                if FENCE_RE.match(raw):
                    in_fence, fence_start, buffer = True, i, []
                continue

            if FENCE_END_RE.match(raw):
                blocks.append((fence_start, '\n'.join(buffer), current_section))
                in_fence = False
                continue

            buffer.append(raw)

        if in_fence:
            self.error(fence_start, "Unclosed code fence — the block is not parsed.")
        return blocks

    # ── value checking ─────────────────────────────────────────────────────
    def check_value(self, line: int, where: str, spec: Dict[str, Any], value: Any) -> bool:
        vtype = spec.get('type')

        if vtype == 'string':
            if not isinstance(value, str) or not value.strip():
                self.error(line, f"{where}: expected a non-empty string, got {value!r}.")
                return False

        elif vtype == 'integer':
            if isinstance(value, bool) or not isinstance(value, int):
                self.error(line, f"{where}: expected a whole number, got {value!r}.")
                return False

        elif vtype == 'boolean':
            if not isinstance(value, bool):
                self.error(line, f"{where}: expected true or false, got {value!r}. "
                                 f"Quoted 'yes'/'no' are strings, not booleans.")
                return False

        elif vtype == 'string_list':
            if not isinstance(value, list) or any(not isinstance(v, str) for v in value):
                self.error(line, f"{where}: expected a list of strings, got {value!r}.")
                return False
            if not value and not spec.get('allow_empty'):
                self.error(line, f"{where}: list must not be empty.")
                return False

        elif vtype == 'integer_list':
            if not isinstance(value, list) or any(
                    isinstance(v, bool) or not isinstance(v, int) for v in value):
                self.error(line, f"{where}: expected a list of whole numbers, got {value!r}.")
                return False

        elif vtype == 'enum':
            allowed = spec.get('values', [])
            if value not in allowed:
                self.error(line, f"{where}: {value!r} is not one of {allowed}.")
                return False

        elif vtype == 'variable_spec':
            if not isinstance(value, str) or not VARIABLE_SPEC_RE.match(value):
                self.error(line, f"{where}: expected NUM/CODE/DECODE, e.g. "
                                 f"TRT01PN/NA/TRT01P — got {value!r}.")
                return False

        elif vtype == 'by_variables':
            if not isinstance(value, list) or not value:
                self.error(line, f"{where}: expected a non-empty list of "
                                 f"{{variable, full_matrix}} entries.")
                return False
            for idx, entry in enumerate(value, start=1):
                if not isinstance(entry, dict):
                    self.error(line, f"{where}[{idx}]: expected a mapping with "
                                     f"'variable' and 'full_matrix'.")
                    return False
                var = entry.get('variable')
                if not isinstance(var, str) or not VARIABLE_SPEC_RE.match(var):
                    self.error(line, f"{where}[{idx}].variable: expected NUM/CODE/DECODE, "
                                     f"got {var!r}.")
                    return False
                if not isinstance(entry.get('full_matrix'), bool):
                    self.error(line, f"{where}[{idx}].full_matrix: expected true or false, "
                                     f"got {entry.get('full_matrix')!r}.")
                    return False
                unknown = set(entry) - {'variable', 'full_matrix'}
                if unknown:
                    self.warn(line, f"{where}[{idx}]: ignored key(s) {sorted(unknown)}.")

        else:
            self.warn(line, f"{where}: schema declares unknown value type {vtype!r}; "
                            f"value not checked.")
        return True

    # ── block checking ─────────────────────────────────────────────────────
    def lint_block(self, line: int, raw: str, section: Optional[int]):
        try:
            data = yaml.safe_load(raw)
        except yaml.YAMLError as e:
            self.error(line, f"Block is not valid YAML: {str(e).splitlines()[0]}")
            return

        if data is None:
            self.warn(line, "Empty block — ignored.")
            return
        if not isinstance(data, dict):
            self.error(line, "Block must be a mapping of keys to values.")
            return

        if 'context' in data:
            self.lint_context_block(line, data)
            return

        req_type = data.get('requirement')
        if req_type is None:
            self.error(line, "Block has neither 'requirement:' nor 'context:'. "
                             "Add one, or remove the fence so it reads as prose.")
            return

        spec = self.types.get(req_type)
        if spec is None:
            known = ', '.join(sorted(self.types))
            self.error(line, f"Unknown requirement type {req_type!r}. Known types: {known}.")
            return

        # Scope: section types need a section heading above them, output types must not.
        scope = spec.get('scope')
        if scope == 'section' and section is None:
            self.error(line, f"'{req_type}' is a section-level requirement but no "
                             f"'Section N — Title' heading precedes it.")
            return
        if scope == 'output' and section is not None:
            self.error(line, f"'{req_type}' is an output-level requirement but appears "
                             f"under Section {section}. Move it above the sections.")
            return

        fields = spec.get('fields', {})
        supplied = {k: v for k, v in data.items() if k not in RESERVED_KEYS}

        for name, fspec in fields.items():
            if name not in supplied:
                if fspec.get('required'):
                    self.error(line, f"'{req_type}' is missing required field '{name}' "
                                     f"({fspec.get('summary', '')}).")
                continue
            self.check_value(line, f"{req_type}.{name}", fspec, supplied[name])

        for name in supplied:
            if name not in fields:
                self.error(line, f"'{req_type}' has no field '{name}'. Fields: "
                                 f"{', '.join(sorted(fields))}.")

        # Qualifiers describe HOW a requirement is asserted rather than being a
        # requirement themselves — display_label.form selects which of the three
        # label patterns applies. They ride along on the block's requirements.
        qualifiers = {name: supplied[name] for name, fspec in fields.items()
                      if fspec.get('qualifier') and name in supplied}

        scope_prefix = 'output' if scope == 'output' else f'section-{section}'
        for name, fspec in fields.items():
            if name not in supplied or fspec.get('qualifier'):
                continue
            suffix = fspec.get('id_suffix')
            req_id = f"{scope_prefix}-{req_type}" + (f"-{suffix}" if suffix else "")
            self.requirements.append({
                'id': req_id,
                'type': req_type,
                'field': name,
                'value': supplied[name],
                'qualifiers': qualifiers,
                'metadata_path': fspec.get('metadata_path', ''),
                'rationale': data.get('rationale'),
                'line': line,
                'section': section,
            })

    def lint_context_block(self, line: int, data: Dict[str, Any]):
        ctype = data.get('context')
        if ctype not in self.context_types:
            known = ', '.join(sorted(self.context_types))
            self.error(line, f"Unknown context type {ctype!r}. Known types: {known}.")
            return
        if not isinstance(data.get('text'), str) or not data['text'].strip():
            self.error(line, f"context '{ctype}' needs a non-empty 'text:' value.")
            return
        self.context.append({'type': ctype, 'text': data['text'].strip(), 'line': line})

    # ── whole-card checks ──────────────────────────────────────────────────
    def lint_card(self, text: str):
        blocks = self.extract_blocks(text)

        if not blocks:
            self.error(1, "No fenced requirement blocks found. This card is in the "
                          "legacy prose format — Stage 1 will fall back to heading "
                          "parsing, which drops anything it does not recognise.")
            return

        for line, raw, section in blocks:
            self.lint_block(line, raw, section)

        self.check_duplicate_ids()
        self.check_sections()

    def check_duplicate_ids(self):
        seen: Dict[str, int] = {}
        for req in self.requirements:
            if req['id'] in seen:
                self.error(req['line'], f"Duplicate requirement ID '{req['id']}' — also "
                                        f"produced at line {seen[req['id']]}. One of the "
                                        f"two blocks will be lost.")
            else:
                seen[req['id']] = req['line']

    def check_sections(self):
        if not self.sections_seen:
            self.warn(1, "No sections found. Correct for some listings; unexpected for a table.")
            return

        numbers = sorted(self.sections_seen)
        expected = list(range(1, len(numbers) + 1))
        if numbers != expected:
            self.error(1, f"Section numbering must be contiguous from 1. Found {numbers}; "
                          f"Stage 2 compares this count against section_aom entities.")

        required = set(self.section_rules.get('required_types', []))
        for number in numbers:
            present = {r['type'] for r in self.requirements if r['section'] == number}
            for missing in sorted(required - present):
                self.error(1, f"Section {number} ({self.sections_seen[number]}) is missing "
                              f"a required '{missing}' block.")

    # ── output ─────────────────────────────────────────────────────────────
    def report(self, card_path: Path) -> str:
        out = [f"Linting {card_path}", "=" * 72, ""]

        if self.findings:
            out.append(f"{len(self.errors)} error(s), {len(self.warnings)} warning(s):")
            out.append("")
            for f in sorted(self.findings, key=lambda f: (f.line, f.level)):
                out.append(str(f))
            out.append("")
        else:
            out.append("No errors, no warnings.")
            out.append("")

        out.append(f"Sections: {len(self.sections_seen)}")
        for n in sorted(self.sections_seen):
            count = len([r for r in self.requirements if r['section'] == n])
            out.append(f"  {n}. {self.sections_seen[n]}  ({count} requirement(s))")
        out.append("")

        output_reqs = [r for r in self.requirements if r['section'] is None]
        section_reqs = [r for r in self.requirements if r['section'] is not None]
        out.append(f"Requirements Stage 1 would generate: {len(self.requirements)} "
                   f"({len(output_reqs)} output-level, {len(section_reqs)} section-level)")
        out.append("")
        for req in self.requirements:
            value = req['value']
            rendered = json.dumps(value) if not isinstance(value, str) else value
            if len(rendered) > 58:
                rendered = rendered[:57] + "…"
            out.append(f"  {req['id']:<38} {rendered}")
        out.append("")

        out.append(f"Context entries (no requirement, no test): {len(self.context)}")
        for c in self.context:
            out.append(f"  {c['type']:<38} {c['text'][:58].strip()}…")

        return "\n".join(out)

    def as_dict(self) -> Dict[str, Any]:
        return {
            'errors': [{'line': f.line, 'message': f.message} for f in self.errors],
            'warnings': [{'line': f.line, 'message': f.message} for f in self.warnings],
            'sections': self.sections_seen,
            'requirements': self.requirements,
            'context': self.context,
        }


def main() -> int:
    parser = argparse.ArgumentParser(description="Lint a TFL card against the requirement schema.")
    parser.add_argument('card', help="Path to the card (markdown)")
    parser.add_argument('--schema', help="Path to tfl-requirement-schema.yaml")
    parser.add_argument('--json', help="Also write the lint result as JSON")
    args = parser.parse_args()

    card_path = Path(args.card)
    if not card_path.is_file():
        print(f"Error: card not found: {card_path}", file=sys.stderr)
        return 2

    schema_path = Path(args.schema) if args.schema else (
        Path(__file__).resolve().parent.parent / 'templates' / 'tfl-requirement-schema.yaml')
    if not schema_path.is_file():
        print(f"Error: schema not found: {schema_path}", file=sys.stderr)
        return 2

    try:
        schema = yaml.safe_load(schema_path.read_text(encoding='utf-8'))
    except yaml.YAMLError as e:
        print(f"Error: schema is not valid YAML: {e}", file=sys.stderr)
        return 2

    linter = CardLinter(schema)
    linter.lint_card(card_path.read_text(encoding='utf-8'))

    print(linter.report(card_path))

    if args.json:
        Path(args.json).write_text(json.dumps(linter.as_dict(), indent=2, default=str),
                                   encoding='utf-8')
        print(f"\nJSON written to {args.json}")

    if linter.errors:
        print(f"\nFAILED — {len(linter.errors)} error(s). Fix the card before running Stage 1.",
              file=sys.stderr)
        return 1

    print("\nOK — card is machine-readable and complete.")
    return 0


if __name__ == '__main__':
    sys.exit(main())
