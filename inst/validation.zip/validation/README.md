# ARMADA Metadata Validation

End-to-end validation of ARMADA metadata for a clinical TFL, from the specification in an ADO card through to a regulatory validation summary.

**This is the only document you need to run the pipeline.** Each stage has a skill file with the detail; this page is the sequence.

---

## The seven stages

Every stage reads and writes **one shared run directory**. That directory is the complete evidence package for a validation run.

```
ADO card (spec + mockshell)
    │
 1  Generate requirements ─────────────► <run-dir>/requirements.json
    │
 2  Collect metadata ──────────────────► <run-dir>/metadata.json
    │                                    <run-dir>/metadata_snapshot/
 3  Generate tests (agentic) ──────────► tests/testthat/test-armada-<tfl>.R
    │                                    (in the package, not the run dir)
 4  Run tests ─────────────────────────► <run-dir>/junit/*.xml
    │
 5  Convert to LEDs and execute ───────► <run-dir>/execution.json + execution.log
    │                                    plus ARDs and PDF under /mnt/data
 6  Record environment ────────────────► <run-dir>/git_metadata.json
    │                                    <run-dir>/environment.json
    │                                    <run-dir>/renv.lock
 7  Generate validation summary ───────► <run-dir>/validation-report.md
```

Only the generated test files live outside the run directory — testthat requires them in `tests/testthat/`.

| Stage | Skill | Mechanism |
|---|---|---|
| 1 | [`01-generate-requirements.md`](skills/01-generate-requirements.md) | `armada_validate.sh` |
| 2 | [`02-collect-metadata.md`](skills/02-collect-metadata.md) | `armada_metadata_collector.py` |
| 3 | [`03-generate-tests.md`](skills/03-generate-tests.md) | **Agent** |
| 4 | [`04-run-tests.md`](skills/04-run-tests.md) | `tests/run_tests.R` |
| 5 | [`05-execute-leds.md`](skills/05-execute-leds.md) | `armada_executor.py` |
| 6 | [`06-record-environment.md`](skills/06-record-environment.md) | `armada_record_environment.sh` |
| 7 | [`07-validation-summary.md`](skills/07-validation-summary.md) | `unified_report_generator.py` |

Stages 1 and 2 are independent and may run in either order. Everything else is sequential. Stage 5 is **not** gated on Stage 4 passing — a failed test tells you the metadata is wrong, and you still want to know whether it executes.

---

## Prerequisites

```bash
# Stage 1 — ADO access. Set in Domino: Account Settings → Environment Variables.
export ADO_PAT="your-personal-access-token"     # never commit this

# Stage 5 — Mercury Executor
export MERCURY_EXECUTOR_PATH="/path/to/executor"
export LED_TOOLING_PATH="/path/to/tooling"
export MERCURY_METADATA_PATH="/mnt/code/executor/metadata"
export MERCURY_ARMAOM_METADATA_PATH="/mnt/code/executor/metadata"   # stage 2 uses this name
export DOMINO_PROJECT_NAME="project-name"
```

Python 3.8+ with `requests`, `pyyaml`. R with `testthat`, `jsonlite`.

---

## Run it

Substituting your own ADO URL and output ID throughout.

### Stage 0 — Create the run directory

Everything below uses `$RUN`. Create it once, and use the same value for all seven stages.

```bash
export RUN=/mnt/code/validation_runs/dv_t01_$(date +%Y%m%d-%H%M%S)
mkdir -p "$RUN"
echo "$RUN"
```

Nothing enforces a naming convention — the scripts use whatever path you give them. A timestamped directory per run keeps history; a fixed directory per TFL overwrites in place. Your choice.

### Stage 1 — Generate requirements

```bash
cd /mnt/imported/code/standard-led

./.github/scripts/armada_validate.sh \
  "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" \
  json "$RUN/requirements.json"

# CHECK — must not be 0
jq '.sections | length, (.requirements | length)' "$RUN/requirements.json"
```

The parser fails silently on a card it cannot read. Count the requirements on the card and compare.

### Stage 2 — Collect metadata

```bash
python ./.github/scripts/armada_metadata_collector.py \
  dv_t01_sum_impo_prot_dev_armada \
  --graph "$RUN/metadata.json"

# Optional but recommended — freeze the YAML that was validated
Rscript ./.github/scripts/copy_from_json.R "$RUN/metadata.json" "$RUN/metadata_snapshot"

# CHECK — section counts from stages 1 and 2 must agree
jq '.entity_counts.section_aom' "$RUN/metadata.json"
jq '.sections | length'         "$RUN/requirements.json"
```

### Stage 3 — Generate tests (agentic)

Invoke a general-purpose agent with `skills/03-generate-tests.md`, the two JSON files, **and the value of `$RUN`** — the agent must bake that absolute path into the generated helper, since the tests read those files at run time from a different working directory. It writes:

- `tests/testthat/helper-armada-<tfl>.R`
- `tests/testthat/test-armada-<tfl>.R`

```bash
# CHECK — the helper points at THIS run
grep ARMADA_RUN_DIR tests/testthat/helper-armada-dv_t01.R

# CHECK — every requirement has a test
for id in $(jq -r '.requirements[].id' "$RUN/requirements.json"); do
  grep -q "$id" tests/testthat/test-armada-dv_t01.R || echo "MISSING TEST: $id"
done
```

Read the generated tests. They are the validation logic — if they assert the wrong thing, a pass means nothing.

### Stage 4 — Run tests

The runner lives in `tests/`, not `.github/scripts/`, and must be run from the package root:

```bash
cd <package-root>
Rscript tests/run_tests.R --junit --run-dir "$RUN" --filter "armada-dv_t01"
echo "exit=$?"

# CHECK — a filter matching nothing prints "No test files matched" and exits 0
ls -l "$RUN/junit/"
```

`--junit` requires `--run-dir` and exits 2 without it. Console-only runs (no `--junit`) need neither.

Failures here are information, not a blocker. Record them and continue.

### Stage 5 — Convert to LEDs and execute

```bash
cd /mnt/code

python /mnt/imported/code/standard-led/.github/scripts/armada_executor.py \
  --output-id dv_t01_sum_impo_prot_dev_armada \
  --run-dir "$RUN" \
  --verbose true

# CHECK — the PDF is from THIS run, not a leftover
jq '.status, .failed_commands' "$RUN/execution.json"
find /mnt/data/${DOMINO_PROJECT_NAME}/prod -name "*.pdf" -newermt "-1 hour"
```

`execution.json` is written on failure as well as success. On success the executor also runs Stage 7 automatically with the same run directory.

### Stage 6 — Record environment

```bash
./.github/scripts/armada_record_environment.sh --run-dir "$RUN" \
  --repo /path/to/metadata-repo --project /path/to/package-root
echo "exit=$?"     # 0 clean · 2 usage · 3 captured but not submittable
```

Point `--repo` at the **metadata** repository — that is the commit that matters. Exit 3 means the evidence was captured honestly but the tree was dirty, had no commits, or no lockfile was produced.

```bash
# CHECK — must be false for anything heading to submission
git status --porcelain
jq '.commit_hash, .has_uncommitted_changes' "$RUN/git_metadata.json"
jq '.packages | length'                     "$RUN/environment.json"

# CHECK — the lockfile is the primary environment evidence
jq '.Packages | length' "$RUN/renv.lock"
```

`renv.lock` is required. If the project is not renv-managed, record why in `$RUN/renv-not-used.txt` so the absence is a decision rather than an omission. Stage 7 does not read or check the lockfile — this check is the only control.

### Stage 7 — Generate the validation summary

```bash
python ./.github/scripts/unified_report_generator.py \
  dv_t01_sum_impo_prot_dev_armada \
  --run-dir "$RUN"
echo "exit=$?"
```

The verdict is derived from the evidence, and the exit code follows it:

| Verdict | Exit | Meaning |
|---|---|---|
| `PASS` | 0 | All seven criteria met |
| `FAIL` | 1 | A criterion is not met — the evidence shows a problem |
| `INCOMPLETE` | 3 | Evidence missing — **no determination possible** |
| — | 2 | Usage error |

The criteria: evidence complete · tests executed · all tests passed · skips justified · every requirement has ≥1 test · execution succeeded · working tree clean. §6 of the report shows each with its reasoning, and unmet criteria are printed to stderr.

**A `PASS` means every checkable criterion is met — not that the metadata is fit for submission.** The report states findings only; the fitness determination is yours to make and record.

The report's structure is fixed by [`templates/validation-report-template.md`](templates/validation-report-template.md) — six sections, their sources, and the verdict rules. Every producer follows it, so two reports are always comparable.

The finished run directory is the submission package:

```bash
ls -R "$RUN"
```

---

## Known issues

These are live defects. Full register in [`REFACTOR_PLAN.md`](REFACTOR_PLAN.md) §5.

| # | Issue | Effect |
|---|---|---|
| **D6** | Stage 1 requires a literal em-dash for section headings and silently drops unrecognised keys | A card it cannot parse yields zero requirements with no error. Stage 7 catches the consequence — zero requirements means zero coverage — but the root cause is silent. |
| **D5** | Stage 7's type table counts a `type` key Stage 1 never emits | "Overview by Type" shows one `unknown` row |
| **D10** | Stage 5 treats any same-named PDF found under `/mnt/data` as success | A stale PDF reads as a successful run — check timestamps |
| **D11** | Stage 5 auto-runs Stage 7 only on success | Run Stage 7 explicitly after a failure |
| **D7** | `.env` loading in `run_tests.R` is a no-op | Export what you need manually |
| — | Summary has no full requirements list | `jq -r '.requirements[] \| "- \(.id): \(.documentation)"' "$RUN/requirements.json"` |

**Fixed:** D1 (verdict now derived from the evidence, fitness assertion removed), D2 and D3 (stage 4 and 5 outputs land where stage 7 reads), D4 (both git key spellings accepted), D12 (coverage arithmetic guarded), D-d (enriched JUnit XML — `ArmadaJunitReporter` emits test IDs and requirement/assertion/expected/actual/UUID properties, and stage 7 renders a per-assertion traceability matrix whose `Comparison` column states how expected relates to actual, so a passing membership or pattern assertion is not misread as a mismatch).

---

## Worked example — DV_T01

Illustrative figures from one historical run of `dv_t01_sum_impo_prot_dev_armada`. **These are not targets.** Requirement counts, section counts and pass rates differ for every TFL, and listings and figures will not follow this shape at all.

| Stage | Result |
|---|---|
| 1 | 20 requirements — 2 output-level, plus 6 types × 3 sections |
| 2 | 48 entities across 19 entity types |
| 3 | 20 `test_that()` blocks |
| 4 | 9 passed, 9 failed — `by_variable` expected TRT01PN/P but metadata had TRT01AN/A; `denominator` expected enrolled-counts but metadata had safety-counts |
| 5 | 4 ARMs + 1 AOM converted and executed, ~24s |

The Stage 4 failures are the system working: the metadata genuinely did not match the specification. The resolution is to confirm the requirement, then correct the metadata — never to relax the test.

---

## Repository layout

The validation framework sits inside a larger package. Stages 1, 2, 5 and 7 live under `.github/`; stage 4's runner lives under `tests/` alongside the suite it runs.

```
<package-root>/
├── .github/
│   ├── README.md                     ← this file
│   ├── skills/
│   │   ├── 01-generate-requirements.md
│   │   ├── 02-collect-metadata.md
│   │   ├── 03-generate-tests.md
│   │   ├── 04-run-tests.md
│   │   ├── 05-execute-leds.md
│   │   ├── 06-record-environment.md
│   │   └── 07-validation-summary.md
│   ├── scripts/
│   │   ├── armada_validator.py           stage 1 — ADO fetch and parse
│   │   ├── armada_validate.sh            stage 1 — CLI
│   │   ├── armada_metadata_collector.py  stage 2 — graph collection
│   │   ├── armada_collect_metadata.sh    stage 2 — CLI
│   │   ├── copy_from_json.R              stage 2 — YAML snapshot
│   │   ├── armada_executor.py            stage 5 — LED conversion and execution
│   │   ├── armada_execute.sh             stage 5 — CLI
│   │   ├── armada_record_git.py          stage 6 — commit provenance
│   │   ├── armada_record_env.R           stage 6 — R environment + renv.lock
│   │   ├── armada_record_environment.sh  stage 6 — CLI, runs both
│   │   └── unified_report_generator.py   stage 7 — summary
│   └── templates/
│       ├── tfl-spec-template.md           the spec shape stage 1 expects
│       ├── validation-report-template.md  the report contract stage 7 implements
│       └── example-validation-report.md    a conforming report to compare against
└── tests/
    ├── run_tests.R                   stage 4 — testthat + JUnit
    ├── testthat/                     stage 3 writes generated tests here
    │   ├── helper-armada-junit.R     enriched JUnit reporter — shared, not generated
    │   ├── helper-armada-<tfl>.R
    │   └── test-armada-<tfl>.R
    └── test-results/                 stage 4 writes JUnit XML here
```

Stage 3 has no script — it is the agentic stage. Every other stage has one.

`tests/run_tests.R` derives the package root from its own location, so it must stay in `tests/`. Do not consolidate it into `.github/scripts/` without also changing that resolution.

---

## Troubleshooting

| Symptom | Cause |
|---|---|
| `ADO_PAT environment variable not set` | Export it, or set it in your Domino profile |
| `401 Unauthorized` from ADO | PAT expired or lacks work-item read permission |
| `404 Not Found` from ADO | Wrong work item ID or project name in the URL |
| Requirements file has 0 sections | Card uses a hyphen where the parser needs an em-dash, or non-whitelisted keys (D6) |
| `Output metadata not found` | Output ID does not match a file in `main_aom/`. `ls /mnt/code/executor/metadata/main_aom/` |
| Stage 1 and 2 section counts differ | Card and metadata disagree — resolve before generating tests |
| `No test files matched filter` | Filter typo, or you ran it from somewhere other than the package root — exits 0, so read the console, not the exit code |
| `Section N not found in metadata` | Test derives section number from `main_aom.sections` ordering; check the AOM has that many sections |
| `UUID not resolved` | Entity missing from the graph — re-run Stage 2 and check its stderr for read warnings |
| `--junit requires --run-dir` | Stage 4 will not guess an artifact location. Pass `--run-dir "$RUN"`. |
| Tests error opening `requirements.json` | The helper's `ARMADA_RUN_DIR` points at a different run. Regenerate Stage 3 with the current `$RUN`. |
| Report banner says INCOMPLETE | A stage did not write to `$RUN`. The missing files are listed in the banner. |
| `KeyError: MERCURY_EXECUTOR_PATH` | Stage 5 environment variables not exported |
| `make: *** [convert_1arm] Error 2` | Re-run with `--dry-run true` to see the exact command, then run it by hand |
| Execution "succeeded" but the PDF is old | Stale PDF matched the name search (D10) — check timestamps |
| Summary sections 3 or 4 empty | Path mismatches D2/D3 — copy the files as shown in Stage 7 |
