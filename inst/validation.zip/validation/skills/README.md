# ARMADA Metadata Validation Skill

**Status:** ✅ Implemented and tested with ADO work item [2385276](https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276)

## Overview

This skill provides a framework for **extracting metadata validation requirements** from ARMADA display/table/listing schema specifications stored in Azure DevOps work items. The generated requirements:

- Are structured with **unique IDs**, **human-readable documentation**, **test code**, and **rationale**
- Serve as input to a future **JUnit-based validation test suite** that will compare actual ARMADA metadata YAML against the schema specifications
- Are output in multiple formats (**JSON, CSV, Java test class stubs**) for integration into CI/CD pipelines

---

## Quick Start

### 1. Ensure ADO_PAT is Set

```bash
# In Domino: Account Settings → Environment Variables → Add Variable
# Or temporarily in session:
export ADO_PAT="your-personal-access-token"

# Verify it's set
echo "ADO_PAT is set: $([ -z "$ADO_PAT" ] && echo NO || echo YES)"
```

### 2. Extract Requirements from an ADO Work Item

```bash
# Print JSON to stdout (default)
./.github/scripts/armada_validate.sh "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276"

# Save JSON to file
./.github/scripts/armada_validate.sh "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" json /tmp/requirements.json

# Save CSV for spreadsheets
./.github/scripts/armada_validate.sh "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" csv /tmp/requirements.csv

# Save Java test class template
./.github/scripts/armada_validate.sh "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" java /tmp/DvT01ValidationTest.java

# Verify files were created
ls -lh /tmp/requirements.*
```

### 3. Use from Python

```python
import sys
sys.path.insert(0, '.github/scripts')

from armada_validator import fetch_ado_workitem, parse_armada_schema
import json

# Fetch and parse
wi = fetch_ado_workitem("https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276")
schema = parse_armada_schema(wi['description'])

# Review requirements
for req in schema['requirements']:
    print(f"{req['id']}: {req['documentation']}")
    print(f"Test: {req['test_code']}\n")
```

---

## Architecture

### Data Flow

```
Azure DevOps Work Item (HTML Description)
          ↓
    fetch_ado_workitem()  →  Convert HTML to plain text
          ↓
 parse_armada_schema()   →  Extract sections & requirements
          ↓
 JSON/CSV/Java Output   →  Ready for CI/CD integration
```

### Key Components

| Component | Purpose |
|-----------|---------|
| `SKILL.md` | Skill documentation (usage, API reference, troubleshooting) |
| `armada_validator.py` | Core Python module with all functions |
| `armada_validate.sh` | CLI wrapper script with multiple output formats |
| `README.md` | This file (quick start, examples, architecture) |

---

## Requirement Structure

Each extracted requirement has this structure:

```json
{
  "id": "section-domain",
  "documentation": "Requirement uses ADDV domain for data source.",
  "test_code": "assertEquals(\"ADDV\", metadata.domain);",
  "description": "Domain: ADDV"
}
```

| Field | Purpose | Example |
|-------|---------|---------|
| **id** | Unique identifier (kebab-case) | `section-domain`, `title-title` |
| **documentation** | Plain English statement of what must be true | "Requirement uses ADDV domain..." |
| **test_code** | JUnit pseudocode for future test generation | `assertEquals("ADDV", metadata.domain);` |
| **description** | Raw schema text (key-value pair) | `Domain: ADDV` |

---

## Example: DV_T01 Table Schema

### Input (ADO Work Item 2385276)

The work item describes a table specification with multiple sections:

- **Title**: "Summary of Important Protocol Deviations"
- **Analysis Set**: Enrolled (ENRLFL = "Y")
- **Treatment**: TRT01PN/TRT01P (parallel study, Treatment A and B only)
- **Sections** (3-level hierarchy):
  1. Any Important Protocol Deviations (distinct subjects, percentage)
  2. By Category (group by ACAT1)
  3. By Category and Coded Term (group by ACAT1 and ADECOD)

### Generated Requirements (Sample)

```json
{
  "schema_title": "Summary of Important Protocol Deviations",
  "schema_type": "table",
  "requirements": [
    {
      "id": "title-title",
      "documentation": "Display title must be: Summary of Important Protocol Deviations",
      "test_code": "// Validate: Title\nassertNotNull(metadata);",
      "description": "Title: Summary of Important Protocol Deviations"
    },
    {
      "id": "section-domain",
      "documentation": "Requirement uses ADDV domain for data source.",
      "test_code": "assertEquals(\"ADDV\", metadata.domain);",
      "description": "Domain: ADDV"
    },
    {
      "id": "section-subset",
      "documentation": "Data must be subset/filtered using: ADIMPTFL EQ \"Y\"",
      "test_code": "assertTrue(metadata.subset.contains(\"ADIMPTFL EQ \\\"Y\\\"\"));",
      "description": "Subset: ADIMPTFL EQ \"Y\""
    },
    {
      "id": "section-by_variable",
      "documentation": "Table must present data stratified by: TRT01PN/NA/TRT01P (Full Matrix: Yes)",
      "test_code": "// Validate: By Variable\nassertNotNull(metadata);",
      "description": "By Variable: TRT01PN/NA/TRT01P (Full Matrix: Yes)"
    }
  ]
}
```

**Total generated: 19 requirements** extracted from the work item description.

---

## Output Formats

### JSON (Default)

```bash
./.github/scripts/armada_validate.sh "https://..." > requirements.json
```

**Use when:** Integrating with CI/CD pipelines, storing results, further processing

**Output:**
```json
{
  "schema_title": "...",
  "schema_type": "table",
  "sections": [...],
  "requirements": [...]
}
```

### CSV

```bash
./.github/scripts/armada_validate.sh "https://..." csv > requirements.csv
```

**Use when:** Importing into spreadsheets, creating validation matrices, documentation

**Columns:** `requirement_id`, `documentation`, `test_code`, `description`

### Java Test Template

```bash
./.github/scripts/armada_validate.sh "https://..." java > SchemaValidationTest.java
```

**Use when:** Generating stub test classes for future JUnit integration

**Output:** Full Java class with:
- Package declaration
- Required imports
- Test method stubs (one per requirement)
- Pseudocode from `test_code` field

**Example generated method:**
```java
@Test
public void test_section_domain() {
    // Requirement: section-domain
    assertEquals("ADDV", metadata.domain);
}
```

---

## Python API Reference

### `fetch_ado_workitem(url, pat=None)`

Fetch an ADO work item and convert HTML description to plain text.

```python
from armada_validator import fetch_ado_workitem

wi = fetch_ado_workitem(
    "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276"
)

print(wi['title'])        # "[VALIDATE] DV_T01 – Summary of Important Protocol Deviations"
print(wi['description'])  # Plain-text schema description
print(wi['state'])        # "In Progress"
```

**Parameters:**
- `url` (str): Full ADO work item URL
- `pat` (str, optional): ADO Personal Access Token (defaults to `ADO_PAT` env var)

**Returns:**
```python
{
    'id': int,
    'title': str,
    'description': str,  # Plain text (HTML converted)
    'type': str,         # "Task", "Feature", etc.
    'state': str,        # "Active", "In Progress", etc.
    'assigned_to': str   # Display name or "Unassigned"
}
```

**Raises:** `ValueError` if ADO_PAT not set; `requests.HTTPError` if API fails.

---

### `parse_armada_schema(description_text)`

Parse plain-text ARMADA schema description and extract requirements.

```python
from armada_validator import parse_armada_schema

schema = parse_armada_schema(plain_text_description)

# Top-level requirements (all, flattened)
for req in schema['requirements']:
    print(f"{req['id']}: {req['documentation']}")

# Organized by section
for section in schema['sections']:
    print(f"\n{section['title']}")
    for req in section['requirements']:
        print(f"  - {req['id']}")
```

**Parameters:**
- `description_text` (str): Plain-text schema description (output from `fetch_ado_workitem`)

**Returns:**
```python
{
    'schema_title': str,
    'schema_type': str,  # "table", "listing", "figure"
    'display_name': str,
    'sections': [        # Grouped by major section
        {
            'id': str,
            'title': str,
            'requirements': [...]
        }
    ],
    'requirements': [    # All requirements, flattened
        {
            'id': str,
            'documentation': str,
            'test_code': str,
            'description': str
        }
    ]
}
```

---

### `generate_junit_template(schema_dict, package_name="com.armada.validation")`

Generate a JUnit test class template from parsed requirements.

```python
from armada_validator import generate_junit_template

template = generate_junit_template(schema, package_name="com.mycompany.armada")

print(template['class_name'])   # "SummaryOfImportantProtocolDeviationsValidationTest"
print(template['java_source'])  # Full Java class source
```

**Parameters:**
- `schema_dict` (dict): Output from `parse_armada_schema`
- `package_name` (str): Java package name (default: `com.armada.validation`)

**Returns:**
```python
{
    'class_name': str,
    'package': str,
    'imports': list,
    'test_methods': [
        {
            'name': str,
            'code': str,
            'requirement_id': str
        }
    ],
    'java_source': str  # Full JUnit class
}
```

---

### `requirements_to_json(schema_dict, indent=2)`

Serialize requirements to formatted JSON string.

```python
from armada_validator import requirements_to_json
import json

json_str = requirements_to_json(schema)
with open('requirements.json', 'w') as f:
    f.write(json_str)
```

---

### `requirements_to_csv(schema_dict)`

Serialize requirements to CSV format.

```python
from armada_validator import requirements_to_csv

csv_str = requirements_to_csv(schema)
with open('requirements.csv', 'w') as f:
    f.write(csv_str)
```

---

### `save_requirements(schema_dict, output_file, format='json')`

Save requirements directly to a file in the specified format.

```python
from armada_validator import fetch_ado_workitem, parse_armada_schema, save_requirements

wi = fetch_ado_workitem("https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276")
schema = parse_armada_schema(wi['description'])

# Save as JSON
save_requirements(schema, '/artifacts/requirements.json', format='json')

# Save as CSV
save_requirements(schema, '/artifacts/requirements.csv', format='csv')

# Save as Java test class
save_requirements(schema, '/artifacts/DvT01ValidationTest.java', format='java')
```

**Parameters:**
- `schema_dict` (dict) — Output from `parse_armada_schema`
- `output_file` (str) — Path to output file (will be created/overwritten)
- `format` (str) — Output format: `json` (default), `csv`, or `java`

**Returns:** None (writes to file directly)

**Raises:** `ValueError` if format unknown; `IOError` if file cannot be written

---

## Integration Points

### 1. CI/CD Pipeline (GitHub Actions)

Generate requirements as an artifact on each commit:

```yaml
- name: Extract ARMADA schema requirements
  run: |
    ./.github/scripts/armada_validate.sh \
      "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" \
      json > ${{ runner.temp }}/requirements.json
    
    cat ${{ runner.temp }}/requirements.json
```

### 2. Documentation

Generate a spreadsheet-friendly CSV:

```bash
./.github/scripts/armada_validate.sh "https://..." csv > \
  "docs/ARMADA_Schema_Requirements_DV_T01.csv"
```

### 3. Test Generation (Future)

Use the Java template to scaffold JUnit tests:

```bash
./.github/scripts/armada_validate.sh "https://..." java > \
  "src/test/java/com/armada/validation/DvT01ValidationTest.java"
```

Then implement the actual assertions by comparing metadata YAML against requirements.

### 4. Validation at Runtime (Future)

Load requirements and validate metadata programmatically:

```python
# Load requirements
schema = parse_armada_schema(description)

# Load ARMADA metadata YAML
metadata = load_armada_yaml("path/to/dv_t01_config.yaml")

# Validate against requirements
for req in schema['requirements']:
    # Check that metadata satisfies requirement
    # Details TBD based on ARMADA metadata structure
    pass
```

---

## Troubleshooting

### ADO_PAT Not Set

**Error:**
```
ValueError: ADO_PAT environment variable not set
```

**Solution:**
Set in Domino profile: *Account Settings → Environment Variables → Add Variable*

Or temporarily in session:
```bash
export ADO_PAT="your-token-here"
```

### 401 Unauthorized

**Error:**
```
requests.exceptions.HTTPError: 401 Client Error: Unauthorized
```

**Causes:**
- Invalid PAT
- Expired token
- Insufficient permissions

**Solution:**
Generate a new PAT with "Read" permission for work items and try again.

### 404 Not Found

**Error:**
```
requests.exceptions.HTTPError: 404 Client Error: Not Found
```

**Causes:**
- Incorrect work item ID
- Wrong project name
- Work item deleted

**Solution:**
Verify the URL in your browser and check that you have access to the project.

### Parsing Issues

**Problem:** Requirements are empty or incomplete

**Cause:** Schema description format doesn't match expected patterns (e.g., "Key: Value")

**Solution:** 
1. Verify the ADO work item has a properly formatted description
2. Check that it follows ARMADA schema documentation conventions
3. File an issue if a new schema format is not being recognized

---

## Future Extensions

### 1. Metadata Validation

Implement runtime validation:

```python
from armada_validator import validate_metadata

results = validate_metadata(
    schema_requirements=schema,
    armada_metadata_yaml="path/to/config.yaml"
)

print(f"Passed: {results['passed']}")
print(f"Failed: {results['failed']}")
for failure in results['failures']:
    print(f"  - {failure['requirement_id']}: {failure['error']}")
```

### 2. Custom Validators

Allow domain-specific validation logic:

```python
from armada_validator import register_validator

@register_validator("domain")
def validate_domain_is_addv(metadata, requirement):
    return metadata.get('domain') == 'ADDV'
```

### 3. Report Generation

Generate compliance reports:

```python
from armada_validator import generate_compliance_report

report = generate_compliance_report(
    schema=schema,
    metadata=metadata,
    format="html"  # or "pdf", "markdown"
)
```

---

## Related Skills

- **ado-workitems** — Create, read, update ADO cards programmatically
- **r-development** — Implement ARMADA metadata generation and validation in R
- **pr-description** — Document validation changes in pull requests

---

## File Structure

```
.github/
├── skills/
│   └── armada-validation/
│       ├── SKILL.md          # Detailed skill documentation
│       └── README.md         # This file (quick start, examples)
└── scripts/
    ├── armada_validate.sh    # CLI wrapper script
    └── armada_validator.py   # Core Python module
```

---

## License & Support

This skill is part of the **PDCA** project and uses the **ARMADA** metadata framework for clinical trial displays.

For issues or questions:
1. Check the troubleshooting section above
2. Review the `SKILL.md` file for detailed API reference
3. Verify your ADO_PAT is valid and you have project access
4. File an issue on the project board

---

## Change Log

### v1.0 (2026-08-17)

- ✅ Initial implementation
- ✅ `fetch_ado_workitem()` — Fetch and parse ADO work items
- ✅ `parse_armada_schema()` — Extract requirements from schema descriptions
- ✅ `generate_junit_template()` — Generate test class stubs
- ✅ `armada_validate.sh` — CLI with JSON/CSV/Java output formats
- ✅ Tested with DV_T01 schema (ADO #2385276)
- ⏳ `validate_metadata()` — Runtime validation against actual ARMADA metadata (future)
- ⏳ Custom validator registration (future)
- ⏳ Compliance reporting (future)

