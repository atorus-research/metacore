# TFL Requirements Template

**Table/Figure/Listing ID:** [Fill in]  
**Study:** [Fill in]  
**Date Created:** [Fill in]

---

## Display

| Field | Value |
|-------|-------|
| ID | DV_T01 |
| Title | Summary of Important Protocol Deviations |
| Type | Table |
| Study Design | Parallel |

---

## Analysis Set

**Analysis Set Name:** Enrolled

**Population Filter:** ENRLFL EQ "Y"

---

## Treatment

**Treatment Variable:** TRT01PN/TRT01P

**Treatment Columns:**
- Treatment A
- Treatment B

**Include Total Column:** false

**Include No-Treatment Column:** false

---

## Column Structure

### Stub Columns (Row Labels)
- Category (from ACAT1)
- Coded Term (from ADECOD)

### Result Columns (Data)
- Treatment A (N, %)
- Treatment B (N, %)

**Big N Source:** analysis-set-enrolled-counts

---

## Footnotes

_No footnotes defined_

---

## Sections

### Section 1: Any Important Protocol Deviations

| Field | Value |
|-------|-------|
| Display Label | Any Important Protocol Deviations |
| Method | Number of distinct subjects (USUBJID) with at least one important protocol deviation, and percentage |
| By Variable | TRT01PN/NA/TRT01P (Full Matrix: Yes) |
| Domain | ADDV |
| Subset | ADIMPTFL EQ "Y" |
| Denominator | Big N (analysis-set-enrolled-counts) |

### Section 2: By Category

| Field | Value |
|-------|-------|
| Display Label | <category name> (one row per observed deviation category, e.g. "NOT WITHDRAWN AFTER DEVELOPING WITHDRAWAL CRITERIA") |
| Method | Number of distinct subjects (USUBJID) with at least one deviation in the category, and percentage |
| By Variable | TRT01PN/NA/TRT01P (Full Matrix: Yes) * NA/NA/ACAT1 (Full Matrix: No) |
| Domain | ADDV |
| Subset | ADIMPTFL EQ "Y" |
| Denominator | Big N (analysis-set-enrolled-counts) |

### Section 3: By Category and Coded Term

| Field | Value |
|-------|-------|
| Display Label | <coded term> (indented under each category, one row per observed coded term, e.g. "NOT DISCONTINUED FROM STUDY TREATMENT") |
| Method | Number of distinct subjects (USUBJID) with at least one deviation matching the category and coded term, and percentage |
| By Variable | TRT01PN/NA/TRT01P (Full Matrix: Yes) * NA/NA/ACAT1 (Full Matrix: No) * NA/NA/ADECOD (Full Matrix: No) |
| Domain | ADDV |
| Subset | ADIMPTFL EQ "Y" |
| Denominator | Big N (analysis-set-enrolled-counts) |

---

## Data Handling

**Missing Values:** .missing row (if missing coded terms encountered)

**Sort Order:** Descending by total incidence, then alphabetical

**Subject Counting:** Counted once per category/coded term regardless of multiplicity

---

## Known Issues

- [ ] Column header should be two lines with Coded Term indented
- [ ] First row should be capitalized: 'Any Important Protocol Deviations'
- [ ] Analysis set should be included in title
