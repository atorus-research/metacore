# Stage 3 — Generate Validation Tests (Agentic)

## Purpose

An agent reads the requirements file and the metadata graph, and writes bespoke R testthat tests that assert the metadata satisfies each requirement.

## Position

Stage 3 of 7. Consumes **Stage 1** (`requirements.json`) and **Stage 2** (`metadata.json`). Feeds **Stage 4 (Run Tests)**.

This is where the intelligence lives. Tests are **generated per TFL**, not hard-coded — the requirement set, section count and metadata shape differ for every table, listing and figure, so a fixed validator cannot work. The agent's job is to bridge a plain-English requirement to a specific path through a UUID graph.

## Inputs

| Input | Path | From |
|---|---|---|
| Requirements | `<run-dir>/requirements.json` | Stage 1 |
| Metadata graph | `<run-dir>/metadata.json` | Stage 2 |
| This skill | `.github/skills/03-generate-tests.md` | — |

The agent must be told the run directory, and **must bake that absolute path into the generated helpers** — the tests read these files at run time, in a separate R process, from a working directory of `tests/testthat/`.

## Procedure

Invoke a general-purpose agent with all three inputs. It must produce two files:

- `tests/testthat/helper-armada-<tfl>.R` — metadata navigation helpers
- `tests/testthat/test-armada-<tfl>.R` — one `test_that()` block per requirement

### What the agent must do

1. **Read every requirement** in `requirements.json` — both `output_requirements` and `sections[].requirements[]`.
2. **Map each requirement type to a metadata path** (see mapping below).
3. **Derive section numbers** from the order of UUIDs in `main_aom.sections` — `section_aom` entities carry no number of their own.
4. **Resolve UUIDs** against `metadata$entities`, splitting `*`-separated strings.
5. **Write one `test_that()` block per requirement**, named with the requirement ID so Stage 7 can match test to requirement.
6. **Write every substantive assertion as `expect_armada_*()`** (see below), so the requirement ID, expected, actual, metadata UUID and metadata path reach the JUnit XML. These wrappers also compose the failure message, so a failure stays diagnosable without re-reading the graph.

### Evidence-carrying assertions

`helper-armada-junit.R` provides three wrappers. Each records evidence and asserts in one call:

```r
expect_armada_equal(
  requirement_id = "section-1-by_variable",
  test_id        = "ARMADA-DV_T01-1-BY_VARIABLE-01",
  expected       = c("TRT01PN/NA/TRT01P"),
  actual         = get_by_variable_specs(metadata, arm),
  uuid           = split_uuids(arm$byVariables),
  metadata_path  = "arm$byVariables -> var_group$variableNum/Code/Decode",
  label          = "By-variable mismatch in Section 1."
)
```

| Wrapper | For |
|---|---|
| `expect_armada_equal()` | Exact match, scalar or vector |
| `expect_armada_match()` | Regex match — pass `expected_display` for the human-readable form |
| `expect_armada_in()` | Membership: the expected value appears in a resolved set (Pattern 3 labels) |

**Never split recording from asserting.** The wrappers set a single evidence slot immediately before firing their expectation, and the reporter consumes and clears it. That is what guarantees evidence lands on the right `<testcase>`; a separate "record then assert" pair can drift silently and attach a claim to the wrong assertion.

Precondition guards (`expect_false(is.null(...))`) may stay bare. They produce a `<testcase>` with no properties, which Stage 7 counts and reports rather than mistaking for evidence.

**Test ID scheme** — `ARMADA-<TFL>-<SECTION>-<TYPE>-<INDEX>`, uppercase, derived from the requirement ID:

```
section-1-by_variable  →  ARMADA-DV_T01-1-BY_VARIABLE-01   (first assertion)
                          ARMADA-DV_T01-1-BY_VARIABLE-02   (second assertion)
output-footnotes       →  ARMADA-DV_T01-OUTPUT-FOOTNOTES-01
```

IDs must be unique within the suite. Stage 7 cites them in the assertion matrix and in the failure list.

### Requirement type → metadata path

**Output-level:**

| Requirement | Path |
|---|---|
| `output-title` | `main_aom.outputLabel` |
| `output-footnotes` | `main_aom.footnotes` → footnote entity → `footnoteText` |

**Section-level:**

| Requirement | Path |
|---|---|
| `display_label` | `section_aom.labels` → `label_aom.displayLabel` — **three patterns, see below** |
| `method` | `section_aom.analyses` → `arm.methodGroupID` → `methodgroup.methods` → `method.methodLabel` |
| `by_variable` | `arm.byVariables` → `var_group` |
| `domain` | `arm.domain` |
| `subset` | `arm.subSet` → `where_clause.whereClause` |
| `denominator` | `arm.denomID` or `main_aom.bigNAnalysisID` |

### Edge cases the agent must handle

- **Optional fields** — not every arm has a `subSet`. Skip where the requirement itself says the field is optional; do **not** silently pass. **Every skip must state a reason** — Stage 7 fails the run on any skip without one:

  ```r
  # Correct — the reason is recorded in the JUnit XML and the summary
  skip("subSet is optional for this arm and is absent from the metadata")

  # Fails Stage 7's "Skips justified" criterion
  skip("")
  ```
- **Unresolvable UUIDs** — fail with the UUID in the message, not `NULL`-dereference.
- **Multi-value fields** — `"uuid1*uuid2*uuid3"` must be split.
- **Entity-type confusion** — `arm` vs `analysis`, `label_aom` vs `label_foot_aom`.
- **Whatever requirements are actually present.** Do not assume 6 types × 3 sections; that is what DV_T01 happened to produce. Listings and figures differ.

---

## Display Label Metadata Patterns (Critical for Future TFLs)

> Preserved verbatim from the original skill. This is the hardest part of the mapping and must not be paraphrased.

The trickiest requirement type is `display_label` because there are **three distinct patterns** in ARMADA metadata. The agent must correctly identify which pattern applies and validate accordingly.

### Pattern 1: Literal Text Label (Simple Match)

**When:** First section of table; requirement specifies exact label text
**Example:** `display_label: "Any Important Protocol Deviations"`

**Metadata path:**
```
section_aom.labels (UUID)
  → label_aom.displayLabel (text field)
```

**Test logic:**
```r
section_aom <- get_section_aom(metadata, section_number)
label_uuid <- section_aom$labels
label_aom <- get_entity(metadata, label_uuid)$data
actual <- label_aom$displayLabel
expected <- "Any Important Protocol Deviations"  # from requirement

expect_equal(actual, expected, info = paste0(
  "Display label mismatch.\n  Expected: '", expected, 
  "'\n  Actual: '", actual, "'"))
```

**Key insight:** This is a direct text match. If label resolves to `"Statistic"` or `NULL`, continue to Pattern 2.

---

### Pattern 2: Format-Based Label (Dynamic from Report Format)

**When:** When `displayLabel` is `"Statistic"` or `NULL`; label should come from the report format definition
**Example:** Section headers that use standard format labels like `"n (%)"` or `"n (Range)"`

**Metadata path:**
```
section_aom.resultFormat (UUID)
  → format_group.formats (list of UUIDs)
    → format.reportLabel (actual label text)
```

**Test logic:**
```r
section_aom <- get_section_aom(metadata, section_number)

# If displayLabel is "Statistic" or NULL, follow format_group path
result_format_uuid <- section_aom$resultFormat
format_group <- get_entity(metadata, result_format_uuid)$data
format_uuid <- strsplit(format_group$formats, "\\*", fixed = TRUE)[[1]][1]
format_entity <- get_entity(metadata, trimws(format_uuid))$data
actual <- format_entity$reportLabel  # e.g., "n (%)"

expect_equal(actual, expected, info = paste0(
  "Format-based label mismatch.\n  Path: resultFormat → format_group → format.reportLabel",
  "\n  Expected: '", expected, "'\n  Actual: '", actual, "'"))
```

**Key insight:** When simple displayLabel fails, always check if `resultFormat` provides the actual label via format_group hierarchy.

---

### Pattern 3: Dynamic/Template Label (Variable Group Reference)

**When:** Requirement text is a template like `"<category name>"` or `"<coded term>"`; actual label will be populated from dataset variables at runtime
**Example:** 
- Section 2: `"<category name> (one row per observed deviation category, e.g. 'NOT WITHDRAWN ...')"`
- Section 3: `"<coded term> (indented under each category, one row per observed coded term, e.g. 'NOT DISCONTINUED ...')"`

**Metadata path:**
```
label_aom.value (UUID to variable_group)
  → variable_group.variableNum or variableCode or variableDecode
    ↓
Compare against expected variables from section's by_variable requirement
```

**Test logic:**
```r
# Step 1: Parse requirement to extract expected variable(s)
requirement_text <- "NA/NA/ACAT1 (Full Matrix: No)"  # from requirement
expected_var <- "ACAT1"  # extract variable name

# Step 2: Get section's label
section_aom <- get_section_aom(metadata, section_number)
label_uuid <- section_aom$labels  # e.g., "416087bf-8cdf-4bc3-b400-71a0873d7e52"
label_aom <- get_entity(metadata, label_uuid)$data

# Step 3: Resolve label.value to variable group
var_group_uuid <- label_aom$value  # e.g., "432154cd-8957-4c8b-9a31-00ab5b815e5e"
var_group <- get_entity(metadata, var_group_uuid)$data

# Step 4: Check if expected variable is in the group
vars_in_group <- c(var_group$variableNum, var_group$variableCode, var_group$variableDecode)
if (expected_var %in% vars_in_group) {
  # PASS: Label correctly references the expected variable group
} else {
  # FAIL: Label doesn't reference the expected variable
}

expect_true(expected_var %in% vars_in_group, info = paste0(
  "Label does not reference expected variable.\n  Expected: '", expected_var,
  "'\n  Variables in group: ", paste(vars_in_group, collapse = ", ")))
```

**Multi-tier example (Section 3):**
```r
# Section 3 may have TWO labels: one for category, one for coded term
# Labels: "432154cd-8957-4c8b-9a31-00ab5b815e5e | 67d541c4-cd08-4cf0-b28c-30ad1dc54c10"
# Expected variables: ACAT1 and ADECOD (from by_variable requirement)

label_uuids <- strsplit(label_string, "\\|")[[1]]
label_uuids <- trimws(label_uuids)
expected_vars <- c("ACAT1", "ADECOD")

for (i in seq_along(expected_vars)) {
  label_uuid <- label_uuids[i]
  label_aom <- get_entity(metadata, label_uuid)$data
  var_group_uuid <- label_aom$value
  var_group <- get_entity(metadata, var_group_uuid)$data
  
  vars_in_group <- c(var_group$variableNum, var_group$variableCode, var_group$variableDecode)
  
  expect_true(expected_vars[i] %in% vars_in_group, info = paste0(
    "Tier ", i, " label does not reference '", expected_vars[i], "'"))
}
```

**Key insight:** Template labels are NOT tested by text match; instead, validate that the label correctly **links to the expected variable group**. The actual label text will come from the dataset at runtime.

---

## How to Distinguish the Patterns

When generating tests for `display_label`:

1. **Read requirement text** from requirements.json → `requirement.documentation`
2. **If requirement text is literal** (e.g., `"Any Important Protocol Deviations"` or `"n (%)"`)
   → Use **Pattern 1 or 2** (try Pattern 1 first, fallback to Pattern 2 if displayLabel is "Statistic" or NULL)
3. **If requirement text is a template** (contains `"<"` and `">"`, e.g., `"<category name>"` or `"<coded term>"`)
   → Use **Pattern 3** (extract expected variable(s) from by_variable requirement and validate variable_group reference)

---

## Outputs

### `tests/testthat/helper-armada-<tfl>.R`

```r
# ── ARMADA METADATA HELPERS ──────────────────────────────────────────────────
# Auto-generated helpers for ARMADA validation
# DO NOT EDIT MANUALLY — regenerate with agent if requirements change.
# ─────────────────────────────────────────────────────────────────────────────

# The run directory is baked in at generation time. Tests execute from
# tests/testthat/ in a separate process, so this MUST be an absolute path.
ARMADA_RUN_DIR <- "/mnt/code/validation_runs/dv_t01_20260818-101500"

load_armada_metadata <- function(
    metadata_file = file.path(ARMADA_RUN_DIR, "metadata.json")) {
  jsonlite::read_json(metadata_file)
}

load_armada_requirements <- function(
    requirements_file = file.path(ARMADA_RUN_DIR, "requirements.json")) {
  jsonlite::read_json(requirements_file)
}

get_entity <- function(metadata, uuid) {
  metadata$entities[[uuid]]
}

get_main_aom <- function(metadata) {
  for (entity in metadata$entities) {
    if (!is.null(entity$entity_type) && entity$entity_type == "main_aom") return(entity$data)
  }
  NULL
}

get_section_aom <- function(metadata, section_number) {
  # Section order is defined ONLY by position in main_aom$sections
  main_aom <- get_main_aom(metadata)
  uuids <- split_uuids(main_aom$sections)
  if (section_number > length(uuids)) return(NULL)
  get_entity(metadata, uuids[section_number])$data
}

split_uuids <- function(uuid_string) {
  if (is.null(uuid_string)) return(character(0))
  trimws(strsplit(as.character(uuid_string), "\\*")[[1]])
}
```

### `tests/testthat/test-armada-<tfl>.R`

```r
# ── ARMADA VALIDATION TESTS ──────────────────────────────────────────────────
# Auto-generated from ADO requirements
# Generated from: <ADO work item URL>
# DO NOT EDIT MANUALLY — regenerate with agent if requirements change.
# ─────────────────────────────────────────────────────────────────────────────

setup({
  metadata     <<- load_armada_metadata()
  requirements <<- load_armada_requirements()
})

test_that("output-title: Output title matches requirement", {
  main_aom <- get_main_aom(metadata)
  expect_false(is.null(main_aom), info = "main_aom not found in metadata")

  expected <- "Summary of Important Protocol Deviations by Treatment Arm"
  actual   <- main_aom$outputLabel

  expect_equal(actual, expected,
    info = paste0("Output title mismatch.",
                  "\n  Expected: '", expected, "'",
                  "\n  Actual: '", actual, "'"))
})

test_that("section-1-domain: Domain matches requirement", {
  section_aom <- get_section_aom(metadata, 1)
  expect_false(is.null(section_aom), info = "Section 1 not found in metadata")

  arm <- get_entity(metadata, section_aom$analyses)$data

  expected <- "ADDV"
  actual   <- arm$domain

  expect_equal(actual, expected,
    info = paste0("Domain mismatch in Section 1.",
                  "\n  Expected: '", expected, "'",
                  "\n  Actual: '", actual, "'"))
})

test_that("section-1-subset: Subset filter is correct", {
  section_aom <- get_section_aom(metadata, 1)
  arm <- get_entity(metadata, section_aom$analyses)$data

  subset_uuid <- arm$subSet
  expect_false(is.null(subset_uuid), info = "Subset not defined for Section 1")

  where_clause <- get_entity(metadata, subset_uuid)$data

  expect_match(where_clause$whereClause, "ADIMPTFL.*EQ.*Y",
    info = paste0("Subset filter does not match requirement.",
                  "\n  Expected to contain: ADIMPTFL EQ \"Y\"",
                  "\n  Actual: '", where_clause$whereClause, "'"))
})

# ... one test_that() block per requirement in requirements.json
```

### Test naming convention

Name each block with the requirement ID as its prefix:

```r
test_that("section-1-display_label: <human description>", { ... })
```

Stage 7 reconstructs the requirement-to-test mapping from this prefix. It normalises both sides first, because testthat rewrites the description into the JUnit `name` attribute, collapsing runs of non-alphanumeric characters into single underscores:

```
test_that("section-1-display_label: label matches")  →  name="section_1_display_label_label_matches"
```

Matching therefore survives the hyphen/underscore difference — but only if the **requirement ID comes first**. Two consequences:

- A test whose name does not begin with a requirement ID is reported as **untraceable**, and its requirement counts as untested.
- **Every requirement must have at least one test.** A requirement with none fails Stage 7's coverage criterion and the whole run reports FAIL.

## Acceptance checks

```bash
# Both files were created
ls -l tests/testthat/{helper,test}-armada-<tfl>.R

# The run directory was baked in, and points at THIS run
grep ARMADA_RUN_DIR tests/testthat/helper-armada-<tfl>.R

# Test count matches requirement count
grep -c 'test_that(' tests/testthat/test-armada-<tfl>.R
jq '.requirements | length' "$RUN/requirements.json"

# Every requirement ID appears in the test file
for id in $(jq -r '.requirements[].id' "$RUN/requirements.json"); do
  grep -q "$id" tests/testthat/test-armada-<tfl>.R || echo "MISSING TEST: $id"
done
```

**Every requirement must have a test.** A requirement with no test is an untested requirement that the Stage 7 summary will nonetheless list as a requirement.

Read the generated tests before running them. They are the validation logic; if they assert the wrong thing, Stage 4 passing means nothing.

## Handover

Stage 4 runs these files with `run_tests.R`. For that to work:

- Files must be in `tests/testthat/` and named `test-*.R` / `helper-*.R` — the runner globs `^test.*\.[Rr]$` and sources `^helper.*\.[Rr]$` first. **The test files live in the package, not the run directory**; only the results land in the run directory.
- `<run-dir>/requirements.json` and `<run-dir>/metadata.json` must still exist when the tests run — the helpers read them at test time, not at generation time.
- `ARMADA_RUN_DIR` in the helper must be an absolute path matching the `--run-dir` passed to Stage 4. A relative path will not resolve: the runner `setwd()`s into `tests/testthat/` first.
- The suite must not call `library()` on anything unavailable in the session; `jsonlite` is required.

## Known gaps

| Ref | Gap |
|---|---|
| — | **Do not treat any pass/fail ratio as expected.** Earlier versions of this documentation instructed the agent to expect "9 PASS / 9 FAIL" for DV_T01. That is a description of one historical run, not a target. Generate tests that assert what the requirements say and let the results fall where they fall. |
| — | The agent must derive section numbers from `main_aom.sections` ordering. Earlier helpers read a `section_number` field on `section_aom`; **no such field exists** in the collected metadata. |
| — | Original documentation was inconsistent about the target language (some passages said Python `unittest`). The pipeline is **R testthat** — `run_tests.R` runs nothing else. |
| **D14** | Ignore the `test_code` field in `requirements.json`. It contains Java pseudocode written against a flat `metadata.domain`-style object that does not exist. |
