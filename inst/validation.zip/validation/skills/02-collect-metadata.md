# Stage 2 — Collect Metadata

## Purpose

Recursively collect every ARMADA metadata entity linked to the target TFL into a single JSON graph, so Stage 3 can navigate it and Stage 4 can assert against it.

## Position

Stage 2 of 7. Consumes the ARMADA metadata tree. Feeds **Stage 3 (Generate Tests)**.

Independent of Stage 1 — the two can run in either order.

## Inputs

| Input | Source | Notes |
|---|---|---|
| Output ID | The target `main_aom` filename without `.yaml` | e.g. `dv_t01_sum_impo_prot_dev_armada` |
| Metadata tree | `/mnt/code/executor/metadata/` | Must contain `main_aom/<output_id>.yaml` |

List available outputs:

```bash
ls /mnt/code/executor/metadata/main_aom/*.yaml | xargs -n1 basename
```

## Procedure

Use the same run directory as Stage 1:

```bash
python ./.github/scripts/armada_metadata_collector.py \
  dv_t01_sum_impo_prot_dev_armada \
  --graph "$RUN/metadata.json"
```

Or via the wrapper, which reads the metadata root from `MERCURY_ARMAOM_METADATA_PATH`:

```bash
./.github/scripts/armada_collect_metadata.sh dv_t01_sum_impo_prot_dev_armada --graph "$RUN/metadata.json"
```

The filename **must** be `metadata.json` — stage 7 looks for exactly that name.

### Optional but recommended — freeze the validated YAML

Copies every source file referenced in the graph into a snapshot directory, giving you the exact metadata that was validated rather than a pointer to a tree that may since have changed:

```bash
Rscript ./.github/scripts/copy_from_json.R "$RUN/metadata.json" "$RUN/metadata_snapshot"
```

Worth doing for anything heading to submission. It lands in the run directory alongside everything else, so the whole directory is the archivable evidence package.

## Outputs

**`<run-dir>/metadata.json`**, plus optionally **`<run-dir>/metadata_snapshot/`**

```json
{
  "output_id": "dv_t01_sum_impo_prot_dev_armada",
  "root_file": "/mnt/code/executor/metadata/main_aom/....yaml",
  "total_entities": 48,
  "entity_counts": { "main_aom": 1, "section_aom": 3, "arm": 3, "method": 4, "label_aom": 3 },
  "entities": {
    "<uuid>": {
      "uuid": "<uuid>",
      "entity_type": "main_aom",
      "file_path": "/mnt/code/executor/metadata/main_aom/....yaml",
      "entity_id": "dv_t01_sum_impo_prot_dev_armada",
      "data": { "outputID": "...", "sections": "uuid1*uuid2*uuid3" }
    }
  },
  "links": { "<uuid>": ["<linked-uuid>"] }
}
```

### How the graph is built

1. Load `main_aom/<output_id>.yaml`.
2. For every string field, split on `*` or `,` and treat each fragment as a candidate UUID.
3. Locate each UUID's file by filename prefix across the whole metadata tree.
4. Recurse, tracking visited files so cycles terminate.

Entity type is derived from the **parent directory name**, so `arm/<uuid>.yaml` → `arm`.

### Entity types you will meet

`main_aom` (root TFL definition) · `section_aom` (one per table section) · `arm` (analysis specs) · `method` / `methodgroup` (statistics) · `label_aom` (row and column labels) · `where_clause` / `range_check` (filters) · `var_group` (stratification variables) · `format_aom` / `format_group` (display formats) · `codelist` / `codelistitem`.

## Acceptance checks

```bash
# Entity count is plausible — DV_T01 collected 48
jq '.total_entities' "$RUN/metadata.json"

# Section count matches the requirements file from Stage 1
jq '.entity_counts.section_aom' "$RUN/metadata.json"
jq '.sections | length'         "$RUN/requirements.json"

# Every entity type present
jq '.entity_counts' "$RUN/metadata.json"
```

**The section counts from Stages 1 and 2 must match.** If the card describes 3 sections and the metadata has 2, Stage 3 will generate tests for a section that does not exist and Stage 4 will fail confusingly.

Watch the collector's stderr for `Warning: Could not read <file>` — an unreadable YAML becomes an empty entity, and any test navigating through it fails for the wrong reason.

## Handover

Stage 3 reads `<run-dir>/metadata.json` and navigates `entities[uuid].data` to find the values each requirement asserts on. The generated R helpers resolve UUIDs against this structure.

For that to work:
- The file must be named `metadata.json` and sit directly in the run directory. The generated helpers take the path as a default argument — Stage 3 must bake in the run directory it was given.
- Multi-value fields are `*`-separated **strings**, not lists — `"uuid1*uuid2*uuid3"`. Stage 3's helpers must split them.
- `section_aom` entities carry **no section number**. Order is defined only by the position of each UUID in `main_aom.sections`. Stage 3 must derive section numbers from that ordering.

## Known gaps

| Ref | Gap |
|---|---|
| **D13** | Three names for one concept: the wrapper reads `MERCURY_ARMAOM_METADATA_PATH`, the executor uses `MERCURY_METADATA_PATH`, and the collector defaults to a hard-coded `/mnt/code/executor/metadata`. Pass `--metadata-path` explicitly if your tree is elsewhere. |
| — | `copy_from_json.R` hard-codes `prefix <- "/mnt/code"` and skips any file outside it, with a warning per file. Metadata stored elsewhere is silently omitted from the snapshot. |
| — | UUID detection is heuristic: any `*`/`,`-separated string fragment matching a filename prefix is followed. A short string that coincidentally prefixes a filename would be traversed. Not observed in practice; be aware when reading unexpected entities in the graph. |
