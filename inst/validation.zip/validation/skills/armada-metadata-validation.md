# Skill: ARMADA Metadata Validation via Agentic Test Generation

This skill covers validating ARMADA metadata against requirements extracted from Azure DevOps work items. Instead of hard-coded validators, an intelligent agent generates bespoke validation tests on the fly based on the requirements file, then executes those tests against the collected metadata.

**Input:**
1. ADO work item URL (e.g., `https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276`)
2. ARMADA output ID (e.g., `dv_t01_sum_impo_prot_dev_armada`)

**Process:**
1. **Extract requirements** from ADO card → `/tmp/requirements.json`
2. **Collect metadata** from ARMADA → `/tmp/metadata.json`
3. **Generate validation tests** (R testthat via agentic skill) → `tests/testthat/test-armada-<tfl>.R`
4. **Execute validation** tests with testthat → console output + JUnit XML results

**Output:**
- `<output_dir>/requirements.json` — extracted requirements (3 sections, 6 requirement types each)
- `<output_dir>/metadata.json` — collected ARMADA metadata (48+ entities)
- `<output_dir>/git_metadata.json` — git commit information for audit trail
- `tests/testthat/test-armada-<tfl>.R` — generated R testthat test suite
- `tests/testthat/helper-armada-<tfl>.R` — helper functions to parse metadata JSON in R
- `tests/documentation/dv_t01-traceability-matrix.md` — detailed traceability with commit info
- Test results via `devtools::test()` / `testthat::test_local()`

---

## Commit Traceability for Regulatory Submissions

**CRITICAL:** Every validation must capture the exact version of metadata that was tested. This provides an **audit trail** for regulatory submissions, proving which commit of the metadata was validated.

### Git Metadata Captured

When validation runs, the following git information is automatically captured and stored in `git_metadata.json`:

```json
{
  "repository_root": "/mnt/code/standard-led",
  "validation_timestamp": "2026-08-17T16:08:09.403832",
  "commit_hash": "a467d08a8e52a5bcd4089f6021ea295c4a9c238f",
  "commit_short": "a467d08",
  "commit_message": "Merge pull request #343 from gsk-tech/adeg-validation...",
  "commit_date": "2026-08-12T12:03:39-04:00",
  "author_name": "Kevin Hudson",
  "author_email": "kevin.j.hudson@gsk.com",
  "branch": "dev",
  "has_uncommitted_changes": true,
  "uncommitted_files": [".github/scripts/...", "tests/testthat/..."]
}
```

### Capturing Git Metadata

```bash
cd /mnt/imported/code/standard-led

# Capture git metadata
python ./.github/scripts/capture_git_metadata.py /tmp/git_metadata.json
```

**Output fields:**
- `commit_hash` — Full commit SHA (use for exact reproducibility)
- `commit_short` — Short SHA (7 chars, human-readable)
- `commit_message` — Commit message
- `commit_date` — ISO format timestamp
- `author_name` / `author_email` — Who made the commit
- `branch` — Branch name (dev, pa_01, etc.)
- `has_uncommitted_changes` — Whether repo has uncommitted changes
- `uncommitted_files` — List of modified files (⚠️ if true, validation is NOT reproducible!)
- `validation_timestamp` — When validation was actually run

### Including in Traceability Matrix

The traceability matrix header must include:

```markdown
# ARMADA Validation Traceability Matrix: DV_T01

**Commit Information:**
| Field | Value |
|-------|-------|
| Repository | `/mnt/imported/code/standard-led` |
| Commit Hash | `a467d08a8e52a5bcd4089f6021ea295c4a9c238f` |
| Commit Short | `a467d08` |
| Branch | `dev` |
| Commit Date | `2026-08-12T12:03:39-04:00` |
| Author | Kevin Hudson (kevin.j.hudson@gsk.com) |
| Message | Merge pull request #343 from gsk-tech/adeg-validation... |
| Uncommitted Changes | ⚠️ YES — 13 files modified |
| Validation Timestamp | 2026-08-17T16:08:09 |

**WARNING:** This validation was run against a repository with uncommitted changes. For regulatory submissions, ensure all changes are committed before validation.
```

### Reproducibility & Regulatory Compliance

**For regulatory submissions, you MUST:**

1. ✅ **Commit all changes** to git before running validation
   ```bash
   git add .
   git commit -m "ADaM ARMADA metadata for Study XYZ v1.0"
   git log -1 --oneline  # Verify commit
   ```

2. ✅ **Capture commit info** during validation
   ```bash
   python ./.github/scripts/capture_git_metadata.py /tmp/git_metadata.json
   ```

3. ✅ **Include commit details** in traceability matrix header
   - Shows exact version of metadata that was tested
   - Provides audit trail for regulators

4. ✅ **Verify no uncommitted changes** before submission
   ```bash
   git status  # Should be clean
   python ./.github/scripts/capture_git_metadata.py /tmp/git_metadata.json | grep uncommitted_changes
   ```

**❌ NEVER** submit validation results from a repository with uncommitted changes.

---

## Workflow

### Step 1: Extract Requirements from ADO

```bash
cd /mnt/imported/code/standard-led

./.github/scripts/armada_validate.sh \
  "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" \
  json \
  /tmp/requirements.json
```

**Output format:**
```json
{
  "schema_title": "Summary of Important Protocol Deviations",
  "schema_type": "table",
  "display_name": "Summary of Important Protocol Deviations by Treatment Arm",
  "output_requirements": [
    {
      "id": "output-title",
      "documentation": "Table title: Summary of Important Protocol Deviations by Treatment Arm",
      "description": "The table's main title displayed above the table"
    },
    {
      "id": "output-footnotes",
      "documentation": [
        "Footnote 1: This analysis includes all subjects in the safety population.",
        "Footnote 2: Protocol deviations are categorized and counted by distinct subjects."
      ],
      "description": "Explanatory text displayed below the table"
    }
  ],
  "sections": [
    {
      "id": "section-1",
      "number": 1,
      "title": "Any Important Protocol Deviations",
      "requirements": [
        {
          "id": "section-1-display_label",
          "documentation": "Display label must be: Any Important Protocol Deviations",
          "test_code": "assertEquals(\"...\", metadata.display_label);",
          "description": "Display label: ..."
        },
        {
          "id": "section-1-method",
          "documentation": "Statistical method: ...",
          "test_code": "assertTrue(metadata.method.contains(...));",
          "description": "Method: ..."
        },
        ...
      ]
    },
    ... (sections 2, 3)
  ]
}
```

**Key points:**
- 3 sections (one per table section from ADO card)
- 6 requirement types per section: `display_label`, `method`, `by_variable`, `domain`, `subset`, `denominator`
- Total: 18 requirement IDs like `section-1-display_label`, `section-2-method`, etc.
- Each requirement includes:
  - `documentation`: what the requirement is
  - `test_code`: Java/pseudo-code hint for generating the test
  - `description`: human-readable summary

---

### Step 2: Collect ARMADA Metadata

```bash
python ./.github/scripts/armada_metadata_collector.py \
  dv_t01_sum_impo_prot_dev_armada \
  --graph /tmp/metadata.json
```

**Output format:**
```json
{
  "output_id": "dv_t01_sum_impo_prot_dev_armada",
  "root_file": "/mnt/code/executor/metadata/main_aom/...",
  "total_entities": 48,
  "entity_counts": {
    "main_aom": 1,
    "section_aom": 3,
    "arm": 3,
    "method": 4,
    "label_aom": 3,
    ...
  },
  "entities": {
    "dv_t01_sum_impo_prot_dev_armada": {
      "entity_type": "main_aom",
      "data": {
        "outputID": "dv_t01_sum_impo_prot_dev_armada",
        "outputLabel": "Summary of Important Protocol Deviations",
        "sections": "uuid1*uuid2*uuid3",
        ...
      }
    },
    ... (48 entities total)
  }
}
```

**Key structure:**
- `main_aom` — the root TFL definition
- `section_aom` — one per table section (3 for DV_T01)
- `arm` — analysis specifications per section
- `method` — statistical methods (counts, percentages, etc.)
- `label_aom` — display labels for rows and columns
- `where_clause` — data filtering logic
- Plus supporting entities: codelists, formats, var_groups, etc.

---

## Output-Level Requirements (Title & Footnotes)

**IMPORTANT:** Beyond the 18 section-level requirements, every table must also validate its **output title** and **output footnotes**. These are critical for regulatory submissions.

### Output-Level Requirement Types

#### 1. Output Title (`output-title`)

**What to validate:**
- The table's main title (displayed above the table)
- Must match what's specified in the ADO requirement

**Metadata path:**
```
main_aom.outputLabel (string)
  or
main_aom.titles (optional, may be more detailed)
```

**Test logic:**
```r
# Get output title from main_aom
main_aom <- get_main_aom(metadata)
expected_title <- "Summary of Important Protocol Deviations by Treatment Arm"
actual_title <- main_aom$outputLabel

# PASS if titles match
expect_equal(actual_title, expected_title, info = paste0(
  "Output title mismatch.\n  Expected: '", expected_title, 
  "'\n  Actual: '", actual_title, "'"))
```

**Requirements.json structure:**
```json
{
  "id": "output-title",
  "documentation": "Table title: Summary of Important Protocol Deviations by Treatment Arm",
  "description": "The table's main title displayed above the table"
}
```

#### 2. Output Footnotes (`output-footnotes`)

**What to validate:**
- Footnotes displayed below the table
- Must include all required explanatory text from requirements
- Can be multiple footnotes (array of strings)

**Metadata path:**
```
main_aom.footnotes (array of footnote UUIDs)
  → footnote entity → footnoteText (string)
  or
main_aom.footerLabels (array of text strings)
```

**Test logic:**
```r
# Get footnotes from main_aom
main_aom <- get_main_aom(metadata)
footnote_uuids <- split_uuids(main_aom$footnotes)

expected_footnotes <- c(
  "This analysis includes all subjects in the safety population.",
  "Protocol deviations are categorized and counted by distinct subjects."
)

# Resolve each footnote UUID and check text
actual_footnotes <- character()
for (uuid in footnote_uuids) {
  footnote_entity <- get_entity(metadata, uuid)$data
  actual_footnotes <- c(actual_footnotes, footnote_entity$footnoteText)
}

# PASS if all expected footnotes are present
for (expected in expected_footnotes) {
  expect_true(any(grepl(expected, actual_footnotes, fixed = TRUE)), info = paste0(
    "Missing expected footnote: '", expected, "'"))
}

# Optionally: check that no unexpected footnotes are present
# expect_equal(length(actual_footnotes), length(expected_footnotes), info = "Footnote count mismatch")
```

**Requirements.json structure:**
```json
{
  "id": "output-footnotes",
  "documentation": [
    "Footnote 1: This analysis includes all subjects in the safety population.",
    "Footnote 2: Protocol deviations are categorized and counted by distinct subjects."
  ],
  "description": "Explanatory text displayed below the table"
}
```

---

### How to Extract Title & Footnotes from ADO

The ADO card describes the output structure. Look for:

1. **Title section** — Usually at top of card or in "Output Definition" section
   - Example: "Table Title: Summary of Important Protocol Deviations by Treatment Arm"
   - Extract this and add as `output-title` requirement

2. **Footnotes section** — Usually at bottom of card
   - Example: "Footnotes: (1) This analysis includes...; (2) Protocol deviations..."
   - Parse each footnote and add as separate entries in `output-footnotes` requirement

---

### Step 3: Generate Validation Tests (Agentic)

This is where the intelligence lives. An agent reads the requirements file and generates Python unittest code that:

1. **Parses each requirement** from the JSON
2. **Interprets the intent** from the documentation
3. **Generates a bespoke test** that validates the corresponding metadata
4. **Handles the metadata structure** (entity types, UUIDs, nested references, etc.)
5. **Creates assertions** that check specific fields

**Example: Generate a test for `section-1-display_label`**

Input requirement:
```json
{
  "id": "section-1-display_label",
  "documentation": "Display label must be: Any Important Protocol Deviations",
  "description": "Display label: Any Important Protocol Deviations"
}
```

Generated test (pseudo-code):
```python
def test_section_1_display_label(self):
    """Validate that section 1 has the correct display label."""
    section_aom = self.get_section_aom(section_number=1)
    self.assertIsNotNone(section_aom, "Section 1 not found in metadata")
    
    # Get the label from the section
    label_uuid = section_aom.get('labels')
    label_aom = self.get_entity(label_uuid)
    self.assertIsNotNone(label_aom, f"Label entity {label_uuid} not found")
    
    actual_label = label_aom.get('displayLabel')
    expected_label = "Any Important Protocol Deviations"
    self.assertEqual(actual_label, expected_label, 
                     f"Display label mismatch: expected '{expected_label}', got '{actual_label}'")
```

**The agent must understand:**
- Requirement types map to metadata fields and entity relationships
- UUIDs must be resolved from the graph
- Optional vs required fields (some arms may not have a subSet)
- Multi-value fields like `sections: "uuid1*uuid2*uuid3"` need splitting
- Error messages must include file locations and metadata paths for debugging

---

### Step 4: Execute Validation Tests

```bash
python /tmp/armada_validation_tests.py -v 2>&1 | tee /tmp/validation_results.json
```

**Output:**
```json
{
  "timestamp": "2026-08-17T14:15:00.123456",
  "test_suite": "ARMADAValidationTests",
  "total_tests": 18,
  "passed": 15,
  "failed": 3,
  "skipped": 0,
  "by_section": {
    "1": { "passed": 6, "failed": 0, "skipped": 0 },
    "2": { "passed": 5, "failed": 1, "skipped": 0 },
    "3": { "passed": 4, "failed": 2, "skipped": 0 }
  },
  "by_type": {
    "display_label": { "passed": 3, "failed": 0, "skipped": 0 },
    "method": { "passed": 3, "failed": 0, "skipped": 0 },
    "by_variable": { "passed": 3, "failed": 0, "skipped": 0 },
    "domain": { "passed": 3, "failed": 0, "skipped": 0 },
    "subset": { "passed": 2, "failed": 1, "skipped": 0 },
    "denominator": { "passed": 1, "failed": 2, "skipped": 0 }
  },
  "results": [
    {
      "test_name": "test_section_1_display_label",
      "section": 1,
      "requirement_type": "display_label",
      "status": "PASS",
      "message": "Display label matches: 'Any Important Protocol Deviations'",
      "duration_ms": 12
    },
    {
      "test_name": "test_section_2_subset",
      "section": 2,
      "requirement_type": "subset",
      "status": "FAIL",
      "message": "AssertionError: Expected subset operator 'EQ' in where_clause, got 'IN'",
      "expected": "EQ",
      "actual": "IN",
      "file_path": "/mnt/code/executor/metadata/where_clause/uuid.yaml",
      "duration_ms": 8
    },
    ...
  ]
}
```

---

## Agentic Test Generation: The Core Intelligence

### What the Agent Must Do

1. **Read requirements.json** and understand each requirement's intent
2. **Map requirement type** → ARMADA metadata entity and field:
   - **Output-level:**
     - `output-title` → `main_aom.outputLabel`
     - `output-footnotes` → `main_aom.footnotes` → footnote entity → `footnoteText`
   - **Section-level:**
     - `display_label` → `section_aom.labels` → `label_aom.displayLabel` (or format-based/dynamic patterns)
     - `method` → `section_aom.analyses` → `arm.methodGroupID` → `methodgroup.methods`
     - `by_variable` → `arm.byVariables` → UUID resolution
     - `domain` → `arm.domain`
     - `subset` → `arm.subSet` → `where_clause` validation
     - `denominator` → `arm.denomID` or `main_aom.bigNAnalysisID`

3. **Handle metadata complexity:**
   - UUID resolution (UUID → entity lookup in graph)
   - Multi-value fields (split on `*`)
   - Optional fields (some arms may lack subSet)
   - Nested references (arm → methodgroup → method → label)
   - Entity types (distinguish `arm` from `analysis`, `label_aom` from `label_foot_aom`, etc.)
   - **Display Label types** (three distinct patterns — see below)

4. **Generate readable R test code** with:
   - Clear test names (`test_that("section_N_requirement_type: ...", { ... })`)
   - Descriptive assertions with context
   - Proper error messages (include expected vs actual, file path, UUID)
   - Skip logic for optional fields (use `testthat::skip_if_not()` if field is optional and missing)

5. **Handle edge cases:**
   - Missing entities (UUID doesn't resolve) → `expect_false(is.null(...), info = "entity not found")`
   - Null fields (allowed for optional) → Pass or skip appropriately
   - Multi-section validation (must test each section independently)
   - Codelist validation (if denominator is a codelist ID, verify it exists)

### Test Structure

**Generated R helper:** `tests/testthat/helper-armada-<tfl>.R`

```r
# ── ARMADA METADATA HELPERS ──────────────────────────────────────────────────
# Auto-generated helpers for ARMADA validation
# DO NOT EDIT MANUALLY — regenerate with agent if requirements change.
# ─────────────────────────────────────────────────────────────────────────────

load_armada_metadata <- function(metadata_file = "/tmp/metadata.json") {
  "Load and parse ARMADA metadata JSON."
  jsonlite::read_json(metadata_file)
}

load_armada_requirements <- function(requirements_file = "/tmp/requirements.json") {
  "Load and parse ARMADA requirements JSON."
  jsonlite::read_json(requirements_file)
}

get_entity <- function(metadata, uuid) {
  "Resolve UUID to entity in metadata graph."
  metadata$entities[[uuid]]
}

get_section_aom <- function(metadata, section_number) {
  "Get section_aom entity for given section number."
  entities <- metadata$entities
  for (i in seq_along(entities)) {
    entity <- entities[[i]]
    if (!is.null(entity$entity_type) && 
        entity$entity_type == "section_aom" &&
        !is.null(entity$data$section_number) &&
        entity$data$section_number == section_number) {
      return(entity$data)
    }
  }
  NULL
}

get_main_aom <- function(metadata) {
  "Get main_aom entity."
  entities <- metadata$entities
  for (i in seq_along(entities)) {
    entity <- entities[[i]]
    if (!is.null(entity$entity_type) && entity$entity_type == "main_aom") {
      return(entity$data)
    }
  }
  NULL
}

split_uuids <- function(uuid_string) {
  "Split pipe-separated UUID string."
  if (is.null(uuid_string)) return(character(0))
  trimws(strsplit(as.character(uuid_string), "\\*")[[1]])
}
```

**Generated R tests:** `tests/testthat/test-armada-<tfl>.R`

```r
# ── ARMADA VALIDATION TESTS ──────────────────────────────────────────────────
# Auto-generated from ADO requirements
# Generated from: https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276
# DO NOT EDIT MANUALLY — regenerate with agent if requirements change.
# ─────────────────────────────────────────────────────────────────────────────

setup({
  metadata <<- load_armada_metadata()
  requirements <<- load_armada_requirements()
})

# ──────────────────────────────────────────────────────────────────────────────
# OUTPUT-LEVEL REQUIREMENTS
# ──────────────────────────────────────────────────────────────────────────────

test_that("output-title: Output title matches requirement", {
  # Requirement: Table title: Summary of Important Protocol Deviations by Treatment Arm
  
  main_aom <- get_main_aom(metadata)
  expect_false(is.null(main_aom), info = "main_aom not found in metadata")
  
  expected_title <- "Summary of Important Protocol Deviations by Treatment Arm"
  actual_title <- main_aom$outputLabel
  
  expect_equal(actual_title, expected_title,
    info = paste0("Output title mismatch.",
                   "\n  Expected: '", expected_title, "'",
                   "\n  Actual: '", actual_title, "'")
  )
})

test_that("output-footnotes: Output footnotes match requirements", {
  # Requirement: Footnotes must include specific text about safety population and deviation counting
  
  main_aom <- get_main_aom(metadata)
  expect_false(is.null(main_aom), info = "main_aom not found in metadata")
  
  # Collect all footnote texts
  footnote_uuids <- split_uuids(main_aom$footnotes)
  actual_footnotes <- character()
  
  for (uuid in footnote_uuids) {
    footnote_entity <- get_entity(metadata, uuid)
    if (!is.null(footnote_entity)) {
      footnote_text <- footnote_entity$data$footnoteText
      if (!is.null(footnote_text)) {
        actual_footnotes <- c(actual_footnotes, footnote_text)
      }
    }
  }
  
  # Verify expected footnotes are present
  expected_footnotes <- c(
    "This analysis includes all subjects in the safety population.",
    "Protocol deviations are categorized and counted by distinct subjects."
  )
  
  for (expected in expected_footnotes) {
    found <- any(grepl(expected, actual_footnotes, fixed = TRUE))
    expect_true(found,
      info = paste0("Missing expected footnote: '", expected, "'",
                     "\n  Actual footnotes: ", paste(actual_footnotes, collapse = " | "))
    )
  }
})

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 1: Any Important Protocol Deviations
# ──────────────────────────────────────────────────────────────────────────────

test_that("section-1-display_label: Display label matches requirement", {
  # Requirement: Display label must be: Any Important Protocol Deviations
  
  section_aom <- get_section_aom(metadata, 1)
  expect_false(is.null(section_aom), info = "Section 1 not found in metadata")
  
  # Navigate: section_aom.labels -> label_aom.displayLabel
  label_uuid <- section_aom$labels
  label_aom <- get_entity(metadata, label_uuid)$data
  
  expected <- "Any Important Protocol Deviations"
  actual <- label_aom$displayLabel
  
  expect_equal(actual, expected,
    info = paste0("Section 1 display label mismatch.",
                   "\n  Expected: '", expected, "'",
                   "\n  Actual: '", actual, "'")
  )
})

test_that("section-1-method: Statistical method matches requirement", {
  # Requirement: Number of distinct subjects (USUBJID) with at least one...
  
  section_aom <- get_section_aom(metadata, 1)
  expect_false(is.null(section_aom), info = "Section 1 not found")
  
  # Navigate: section_aom.analyses -> arm.methodGroupID -> methodgroup.methods
  analyses_uuid <- section_aom$analyses
  arm <- get_entity(metadata, analyses_uuid)$data
  
  methodgroup_uuid <- arm$methodGroupID
  methodgroup <- get_entity(metadata, methodgroup_uuid)$data
  methods_uuids <- split_uuids(methodgroup$methods)
  
  # Check that at least one method contains expected text
  expected_text <- "Number of distinct subjects (USUBJID)"
  found <- FALSE
  
  for (uuid in methods_uuids) {
    method <- get_entity(metadata, uuid)$data
    if (!is.null(method$methodLabel) && 
        grepl(expected_text, method$methodLabel, fixed = TRUE)) {
      found <- TRUE
      break
    }
  }
  
  expect_true(found,
    info = paste0("Expected method containing '", expected_text, "' not found")
  )
})

test_that("section-1-domain: Domain matches requirement", {
  # Requirement: Requirement uses ADDV domain for data source.
  
  section_aom <- get_section_aom(metadata, 1)
  expect_false(is.null(section_aom))
  
  # Navigate: section_aom.analyses -> arm.domain
  analyses_uuid <- section_aom$analyses
  arm <- get_entity(metadata, analyses_uuid)$data
  
  expected_domain <- "ADDV"
  actual_domain <- arm$domain
  
  expect_equal(actual_domain, expected_domain,
    info = paste0("Domain mismatch in Section 1.",
                   "\n  Expected: '", expected_domain, "'",
                   "\n  Actual: '", actual_domain, "'")
  )
})

test_that("section-1-subset: Subset filter is correct", {
  # Requirement: Data must be subset/filtered using: ADIMPTFL EQ "Y"
  
  section_aom <- get_section_aom(metadata, 1)
  expect_false(is.null(section_aom))
  
  # Navigate: section_aom.analyses -> arm.subSet -> where_clause
  analyses_uuid <- section_aom$analyses
  arm <- get_entity(metadata, analyses_uuid)$data
  
  subset_uuid <- arm$subSet
  expect_false(is.null(subset_uuid), info = "Subset not defined for Section 1")
  
  where_clause <- get_entity(metadata, subset_uuid)$data
  where_string <- where_clause$whereClause
  
  # Verify the where clause contains the expected filter
  expect_match(where_string, "ADIMPTFL.*EQ.*Y", 
    info = paste0("Subset filter does not match requirement.",
                   "\n  Expected to contain: ADIMPTFL EQ \"Y\"",
                   "\n  Actual: '", where_string, "'")
  )
})

# ... (more tests for sections 2 and 3, all 18 requirements)
```

---

## Key Differences from Phase 3 (LED) Validation

| Aspect | Phase 3 (LED) | ARMADA Validation |
|--------|---------------|-------------------|
| **Source of truth** | Excel spec (`*_LED.xlsx`) | ADO work item card |
| **Data to validate** | R code (LED derivations) | YAML metadata (main_aom, section_aom, etc.) |
| **Test generation** | Manual (skill guides developer to write tests) | Agentic (agent generates tests from requirements) |
| **Assertion style** | testthat R framework | **testthat R framework** |
| **Entity complexity** | Variables, predecessors, formulas | UUIDs, nested references, multi-value fields |
| **Coverage model** | Row-level assertions (specific data values) | Entity-level assertions (metadata fields) |

---

## How to Use This Skill

### Quick Start

```bash
cd /mnt/imported/code/standard-led

# Step 1: Extract requirements
./.github/scripts/armada_validate.sh \
  "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" \
  json /tmp/requirements.json

# Step 2: Collect metadata
python ./.github/scripts/armada_metadata_collector.py \
  dv_t01_sum_impo_prot_dev_armada \
  --graph /tmp/metadata.json

# Step 3: Generate validation tests (agentic approach)
# Agent reads requirements.json and metadata.json
# Agent generates: tests/testthat/test-armada-dv_t01.R
# Agent generates: tests/testthat/helper-armada-dv_t01.R

# Step 4: Run tests with testthat
devtools::test(filter = "armada-dv_t01")

# Or with testthat directly
testthat::test_local(filter = "test-armada-dv_t01")
```

### With Agent-Based Test Generation

For production use, invoke the agentic skill:

```bash
# Use a background agent to generate validation tests
# Input: requirements.json, metadata.json
# Output: tests/testthat/test-armada-<tfl>.R (generated test file with proper assertions)
#         tests/testthat/helper-armada-<tfl>.R (generated helper functions)
# Then: Run tests with devtools::test() or testthat::test_local()
```

---

## Display Label Metadata Patterns (Critical for Future TFLs)

The trickiest requirement type is `display_label` because there are **three distinct patterns** in ARMADA metadata. The agent must correctly identify which pattern applies and validate accordingly.

### Pattern 1: Literal Text Label (Simple Match)

**When:** First section of table; requirement specifies exact label text
**Example:** `display_label: "Any Important Protocol Deviations"`

**Metadata path:**
```
section_aom.labels (UUID)
  → label_aom.displayLabel (text field)
```

**Test logic:**
```r
section_aom <- get_section_aom(metadata, section_number)
label_uuid <- section_aom$labels
label_aom <- get_entity(metadata, label_uuid)$data
actual <- label_aom$displayLabel
expected <- "Any Important Protocol Deviations"  # from requirement

expect_equal(actual, expected, info = paste0(
  "Display label mismatch.\n  Expected: '", expected, 
  "'\n  Actual: '", actual, "'"))
```

**Key insight:** This is a direct text match. If label resolves to `"Statistic"` or `NULL`, continue to Pattern 2.

---

### Pattern 2: Format-Based Label (Dynamic from Report Format)

**When:** When `displayLabel` is `"Statistic"` or `NULL`; label should come from the report format definition
**Example:** Section headers that use standard format labels like `"n (%)"` or `"n (Range)"`

**Metadata path:**
```
section_aom.resultFormat (UUID)
  → format_group.formats (list of UUIDs)
    → format.reportLabel (actual label text)
```

**Test logic:**
```r
section_aom <- get_section_aom(metadata, section_number)

# If displayLabel is "Statistic" or NULL, follow format_group path
result_format_uuid <- section_aom$resultFormat
format_group <- get_entity(metadata, result_format_uuid)$data
format_uuid <- strsplit(format_group$formats, "\\*", fixed = TRUE)[[1]][1]
format_entity <- get_entity(metadata, trimws(format_uuid))$data
actual <- format_entity$reportLabel  # e.g., "n (%)"

expect_equal(actual, expected, info = paste0(
  "Format-based label mismatch.\n  Path: resultFormat → format_group → format.reportLabel",
  "\n  Expected: '", expected, "'\n  Actual: '", actual, "'"))
```

**Key insight:** When simple displayLabel fails, always check if `resultFormat` provides the actual label via format_group hierarchy.

---

### Pattern 3: Dynamic/Template Label (Variable Group Reference)

**When:** Requirement text is a template like `"<category name>"` or `"<coded term>"`; actual label will be populated from dataset variables at runtime
**Example:** 
- Section 2: `"<category name> (one row per observed deviation category, e.g. 'NOT WITHDRAWN ...')"`
- Section 3: `"<coded term> (indented under each category, one row per observed coded term, e.g. 'NOT DISCONTINUED ...')"`

**Metadata path:**
```
label_aom.value (UUID to variable_group)
  → variable_group.variableNum or variableCode or variableDecode
    ↓
Compare against expected variables from section's by_variable requirement
```

**Test logic:**
```r
# Step 1: Parse requirement to extract expected variable(s)
requirement_text <- "NA/NA/ACAT1 (Full Matrix: No)"  # from requirement
expected_var <- "ACAT1"  # extract variable name

# Step 2: Get section's label
section_aom <- get_section_aom(metadata, section_number)
label_uuid <- section_aom$labels  # e.g., "416087bf-8cdf-4bc3-b400-71a0873d7e52"
label_aom <- get_entity(metadata, label_uuid)$data

# Step 3: Resolve label.value to variable group
var_group_uuid <- label_aom$value  # e.g., "432154cd-8957-4c8b-9a31-00ab5b815e5e"
var_group <- get_entity(metadata, var_group_uuid)$data

# Step 4: Check if expected variable is in the group
vars_in_group <- c(var_group$variableNum, var_group$variableCode, var_group$variableDecode)
if (expected_var %in% vars_in_group) {
  # PASS: Label correctly references the expected variable group
} else {
  # FAIL: Label doesn't reference the expected variable
}

expect_true(expected_var %in% vars_in_group, info = paste0(
  "Label does not reference expected variable.\n  Expected: '", expected_var,
  "'\n  Variables in group: ", paste(vars_in_group, collapse = ", ")))
```

**Multi-tier example (Section 3):**
```r
# Section 3 may have TWO labels: one for category, one for coded term
# Labels: "432154cd-8957-4c8b-9a31-00ab5b815e5e | 67d541c4-cd08-4cf0-b28c-30ad1dc54c10"
# Expected variables: ACAT1 and ADECOD (from by_variable requirement)

label_uuids <- strsplit(label_string, "\\|")[[1]]
label_uuids <- trimws(label_uuids)
expected_vars <- c("ACAT1", "ADECOD")

for (i in seq_along(expected_vars)) {
  label_uuid <- label_uuids[i]
  label_aom <- get_entity(metadata, label_uuid)$data
  var_group_uuid <- label_aom$value
  var_group <- get_entity(metadata, var_group_uuid)$data
  
  vars_in_group <- c(var_group$variableNum, var_group$variableCode, var_group$variableDecode)
  
  expect_true(expected_vars[i] %in% vars_in_group, info = paste0(
    "Tier ", i, " label does not reference '", expected_vars[i], "'"))
}
```

**Key insight:** Template labels are NOT tested by text match; instead, validate that the label correctly **links to the expected variable group**. The actual label text will come from the dataset at runtime.

---

## How to Distinguish the Patterns

When generating tests for `display_label`:

1. **Read requirement text** from requirements.json → `requirement.documentation`
2. **If requirement text is literal** (e.g., `"Any Important Protocol Deviations"` or `"n (%)"`)
   → Use **Pattern 1 or 2** (try Pattern 1 first, fallback to Pattern 2 if displayLabel is "Statistic" or NULL)
3. **If requirement text is a template** (contains `"<"` and `">"`, e.g., `"<category name>"` or `"<coded term>"`)
   → Use **Pattern 3** (extract expected variable(s) from by_variable requirement and validate variable_group reference)

---


## Advantages of Agentic Test Generation

1. **No hard-coded validators** — each test is unique to the requirements and metadata structure
2. **Self-explanatory tests** — generated code reads like human-written tests (clear intent)
3. **Flexible error messages** — agent can include contextual info (file paths, UUIDs, expected vs actual)
4. **Adaptive to schema changes** — if ARMADA structure evolves, agent can handle new entity types
5. **Full traceability** — each generated test has a requirement ID and documentation link
6. **Debuggable** — generated test file can be inspected and understood before execution
7. **Reusable pattern** — same approach works for future TFLs without code changes

---

## Complete Test Coverage Summary

### Total Tests per TFL

With both **output-level** and **section-level** requirements:

- **Output-level requirements:** 2 tests
  - `output-title` (1 test)
  - `output-footnotes` (1 test)

- **Section-level requirements:** 18 tests
  - 6 requirement types × 3 sections = 18 tests
  - Types: display_label, method, by_variable, domain, subset, denominator

- **TOTAL PER TFL: 20 tests**

### Requirement Extraction Checklist

When extracting requirements from ADO, ensure you capture:

**Output-Level (Top of Card):**
- [ ] **Output Title** — What the table is called
- [ ] **Output Footnotes** — All explanatory text displayed below the table

**Section-Level (For Each Section):**
- [ ] Display Label
- [ ] Statistical Method
- [ ] By Variables (stratification)
- [ ] Data Source Domain
- [ ] Subset/Filter Criteria
- [ ] Denominator for Percentages

### Requirements.json Structure with Output-Level

The enhanced requirements.json format now includes output-level requirements:

```json
{
  "schema_title": "Summary of Important Protocol Deviations",
  "schema_type": "table",
  "display_name": "Summary of Important Protocol Deviations by Treatment Arm",
  
  "output_requirements": [
    {
      "id": "output-title",
      "documentation": "Table title: Summary of Important Protocol Deviations by Treatment Arm",
      "description": "The table's main title displayed above the table"
    },
    {
      "id": "output-footnotes",
      "documentation": [
        "Footnote 1: This analysis includes all subjects in the safety population.",
        "Footnote 2: Protocol deviations are categorized and counted by distinct subjects."
      ],
      "description": "Explanatory text displayed below the table"
    }
  ],
  
  "sections": [
    {
      "id": "section-1",
      "number": 1,
      "title": "Any Important Protocol Deviations",
      "requirements": [ ... 6 section-level requirements ... ]
    },
    ...
  ]
}
```

---

## Future Enhancements

1. **HTML report generation** — transform test results into visual report with pass/fail matrix
2. **CI/CD integration** — automatically run validation on PR merge
3. **Evidence collection** — capture actual vs expected side-by-side in results
4. **Codelist validation** — cross-reference against ADaM spec dictionaries
5. **Multi-TFL batch runs** — validate multiple TFLs in one command with consolidated report
6. **Test persistence** — cache generated tests for reproducibility

---

## Troubleshooting

**Problem:** `Section N not found in metadata`
- Check that main_aom has exactly 3 sections defined in the `sections` field
- Verify section UUIDs exist as `section_aom` entities in metadata.json

**Problem:** `UUID not resolved`
- The referenced entity doesn't exist in metadata.json
- Run armada_metadata_collector with full graph to ensure all linked entities are collected

**Problem:** `Test failed with AssertionError: expected X, got Y`
- Metadata value doesn't match requirement
- Either update metadata YAML files or update ADO requirement
- Always update requirement first, then metadata (not the reverse)

---

## References

- ADO Requirements: `https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276`
- ARMADA Metadata: `/mnt/code/executor/metadata/`
- Requirements Extraction: `./.github/scripts/armada_validate.sh`
- Metadata Collection: `./.github/scripts/armada_metadata_collector.py`
- Test Execution: `python /tmp/armada_validation_tests.py`

---

## Summary

This skill enables **agentic validation** of ARMADA metadata by:
1. Extracting requirements from ADO (structured, 18 requirements)
2. Collecting linked ARMADA metadata (48 entities)
3. **Generating bespoke Python tests** that validate metadata against requirements
4. Executing tests and reporting results with evidence

The key innovation: **tests are generated on-the-fly by an intelligent agent**, not hard-coded. This makes the validation system flexible, self-documenting, and adaptable to future TFL schemas.
