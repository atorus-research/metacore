# ARMADA LED Execution & ARD Generation: Step 5

**Purpose:** Convert ARMADA metadata (ARM and AOM) to Linked Executable Definitions (LEDs) and execute them through Mercury Executor to generate Analysis Result Datasets (ARDs) and PDF outputs.

**Status:** ✅ Fully automated via `armada_executor.py`

---

## Overview

This skill enables Step 5 of the ARMADA validation pipeline:

1. **Collect ARM metadata** — Find all ARM files that belong to the target table
2. **Convert ARM → LED** — Run `make convert_1arm` for each ARM
3. **Convert AOM → LED** — Run `make convert_1aom` for the target AOM
4. **Execute LEDs** — Run `make run` for each created LED (ARM first, then AOM)
5. **Capture outputs** — ARDs (Parquet) and PDF are generated in `/mnt/data/{project}/prod/adamdata/`

---

## Prerequisites

### Environment Variables

Must be set before any `make` command:

```bash
# In Domino: Environment → Set Variable
# Or in session:
export MERCURY_EXECUTOR_PATH="/path/to/executor"
export LED_TOOLING_PATH="/path/to/tooling"
export MERCURY_METADATA_PATH="/mnt/code/executor/metadata"
export DOMINO_PROJECT_NAME="project-name"

# Verify:
echo $MERCURY_EXECUTOR_PATH
echo $DOMINO_PROJECT_NAME
```

### Directory Structure

Work happens in two directories:

```
/mnt/imported/code/standard-led/          # Skills and validation framework
/mnt/code/                                  # End-to-end standards & metadata
  ├── executor/metadata/
  │   ├── main_aom/*.yaml                 # Main AOM definitions
  │   ├── arm/*.yaml                      # ARM metadata files
  │   ├── section_aom/*.yaml              # Section-level AOMs
  │   └── led/                            # Output LEDs (created by convert_1arm/convert_1aom)
  └── Makefile                            # Commands: convert_1arm, convert_1aom, run
```

---

## Quick Start

### 1. Identify the Target Output

Get the output ID (e.g., `dv_t01_sum_impo_prot_dev_armada`):

```bash
# List all main AOMs
ls /mnt/code/executor/metadata/main_aom/*.yaml

# Or from your validation pipeline (Stage 2)
cat /tmp/metadata.json | jq '.output_id'
```

### 2. Run the Full Execution Pipeline

```bash
cd /mnt/code

python ../.github/scripts/armada_executor.py \
  --output-id dv_t01_sum_impo_prot_dev_armada \
  --dry-run false \
  --verbose true \
  --log-file executor_logs/dv_t01_execution.log
```

### 3. Monitor Progress

```bash
# Watch log output in real-time
tail -f /mnt/code/executor_logs/dv_t01_execution.log

# Or check output afterwards
cat /mnt/code/executor_logs/dv_t01_execution.log
```

### 4. Verify Outputs

```bash
# Check ARD files
ls -lh /mnt/data/{DOMINO_PROJECT_NAME}/prod/adamdata/

# Check PDF outputs
ls -lh /mnt/data/{DOMINO_PROJECT_NAME}/prod/tfls/
```

---

## API & Command-Line Usage

### Python API

```python
from armada_executor import ARMADAExecutor

executor = ARMADAExecutor(
    output_id="dv_t01_sum_impo_prot_dev_armada",
    work_dir="/mnt/code",
    dry_run=False,
    verbose=True,
    log_file="/tmp/execution.log"
)

result = executor.execute()

print(result['status'])           # "success" or "failed"
print(result['arms_converted'])   # List of ARM files converted
print(result['aom_converted'])    # AOM file converted
print(result['leds_executed'])    # List of LEDs executed
print(result['total_duration'])   # Total execution time (seconds)
```

### Command-Line Interface

```bash
# Basic execution
python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada

# Dry-run mode (no actual execution)
python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada --dry-run true

# Verbose logging
python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada --verbose true

# Custom log file
python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada \
  --log-file /tmp/my_execution.log

# All options
python armada_executor.py \
  --output-id dv_t01_sum_impo_prot_dev_armada \
  --work-dir /mnt/code \
  --dry-run false \
  --verbose true \
  --log-file /tmp/execution.log \
  --stop-on-error true
```

---

## Workflow

### Phase 1: Discover Metadata

The executor finds all ARM metadata linked to the target AOM:

```
Target: dv_t01_sum_impo_prot_dev_armada
    ↓
Read /mnt/code/executor/metadata/main_aom/dv_t01_sum_impo_prot_dev_armada.yaml
    ↓
Extract UUIDs of linked ARM files
    ↓
Map to ARM files in /mnt/code/executor/metadata/arm/
    ↓
Collect list of ARM files to convert
```

**Example output:**
```
Discovered target AOM:
  File: dv_t01_sum_impo_prot_dev_armada.yaml
  UUIDs: [uuid-1, uuid-2, uuid-3]
  Linked ARM files: 3
    - ae-any-count.yaml
    - ae-by-soc-count.yaml
    - ae-by-soc-pt-count.yaml
```

### Phase 2: Convert ARM to LEDs

For each discovered ARM file:

```bash
cd /mnt/code
make convert_1arm what='ae-any-count.yaml'
```

This creates LED files in `/mnt/code/executor/metadata/led/`:

```
executor/metadata/led/
  ├── adam_arm_ae_any_count_*.yaml
  ├── adam_arm_ae_by_soc_count_*.yaml
  └── adam_arm_ae_by_soc_pt_count_*.yaml
```

**Example output:**
```
✓ Converted: arm:ae-any-count.yaml → led:adam_arm_ae_any_count_01.yaml
✓ Converted: arm:ae-by-soc-count.yaml → led:adam_arm_ae_by_soc_count_01.yaml
✓ Converted: arm:ae-by-soc-pt-count.yaml → led:adam_arm_ae_by_soc_pt_count_01.yaml
```

### Phase 3: Convert AOM to LED

Convert the target AOM:

```bash
cd /mnt/code
make convert_1aom what='dv_t01_sum_impo_prot_dev_armada.yaml'
```

This creates:

```
executor/metadata/led/
  └── adam_aom_dv_t01_sum_impo_prot_dev_armada_*.yaml
```

**Example output:**
```
✓ Converted: aom:dv_t01_sum_impo_prot_dev_armada.yaml → led:adam_aom_dv_t01_sum_impo_prot_dev_armada_01.yaml
```

### Phase 4: Execute ARM LEDs

Run all ARM LEDs **first** to create the ARDs (Analysis Result Datasets) needed by the AOM:

```bash
cd /mnt/code
make run args='--what dv-any-count'
make run args='--what dv-by-acat-count'
make run args='--what dv-by-acat-adecod-count'
```

**Example output:**
```
✓ Executed: dv-any-count (12.3s)
  Output: /mnt/data/project/prod/adamdata/dv_any_count.parquet
  
✓ Executed: dv-by-acat-count (15.7s)
  Output: /mnt/data/project/prod/adamdata/dv_by_acat_count.parquet
  
✓ Executed: dv-by-acat-adecod-count (18.2s)
  Output: /mnt/data/project/prod/adamdata/dv_by_acat_adecod_count.parquet
```

### Phase 5: Execute AOM

Run the AOM **after** all ARM LEDs to generate the final TFL table:

```bash
cd /mnt/code
make run args='--what dv_t01_sum_impo_prot_dev_armada'
```

**Example output:**
```
✓ Executed: dv_t01_sum_impo_prot_dev_armada (8.5s)
  Outputs:
    - /mnt/data/project/prod/adamdata/dv_t01.parquet (ARD)
    - /mnt/data/project/prod/tfls/dv_t01.pdf (PDF)
    - /mnt/data/project/prod/tfls/dv_t01_mock.html (Mock Shell)
```

---

## ARMADAExecutor Class

### Constructor

```python
class ARMADAExecutor:
    def __init__(self,
                 output_id: str,
                 work_dir: str = "/mnt/code",
                 dry_run: bool = False,
                 verbose: bool = False,
                 log_file: str = None,
                 stop_on_error: bool = True)
```

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `output_id` | str | Required | Target AOM output ID (e.g. `dv_t01_sum_impo_prot_dev_armada`) |
| `work_dir` | str | `/mnt/code` | Root directory containing metadata and Makefile |
| `dry_run` | bool | False | If True, print commands without executing |
| `verbose` | bool | False | If True, print detailed progress messages |
| `log_file` | str | None | Optional file path to write logs (in addition to stdout) |
| `stop_on_error` | bool | True | If True, stop on first error; if False, continue with remaining commands |

### Methods

#### `execute() → dict`

Run the full execution pipeline (discovery → conversion → execution).

**Returns:**
```python
{
    'status': 'success' | 'failed',
    'output_id': str,
    'arms_discovered': int,
    'arms_converted': list,      # List of ARM files converted
    'aom_converted': str,        # AOM file converted
    'leds_created': list,        # List of LED files created
    'leds_executed': list,       # List of LEDs executed successfully
    'failed_commands': list,     # List of failed make commands
    'total_duration': float,     # Total execution time in seconds
    'phases': {
        'discovery': {'status': 'success' | 'failed', 'duration': float},
        'arm_conversion': {'status': 'success' | 'failed', 'duration': float},
        'aom_conversion': {'status': 'success' | 'failed', 'duration': float},
        'arm_execution': {'status': 'success' | 'failed', 'duration': float},
        'aom_execution': {'status': 'success' | 'failed', 'duration': float}
    }
}
```

**Example:**
```python
executor = ARMADAExecutor(output_id="dv_t01_sum_impo_prot_dev_armada")
result = executor.execute()

if result['status'] == 'success':
    print(f"✓ Execution complete in {result['total_duration']:.1f}s")
    print(f"  ARM files converted: {len(result['arms_converted'])}")
    print(f"  Outputs: {result['leds_executed']}")
else:
    print(f"✗ Execution failed")
    print(f"  Failed commands: {result['failed_commands']}")
```

#### `discover_arms() → list`

Discover all ARM files linked to the target AOM (Phase 1 only).

**Returns:** List of ARM file names

#### `convert_arms() → dict`

Convert all discovered ARM files to LEDs (Phase 2 only).

**Returns:** Dict with ARM files converted and LED files created

#### `convert_aom() → dict`

Convert the target AOM to LED (Phase 3 only).

**Returns:** Dict with AOM file converted and LED file created

#### `execute_arms() → dict`

Execute all ARM LEDs (Phase 4 only).

**Returns:** Dict with LEDs executed and their durations

#### `execute_aom() → dict`

Execute the AOM LED (Phase 5 only).

**Returns:** Dict with LED executed, duration, and output files

---

## Output Files

### ARDs (Analysis Result Datasets)

Located at `/mnt/data/{DOMINO_PROJECT_NAME}/prod/adamdata/`:

```
adamdata/
  ├── ae_any_count.parquet           # ARM output (from adam_arm_ae_any_count_01)
  ├── ae_by_soc_count.parquet        # ARM output
  ├── ae_by_soc_pt_count.parquet     # ARM output
  └── dv_t01.parquet                 # AOM output (final ARD)
```

### TFL Outputs

Located at `/mnt/data/{DOMINO_PROJECT_NAME}/prod/tfls/`:

```
tfls/
  ├── dv_t01.pdf                     # Final PDF output
  ├── dv_t01_mock.html               # Mock shell (for validation)
  └── dv_t01_metadata.json           # Output metadata
```

---

## Error Handling

### Common Issues

#### 1. Environment Variables Not Set

**Error:**
```
KeyError: MERCURY_EXECUTOR_PATH not set
```

**Solution:**
```bash
export MERCURY_EXECUTOR_PATH="/path/to/executor"
export LED_TOOLING_PATH="/path/to/tooling"
export MERCURY_METADATA_PATH="/mnt/code/executor/metadata"
export DOMINO_PROJECT_NAME="my-project"
```

#### 2. Output ID Not Found

**Error:**
```
FileNotFoundError: /mnt/code/executor/metadata/main_aom/invalid_id.yaml not found
```

**Solution:**
```bash
# Verify the output ID exists
ls /mnt/code/executor/metadata/main_aom/ | grep -E "\.yaml$"
```

#### 3. ARM File Not Found During Conversion

**Error:**
```
make: *** [convert_1arm] Error 2
Command: make convert_1arm what='invalid-arm.yaml'
```

**Solution:**
```bash
# Verify ARM files are discoverable
python -c "from armada_executor import ARMADAExecutor; e = ARMADAExecutor('output_id'); print(e.discover_arms())"
```

#### 4. LED Execution Fails

**Error:**
```
make: *** [run] Error 1
LED: adam_arm_ae_any_count_01
```

**Solution:**
1. Check Mercury Executor logs: `tail /mnt/code/executor_logs/`
2. Verify ARD dependencies are created: `ls /mnt/data/{project}/prod/adamdata/`
3. Run with `--dry-run true` to see exact make commands

### Debug Mode

Enable full debugging:

```python
executor = ARMADAExecutor(
    output_id="dv_t01_sum_impo_prot_dev_armada",
    dry_run=True,      # See all commands without executing
    verbose=True,      # Detailed progress
    log_file="/tmp/debug.log"
)

result = executor.execute()

# Inspect the commands that would be run
for phase, details in result['phases'].items():
    print(f"{phase}: {details}")
```

---

## Integration with Validation Pipeline

### Full Pipeline (Steps 1-5)

```bash
#!/bin/bash
set -e

cd /mnt/imported/code/standard-led

# Step 1: Extract requirements
./.github/scripts/armada_validate.sh \
  "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" \
  json /tmp/requirements.json

# Step 2: Collect metadata
python ./.github/scripts/armada_metadata_collector.py \
  dv_t01_sum_impo_prot_dev_armada \
  --graph /tmp/metadata.json

# Step 3: Generate tests (AGENT)
# [Agent invocation for test generation - see QUICK_REFERENCE.md]

# Step 4: Run tests
Rscript -e "testthat::test_file('tests/testthat/test-armada-dv_t01.R')"

# Step 5: Execute LEDs and generate ARDs/PDFs
cd /mnt/code
python ../.github/scripts/armada_executor.py \
  --output-id dv_t01_sum_impo_prot_dev_armada \
  --dry-run false \
  --log-file executor_logs/step5_execution.log

# Step 6: Generate traceability matrix (AGENT)
# [Agent invocation for reporting - see QUICK_REFERENCE.md]
```

### CI/CD Integration

```yaml
# .github/workflows/armada-validation.yml

name: ARMADA Validation Pipeline

on:
  push:
    paths:
      - 'executor/metadata/**'
      - '.github/scripts/armada_*.py'

jobs:
  step5-led-execution:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Set environment variables
        run: |
          echo "MERCURY_EXECUTOR_PATH=/opt/mercury" >> $GITHUB_ENV
          echo "DOMINO_PROJECT_NAME=${{ github.event.repository.name }}" >> $GITHUB_ENV
      
      - name: Execute LEDs
        run: |
          cd /mnt/code
          python ../.github/scripts/armada_executor.py \
            --output-id ${{ env.TARGET_OUTPUT_ID }} \
            --log-file ${{ runner.temp }}/execution.log
      
      - name: Upload artifacts
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: led-execution-logs
          path: ${{ runner.temp }}/execution.log
          retention-days: 30
```

---

## Performance Considerations

### Execution Time

Typical execution times by phase:

| Phase | ARM Count | Duration |
|-------|-----------|----------|
| Discovery | N/A | <1 second |
| ARM Conversion | 3 | 2-5 seconds |
| AOM Conversion | 1 | 2-3 seconds |
| ARM Execution | 3 | 30-60 seconds (10-20s each) |
| AOM Execution | 1 | 5-10 seconds |
| **Total** | **3 ARMs + 1 AOM** | **~2 minutes** |

### Optimization

For large numbers of ARM files:

```python
# Use stop_on_error=False to continue through failures
# (instead of stopping on first error)
executor = ARMADAExecutor(
    output_id="large_output",
    stop_on_error=False,  # Continue converting all ARMs
    verbose=True,
    log_file="/tmp/full_execution.log"
)

result = executor.execute()

# Review failures after completion
if result['failed_commands']:
    print(f"Failed: {result['failed_commands']}")
    # Can re-run just the failed commands
```

---

## Related Skills

- **armada-metadata-validation.md** — Requirements generation and test creation
- **armada-traceability-reporting.md** — Traceability matrix generation
- **END_TO_END_VALIDATION_GUIDE.md** — Complete pipeline walkthrough

---

## File Locations

| File | Location | Purpose |
|------|----------|---------|
| **Executor script** | `./.github/scripts/armada_executor.py` | Main orchestration |
| **Executor module** | `./.github/scripts/armada_executor/__init__.py` | ARMADAExecutor class |
| **CLI wrapper** | `./.github/scripts/armada_execute.sh` | Command-line interface |
| **Skill documentation** | `./.github/skills/armada-validation/armada-led-execution.md` | This file |

---

## Future Extensions

1. **Parallel Execution** — Run ARM LEDs in parallel (currently sequential)
2. **Selective Execution** — Re-run only changed ARM/AOM files
3. **Rollback** — Undo changes if execution fails
4. **Caching** — Cache intermediate ARD files for faster re-runs
5. **Validation Checks** — Verify ARD schemas before proceeding to AOM


---

## Bug Fix: Selective ARM Discovery

**FIXED:** The executor now correctly discovers ONLY the ARM files linked to the target AOM, not all ARM files in the directory.

### How It Works

The discovery algorithm properly traverses ARMADA metadata:

1. **Load target main_aom** — e.g., `dv_t01_sum_impo_prot_dev_armada.yaml`
2. **Extract section UUIDs** — From the `sections` field (format: `uuid1*uuid2*uuid3`)
3. **Read each section_aom** — Load the section metadata file for each UUID
4. **Extract ARM file name** — From the `analyses` field of each section
5. **Return only linked ARMs** — List of ARM files that belong to this output

### Example

```
Input: output_id = "dv_t01_sum_impo_prot_dev_armada"

Step 1: Read main_aom/dv_t01_sum_impo_prot_dev_armada.yaml
  sections: "b21f5661-05da-490c-8b58-ec69c8a84a99*0c0346d2-cf7a-4abf-90a0-3612ab60e1d8*69307180-7247-421c-a1af-c9db1f281677"

Step 2: Extract 3 section UUIDs:
  - b21f5661-05da-490c-8b58-ec69c8a84a99
  - 0c0346d2-cf7a-4abf-90a0-3612ab60e1d8
  - 69307180-7247-421c-a1af-c9db1f281677

Step 3: For each section UUID, read section_aom file:
  - section_aom/b21f5661-05da-490c-8b58-ec69c8a84a99.yaml → analyses: "dv-any-count"
  - section_aom/0c0346d2-cf7a-4abf-90a0-3612ab60e1d8.yaml → analyses: "dv-by-acat-count"
  - section_aom/69307180-7247-421c-a1af-c9db1f281677.yaml → analyses: "dv-by-acat-adecod-count"

Output: Only these 3 ARM files will be converted and executed:
  ✓ dv-any-count
  ✓ dv-by-acat-count
  ✓ dv-by-acat-adecod-count
```

### Benefits

- **Selective execution** — Only process ARM files that belong to the target output
- **No cross-output contamination** — Won't accidentally process unrelated ARMs
- **Proper dependency ordering** — ARM LEDs created in correct sequence for the output
- **Regulatory compliance** — Clear traceability of which ARMs were used for each output

