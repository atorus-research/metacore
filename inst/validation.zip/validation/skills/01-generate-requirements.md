# Stage 1 — Generate Requirements

## Purpose

Read the TFL specification documented in an Azure DevOps work item and emit a structured, machine-readable `requirements.json` describing everything the metadata must satisfy.

## Position

Stage 1 of 7. Consumes an ADO card. Feeds **Stage 3 (Generate Tests)** and **Stage 7 (Validation Summary)**.

This is the only stage that reads the human-authored specification. Everything downstream validates against `requirements.json`, so an omission here becomes an untested requirement, not an error.

## Inputs

| Input | Source | Notes |
|---|---|---|
| ADO work item URL | The TFL's ADO card | e.g. `https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276` |
| `ADO_PAT` env var | Your Domino profile | *Account Settings → Environment Variables → Add Variable*. Never commit it. |
| Mockshell + spec | The ADO card body | See `templates/tfl-spec-template.md` for the shape the parser expects |

## Procedure

Every stage reads and writes one shared **run directory**. Create it first and use the same path throughout:

```bash
cd /mnt/imported/code/standard-led

RUN=/mnt/code/validation_runs/dv_t01_$(date +%Y%m%d-%H%M%S)
mkdir -p "$RUN"

./.github/scripts/armada_validate.sh \
  "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" \
  json \
  "$RUN/requirements.json"
```

The filename **must** be `requirements.json` — stage 7 looks for exactly that name in the run directory.

Formats: `json` (required for the pipeline), `csv` (spreadsheet review), `java` (unused — see Known gaps).

## Outputs

**`<run-dir>/requirements.json`**

```json
{
  "schema_title": "Summary of Important Protocol Deviations",
  "schema_type": "table",
  "display_name": "...",
  "output_requirements": [
    { "id": "output-title",     "documentation": "...", "description": "...", "test_code": "..." },
    { "id": "output-footnotes", "documentation": ["..."], "description": "...", "test_code": "..." }
  ],
  "sections": [
    {
      "id": "section-1",
      "number": 1,
      "title": "Any Important Protocol Deviations",
      "requirements": [
        { "id": "section-1-display_label", "documentation": "...", "test_code": "...", "description": "..." }
      ]
    }
  ],
  "requirements": [ "... all of the above, flattened ..." ]
}
```

Each requirement carries:

| Field | Purpose |
|---|---|
| `id` | Unique, kebab-case — `section-1-display_label`, `output-title` |
| `documentation` | Plain-English statement of what must be true. **This is what Stage 3 turns into a test.** |
| `description` | The raw `Key: Value` line from the card |
| `test_code` | Java pseudocode. Vestigial — see Known gaps. |

### Requirement types

The parser reads a card in two forms, because cards use both.

**Inside a section** — `Key: Value` lines. Recognised keys: `Display label`, `Method`, `By Variable`, `Domain`, `Subset`, `Denominator`, `Title`, `Rationale`, `Footnote`, `Analysis set`.

**Output-level** — a bare heading on its own line, with the requirement stated in the prose beneath it:

```
Column

As displayed in the PNG, the table has two stub columns (indented) and two
result columns (one per treatment subset).
```

Recognised headings (`OUTPUT_BLOCK_HEADINGS` in `armada_validator.py`), each producing one `output-<type>` requirement:

| Heading | ID |
|---|---|
| `Title` | `output-title` |
| `Footnote` / `Footnotes` | `output-footnotes` |
| `Analysis Set` | `output-analysis_set` |
| `Treatment` | `output-treatment` |
| `Column` / `Columns` | `output-column` |
| `Study Design` | `output-study_design` |
| `Sorting Order` | `output-sorting_order` |

### Context, not requirements

Three headings are captured into `schema.context` and produce **no requirement and no test**. They inform the reviewer and whoever writes the metadata, but state nothing the metadata can be asserted against:

| Heading | `context` key | Why not a requirement |
|---|---|---|
| `Study Design` | `study_design` | A property of the study, not of this display |
| `.missing` | `missing` | Conditional on the data — no `.missing` row exists until a missing coded term is encountered |
| `Known Conflicts with the Mock Shell` | `known_conflicts` | Discrepancies for a human to resolve before the display is finalised |

Extend `CONTEXT_TYPES` in `armada_validator.py` to classify a new heading this way.

Notes on the block form:

- `Title: <value>` **inside** a `Title` block sets `display_name` exactly; the surrounding prose still becomes the requirement text.
- A `Rationale` heading attaches to the block above it as a `rationale` field rather than becoming a requirement of its own.
- `Section` (the prose introducing the sections) and `Display Description` are ignored; the sections themselves are matched by the `Section N —` pattern.
- Headings after the last section — `.missing`, `Sorting Order`, `Known Conflicts` — are still output-level and are picked up.
- A horizontal rule (`-----`) ends the specification. Text beneath it is captured as `schema.mock_shell` provenance, not as requirements.

DV_T01 produces 6 types × 3 sections + 6 output-level = 24 requirements, plus 3 context entries. **This is an example, not a schema.** Listings and figures will produce a different shape, and Stage 3 must handle whatever is present rather than expecting a fixed count.

**Everything in `requirements` must be assertable.** If a block cannot be tested against the metadata, it belongs in `context`, not in the requirement list — a requirement no test can satisfy either fails the run or forces a skip, and neither reflects the metadata's quality.

## Acceptance checks

Before moving to Stage 2:

```bash
# Sections were found — MUST NOT be 0
jq '.sections | length' "$RUN/requirements.json"

# Requirements were extracted — MUST NOT be 0
jq '.requirements | length' "$RUN/requirements.json"

# Eyeball the IDs against the card
jq -r '.requirements[].id' "$RUN/requirements.json"
```

**Read the card and count the requirements yourself, then compare.** The parser fails silently (gap D6) — a card it cannot parse yields a well-formed file with an empty `sections` array, and the pipeline will happily proceed to generate zero tests and report 100% coverage of nothing.

## Handover

Stage 3 reads `<run-dir>/requirements.json` and turns each entry's `documentation` into an R testthat assertion. Stage 7 reads the same file to summarise requirements.

For that to work:
- The file must be named `requirements.json` and sit directly in the run directory.
- `sections[].requirements[]` must be non-empty.
- Each `documentation` must be specific enough to assert on. "Method: counts subjects" is not testable; "Number of distinct subjects (USUBJID) with at least one important protocol deviation" is.

## Known gaps

| Ref | Gap |
|---|---|
| **D6** | **Silent parse failure.** Section detection requires a literal em-dash — `Section\s+(\d+)\s*—`. A hyphen or en-dash in the card yields zero sections with no warning. Both the section key list and the output heading list are closed whitelists; anything the card calls something else is dropped silently. **Always run the acceptance checks above, and count the card's headings against the extracted IDs.** |
| — | Output blocks end at the next recognised heading. A section that happens to contain a line reading exactly `Column` or `Title` would be read as the start of an output block. Not observed on real cards; check the section requirement counts if a card uses those words as standalone lines. |
| **D8** | Title extraction has an operator-precedence bug (`'Display Description' in line or 'Display' in line and i < 10`), so the `i < 10` guard doesn't apply to the first branch and the title may be taken from anywhere in the card. |
| **D9** | `armada_validate.sh` puts `$REPO_ROOT/.github/scripts` on `sys.path` where `REPO_ROOT` is two levels above the script. Verify the import resolves in your checkout before relying on the script. |
| **D5** | Requirements carry no `type` key, so Stage 7's "Overview by Type" table renders a single `unknown` row. |
| **D14** | The `java` output format and the per-requirement `test_code` field are unused by the pipeline, which validates in R. Ignore both. `test_code` in particular invites Stage 3 to transliterate Java assertions that don't fit ARMADA's UUID graph. |
| — | Output-level footnote detection fires on any line containing `Note:`. |
