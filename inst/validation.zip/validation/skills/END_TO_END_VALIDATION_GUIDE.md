# ARMADA Metadata Validation: Complete End-to-End Pipeline

## Overview

This document shows the complete validation pipeline from ADO card to final traceability reports, with exact commands and agent invocations.

---

## STAGE 1: Extract Requirements from ADO Card

**What:** Read ADO work item and extract structured requirements

**Command:**
```bash
cd /mnt/imported/code/standard-led

./.github/scripts/armada_validate.sh \
  "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" \
  json \
  /tmp/requirements.json
```

**What It Does:**
- Parses ADO card description
- Extracts requirements structured as:
  - 2 output-level requirements (title, footnotes)
  - 18 section-level requirements (6 types × 3 sections)
- Outputs JSON with requirement IDs, documentation, descriptions

**Output File:** `/tmp/requirements.json`

**Output Structure:**
```json
{
  "schema_title": "Summary of Important Protocol Deviations",
  "schema_type": "table",
  "sections": [
    {
      "id": "section-1",
      "number": 1,
      "title": "Any Important Protocol Deviations",
      "requirements": [
        {
          "id": "section-1-display_label",
          "documentation": "Display label must be: Any Important Protocol Deviations",
          "description": "..."
        },
        ...
      ]
    }
  ]
}
```

**Sample Output:**
```
✓ Saved to: /tmp/requirements.json
  - schema_title: Summary of Important Protocol Deviations
  - sections: 3 sections
  - total requirements: 6 per section
  - requirement types: ['display_label', 'method', 'by_variable', 'domain', 'subset', 'denominator']
```

---

## STAGE 2: Collect ARMADA Metadata

**What:** Recursively collect all linked ARMADA metadata entities

**Command:**
```bash
python ./.github/scripts/armada_metadata_collector.py \
  dv_t01_sum_impo_prot_dev_armada \
  --graph /tmp/metadata.json
```

**What It Does:**
- Finds main_aom entity for given output_id
- Recursively follows UUID links
- Collects all related entities (arm, method, label_aom, var_group, etc)
- Outputs JSON graph with 48+ entities

**Output File:** `/tmp/metadata.json`

**Output Structure:**
```json
{
  "output_id": "dv_t01_sum_impo_prot_dev_armada",
  "root_file": "/mnt/code/executor/metadata/main_aom/...",
  "total_entities": 48,
  "entity_counts": {
    "main_aom": 1,
    "section_aom": 3,
    "arm": 3,
    "method": 4,
    "label_aom": 3,
    ...
  },
  "entities": {
    "uuid-1": {
      "entity_type": "main_aom",
      "file_path": "...",
      "entity_id": "dv_t01_sum_impo_prot_dev_armada",
      "data": { ... }
    },
    ...
  }
}
```

**Sample Output:**
```
================================================================================
ARMADA METADATA COLLECTION: dv_t01_sum_impo_prot_dev_armada
================================================================================

✓ Total entities collected: 48

Breakdown by entity type:
  • arm: 3
  • method: 4
  • section_aom: 3
  • var_group: 3
  • format_aom: 4
  ... (19 entity types total)

Metadata graph saved to /tmp/metadata.json
```

---

## STAGE 3: Generate Validation Tests (AGENTIC)

**What:** Use an agent to generate R testthat tests based on requirements and metadata

**Agent Invocation:**
```bash
# NOTE: This uses the agentic system - invoke with:
# - model: general-purpose agent
# - description: "Generate R testthat tests for ARMADA metadata validation"
# - input: skill doc + requirements.json + metadata.json
# - output: test files

# In practice, use:
task --agent general-purpose \
  --name "Generate ARMADA Validation Tests" \
  --prompt "{full prompt with task details}"
```

**Agent Task Specification:**

The agent reads:
1. `.github/skills/armada-metadata-validation.md` (1060-line skill doc)
2. `/tmp/requirements.json` (20 requirements)
3. `/tmp/metadata.json` (48 entities)

The agent generates:
1. `tests/testthat/helper-armada-dv_t01.R`
   - `load_armada_metadata()` — Load JSON files
   - `get_entity(metadata, uuid)` — Resolve UUIDs
   - `get_section_aom(metadata, section_number)` — Get section
   - `split_uuids(uuid_string)` — Split *-separated UUIDs

2. `tests/testthat/test-armada-dv_t01.R`
   - 18 test_that() blocks (6 types × 3 sections)
   - Each test:
     * Extracts expected value from requirements.json
     * Extracts actual value from metadata.json
     * Compares with proper assertions
     * Uses correct display_label patterns

**Generated Files:**
- `tests/testthat/helper-armada-dv_t01.R` (69 lines)
- `tests/testthat/test-armada-dv_t01.R` (517 lines)

**Agent Output:**
```
Created:
- `tests/testthat/helper-armada-dv_t01.R`
- `tests/testthat/test-armada-dv_t01.R`

Result: **9 PASS / 9 FAIL**.

Pass: all `display_label`, `method`, `domain`, `subset` tests.
Fail: all `by_variable` and `denominator` tests.
```

---

## STAGE 4: Run Validation Tests

**What:** Execute R testthat tests to validate metadata against requirements

**Command:**
```bash
cd /mnt/imported/code/standard-led

Rscript -e "testthat::test_file('tests/testthat/test-armada-dv_t01.R')"
```

**What It Does:**
- Loads helper functions
- Loads requirements.json and metadata.json
- Runs 18 tests in testthat framework
- Reports PASS/FAIL for each test
- Shows test progress and summary

**Output:**
```
[ FAIL 9 | WARN 514 | SKIP 0 | PASS 133 ]

Test Results:
✅ PASS (9 tests):
  - display_label (S1, S2, S3)
  - method (S1, S2, S3)
  - domain (S1, S2, S3)
  - subset (S1, S2, S3)

❌ FAIL (9 tests):
  - by_variable (S1, S2, S3) — expected TRT01PN/P, actual TRT01AN/A
  - denominator (S1, S2, S3) — expected enrolled-counts, actual safety-counts
```

---

## STAGE 5: Capture Git Metadata (for Traceability)

**What:** Capture commit information for audit trail

**Command:**
```bash
python ./.github/scripts/capture_git_metadata.py /tmp/git_metadata.json
```

**What It Does:**
- Captures current commit hash
- Records author, date, branch
- Detects uncommitted changes
- Outputs JSON for inclusion in reports

**Output File:** `/tmp/git_metadata.json`

**Output Structure:**
```json
{
  "repository_root": "/mnt/imported/code/standard-led",
  "commit_hash": "76e481fb597096a40b995a0801b3f43f96f56f3f",
  "commit_short": "76e481f",
  "commit_message": "Add comprehensive ARMADA metadata validation system",
  "commit_date": "2026-08-17T16:15:53+00:00",
  "author_name": "Liam Hobby",
  "author_email": "liam.hobby@example.com",
  "branch": "feat/validate-armada",
  "has_uncommitted_changes": false,
  "uncommitted_files": [],
  "validation_timestamp": "2026-08-17T16:22:00.123456"
}
```

---

## STAGE 6: Generate Traceability Matrix (AGENTIC)

**What:** Use an agent to generate detailed traceability reports from test results

**Agent Invocation:**
```bash
# Invoke with:
task --agent general-purpose \
  --name "Generate ARMADA Traceability Matrix" \
  --prompt "{full prompt with task details}"
```

**Agent Task Specification:**

The agent reads:
1. `/tmp/requirements.json` (requirements)
2. `/tmp/metadata.json` (metadata)
3. `/tmp/git_metadata.json` (commit info)
4. `tests/testthat/test-armada-dv_t01.R` (test code)

The agent generates:
1. `tests/documentation/dv_t01-traceability-matrix.md` (12 KB)
   - Commit information header
   - 18 requirement entries with unique test IDs (ARMADA-DV_T01-1-DISPLAY_LABEL-01, etc.)
   - For each test: Status | Requirement | Expected | Actual | Reason | Evidence
   - Summary table by section and type
   - Coverage: 9 PASS / 9 FAIL (50%)

2. `tests/documentation/dv_t01-traceability-matrix.html` (23 KB)
   - Self-contained HTML with embedded JSON
   - Filters: Section, Type, Status
   - Search functionality
   - Color-coded status
   - Coverage summary

**Generated Files:**
- `tests/documentation/dv_t01-traceability-matrix.md` (12 KB)
- `tests/documentation/dv_t01-traceability-matrix.html` (23 KB)

**Agent Output:**
```
Generated both files:
- `tests/documentation/dv_t01-traceability-matrix.md`
- `tests/documentation/dv_t01-traceability-matrix.html`

They include commit metadata, 18 requirement entries with IDs, 
PASS/FAIL status details, evidence, section/type summaries, 
and self-contained HTML with filters/search.
```

---

## STAGE 7: Execute LEDs & Generate ARD/PDF Outputs

**What:** Convert and execute ARMADA metadata to generate Analysis Result Datasets and PDF tables

**Prerequisites:**
- ✅ Validation tests PASSED (Stage 4)
- ✅ Traceability matrix GENERATED (Stage 6)
- ✅ Validation approved for release

**Command:**
```bash
cd /mnt/code

python ../.github/scripts/armada_executor.py \
  --output-id dv_t01_sum_impo_prot_dev_armada \
  --verbose true \
  --log-file executor_logs/dv_t01_execution.log
```

**What It Does:**

1. **Phase 1: Discover ARM files**
   - Reads target AOM YAML
   - Identifies linked ARM metadata files
   - Returns: List of ARM files to convert

2. **Phase 2: Convert ARM → LED**
   - Runs `make convert_1arm what='<arm>.yaml'` for each ARM
   - Generates LED YAML files in `executor/metadata/led/`
   - Returns: List of created ARM LED files

3. **Phase 3: Convert AOM → LED**
   - Runs `make convert_1aom what='<aom>.yaml'` for target AOM
   - Generates LED YAML file in `executor/metadata/led/`
   - Returns: Path to created AOM LED file

4. **Phase 4: Execute ARM LEDs**
   - Runs `make run args='--led <led_name>'` for each ARM LED
   - Creates ARD Parquet files in `/mnt/data/{project}/prod/adamdata/`
   - Returns: Duration and status for each execution

5. **Phase 5: Execute AOM LED**
   - Runs `make run args='--led <led_name>'` for AOM LED
   - Creates final TFL output:
     * PDF table: `/mnt/data/{project}/prod/tfls/`
     * Mock shell HTML: `/mnt/data/{project}/prod/tfls/*_mock.html`
   - Returns: Duration and status

**Output File:** `/mnt/code/executor_logs/dv_t01_execution.log`

**Output Structure:**
```
executor_logs/
  └── dv_t01_execution.log
      ├── Timestamp
      ├── PHASE 1: Discover ARM Files
      │   ├── Target AOM file
      │   ├── Discovered ARM count
      │   └── ARM file list
      ├── PHASE 2: Convert ARM → LED
      │   ├── Command output for each ARM
      │   └── Success/failure status
      ├── PHASE 3: Convert AOM → LED
      │   ├── Command output
      │   └── Success/failure status
      ├── PHASE 4: Execute ARM LEDs
      │   ├── Duration per LED
      │   └── Output file paths
      ├── PHASE 5: Execute AOM LED
      │   ├── Duration
      │   └── Final output paths
      └── EXECUTION SUMMARY
          ├── Status: SUCCESS/FAILED
          ├── Total Duration
          └── File counts
```

**Sample Output:**
```
================================================================================
ARMADA LED Execution Pipeline
Output ID: dv_t01_sum_impo_prot_dev_armada
Dry-run: False
Stop on error: True
================================================================================

PHASE 1: Discover ARM Files
================================================================================
Reading target AOM: dv_t01_sum_impo_prot_dev_armada.yaml
✓ Discovered 3 ARM files:
  - ae-any-count
  - ae-by-soc-count
  - ae-by-soc-pt-count

PHASE 2: Convert ARM → LED
================================================================================
Converting ARM: ae-any-count
✓ Converted: ae-any-count
Converting ARM: ae-by-soc-count
✓ Converted: ae-by-soc-count
Converting ARM: ae-by-soc-pt-count
✓ Converted: ae-by-soc-pt-count
✓ ARM conversion complete: 3/3 succeeded

PHASE 3: Convert AOM → LED
================================================================================
Converting AOM: dv_t01_sum_impo_prot_dev_armada
✓ Converted: dv_t01_sum_impo_prot_dev_armada
✓ AOM conversion complete: 1/1 succeeded

PHASE 4: Execute ARM LEDs
================================================================================
Executing LED: adam_arm_ae_any_count_01
✓ Executed: adam_arm_ae_any_count_01 (12.3s)
Executing LED: adam_arm_ae_by_soc_count_01
✓ Executed: adam_arm_ae_by_soc_count_01 (15.7s)
Executing LED: adam_arm_ae_by_soc_pt_count_01
✓ Executed: adam_arm_ae_by_soc_pt_count_01 (18.2s)
✓ ARM execution complete: 3/3 succeeded

PHASE 5: Execute AOM LED
================================================================================
Executing AOM LED: adam_aom_dv_t01_sum_impo_prot_dev_armada_01
✓ Executed: adam_aom_dv_t01_sum_impo_prot_dev_armada_01 (8.5s)

================================================================================
EXECUTION SUMMARY
================================================================================
Status: SUCCESS
Total Duration: 74.1s
ARM files discovered: 3
ARM files converted: 3
AOM files converted: 1
LEDs created: 4
LEDs executed: 4
================================================================================
```

---

## Full Pipeline: All 7 Stages

### Validation Phase (Stages 1–6)

| Stage | Input | Step | Output |
|-------|-------|------|--------|
| 1 | ADO work item | Extract schema requirements | `requirements.json` |
| 2 | ARMADA metadata | Collect linked entities | `metadata.json` |
| 3 | Requirements + Metadata | (AGENT) Generate validation tests | `test-armada-*.R` |
| 4 | Validation tests | Run tests, capture PASS/FAIL | Test results console |
| 5 | Current git branch | Capture audit trail | `git_metadata.json` |
| 6 | Test results + git info | (AGENT) Generate traceability matrix | `dv_t01-traceability-matrix.*` |

**Outcome:** Metadata is validated against requirements; validation is documented for regulatory submission.

### Execution Phase (Stage 7)

| Stage | Input | Step | Output |
|-------|-------|------|--------|
| 7 | ARM + AOM metadata | Convert and execute LEDs | ARDs + PDFs + execution log |

**Outcome:** Analysis Result Datasets and PDF tables are generated.

---

## Integration with Complete Validation Workflow

```bash
#!/bin/bash
set -e

cd /mnt/imported/code/standard-led

echo "================================================================================"
echo "STAGE 1-6: VALIDATION PIPELINE"
echo "================================================================================"

# Stage 1: Extract requirements from ADO
./.github/scripts/armada_validate.sh \
  "https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276" \
  json /tmp/requirements.json

# Stage 2: Collect ARMADA metadata
python ./.github/scripts/armada_metadata_collector.py \
  dv_t01_sum_impo_prot_dev_armada \
  --graph /tmp/metadata.json

# Stage 3: Generate tests (AGENT)
echo "Stage 3: [AGENT] Generate R testthat tests"
# [Invoke agent to generate tests]

# Stage 4: Run validation tests
Rscript -e "testthat::test_file('tests/testthat/test-armada-dv_t01.R')"

# Stage 5: Capture git metadata
python ./.github/scripts/capture_git_metadata.py /tmp/git_metadata.json

# Stage 6: Generate traceability matrix (AGENT)
echo "Stage 6: [AGENT] Generate traceability matrix"
# [Invoke agent to generate matrix]

echo ""
echo "================================================================================"
echo "VALIDATION COMPLETE"
echo "================================================================================"
echo "Review traceability matrix: tests/documentation/dv_t01-traceability-matrix.html"
echo ""
read -p "Press ENTER to proceed with LED execution (Stage 7)..." 

echo ""
echo "================================================================================"
echo "STAGE 7: LED EXECUTION PIPELINE"
echo "================================================================================"

cd /mnt/code

# Stage 7: Execute LEDs to generate ARDs and PDFs
python ../.github/scripts/armada_executor.py \
  --output-id dv_t01_sum_impo_prot_dev_armada \
  --verbose true \
  --log-file executor_logs/dv_t01_execution.log

echo ""
echo "================================================================================"
echo "EXECUTION COMPLETE"
echo "================================================================================"
echo "ARDs: /mnt/data/\${DOMINO_PROJECT_NAME}/prod/adamdata/"
echo "PDFs: /mnt/data/\${DOMINO_PROJECT_NAME}/prod/tfls/"
echo "Log:  /mnt/code/executor_logs/dv_t01_execution.log"
```

---

## How to Invoke Agents

### General-Purpose Agent for Test Generation

```python
from copilot import task

result = task(
    agent_type="general-purpose",
    name="Generate ARMADA Validation Tests",
    description="Generate R testthat tests for ARMADA metadata validation",
    mode="sync",  # Wait for completion
    prompt="""
STAGE 3: Generate Validation Tests (AGENTIC)

Your task is to generate R testthat validation tests...
[Full prompt from Stage 3 above]
"""
)

# result contains:
# - tests/testthat/helper-armada-dv_t01.R
# - tests/testthat/test-armada-dv_t01.R
# - Test validation output (9 PASS / 9 FAIL)
```

### General-Purpose Agent for Traceability Matrix

```python
from copilot import task

result = task(
    agent_type="general-purpose",
    name="Generate ARMADA Traceability Matrix",
    description="Generate traceability matrix from validation results",
    mode="sync",  # Wait for completion
    prompt="""
STAGE 6: Generate Traceability Matrix (AGENTIC)

Your task is to generate comprehensive traceability matrices...
[Full prompt from Stage 6 above]
"""
)

# result contains:
# - tests/documentation/dv_t01-traceability-matrix.md
# - tests/documentation/dv_t01-traceability-matrix.html
```

---

## STAGE 7: Execute Metadata to Generate ARDs & PDF

**What:** Convert ARMADA metadata to LEDs and execute through Mercury Executor

**Command:**
```bash
cd /mnt/code

python /mnt/imported/code/standard-led/.github/scripts/armada_executor.py \
  --output-id dv_t01_sum_impo_prot_dev_armada \
  --verbose true \
  --log-file executor_logs/dv_t01_execution.log
```

**What It Does:**
1. Discovers all ARM metadata linked to the target AOM
2. Converts each ARM → LED using `arm2led.py`
3. Converts AOM → LED using `aom2led.py`
4. Executes all ARM LEDs (creates ARD datasets)
5. Executes AOM LED (creates final PDF and output)
6. Validates outputs exist and execution succeeded
7. Saves structured results to JSON

**Output Files:**
- `executor_logs/dv_t01_execution.log` — Detailed execution log
- `executor_logs/dv_t01_execution_result.json` — Structured results
- `/mnt/data/{project}/prod/adamdata/` — Generated ARD parquet files
- `/mnt/data/{project}/prod/tfls/dv_t01_sum_impo_prot_dev_armada.pdf` — Final PDF

**Sample Output:**
```json
{
  "status": "success",
  "output_id": "dv_t01_sum_impo_prot_dev_armada",
  "total_duration": 24.4,
  "arms_discovered": 4,
  "arms_converted": ["analysis-set-enrolled-counts", "dv-any-count", "dv-by-acat-adecod-count", "dv-by-acat-count"],
  "aom_converted": "dv_t01_sum_impo_prot_dev_armada",
  "leds_executed": ["analysis-set-enrolled-counts", "dv-any-count", "dv-by-acat-adecod-count", "dv-by-acat-count", "dv_t01_sum_impo_prot_dev_armada"],
  "phases": {
    "arm_discovery": { "status": "success", "duration": 0.3, "items_processed": 4 },
    "arm_conversion": { "status": "success", "duration": 1.7, "items_processed": 4 },
    "arm_execution": { "status": "success", "duration": 13.7, "items_processed": 4 },
    "aom_conversion": { "status": "success", "duration": 0.8, "items_processed": 1 },
    "aom_execution": { "status": "success", "duration": 8.2, "items_processed": 1 }
  }
}
```

**Success Criteria:**
- ✅ All ARM files discovered (including denominator dataset)
- ✅ All ARM files converted to LEDs
- ✅ AOM file converted to LED
- ✅ All LEDs executed without fatal errors
- ✅ PDF output file exists at target location
- ✅ JSON status shows `"success"`

**What Happens Next:**
The unified report generator automatically runs and creates a single comprehensive document combining:
- Commit information (from git)
- Requirements summary (from Stage 1)
- Traceability matrix (from Stage 6 tests)
- Execution verification (from Stage 7 results)

---

## UNIFIED REPORT: Complete Validation Evidence

**What:** Automatic consolidation of all validation and execution evidence into a single regulatory-ready document

**Generated File:** `tests/documentation/{output_id}-validation-report.md`

**Example:** `tests/documentation/dv_t01_sum_impo_prot_dev_armada-validation-report.md`

**Report Contents:**

### Section 1: Commit Information
- Commit hash, author, date, repository, branch
- Links validation to exact code state

### Section 2: Requirements Summary
- Total requirements extracted from schema
- Breakdown by requirement type
- Section-by-section organization

### Section 3: Traceability Matrix
- Requirements → Test mappings
- Test pass/fail status from JUnit
- Overall coverage percentage

### Section 4: Execution Verification
- ARM discovery and conversion results
- All execution phases (discovery → conversion → execution)
- Time for each phase
- Confirmed output artifacts

### Section 5: Combined Assessment
- Synthesis: Are requirements validated AND metadata executed?
- Final recommendation: Fit for regulatory submission?
- Status: COMPLETE

**How It Integrates Execution:**

```
[Stage 7 Execution Completes]
        ↓
[Saves: executor_logs/{id}_result.json]
        ↓
[Report Generator Launches Automatically]
        ↓
[Reads: requirements.json (Stage 1)]
  +     [JUnit XML (Stage 4 tests)]
  +     [git_metadata.json (Stage 5)]
  +     [_result.json (Stage 7 execution)]
        ↓
[Generates: Unified 5-section markdown]
        ↓
[Saves: tests/documentation/{id}-validation-report.md]
        ↓
[Result: Ready for regulatory submission]
```

**Manual Generation (if needed):**
```bash
cd /mnt/code

python .github/scripts/unified_report_generator.py \
  dv_t01_sum_impo_prot_dev_armada \
  tests/documentation/dv_t01_sum_impo_prot_dev_armada-validation-report.md
```

**What You Get:**
- ✅ Single document with all validation evidence
- ✅ Commit information for traceability
- ✅ Requirements validated by automated tests
- ✅ Metadata converted and executed
- ✅ ARDs and PDF confirmed generated
- ✅ Ready to attach to PR/submission

**For Detailed Information:**
See [Unified Report Integration Guide](./UNIFIED_REPORT.md)

---

## Complete Pipeline at a Glance

```
ADO Card (Requirements Source)
    ↓
[Stage 1] Extract requirements → requirements.json
    ↓
[Stage 2] Collect metadata → metadata.json
    ↓
[Stage 3] Generate tests → R test files
    ↓
[Stage 4] Run tests → JUnit XML results
    ↓
[Stage 5] Capture git info → git_metadata.json
    ↓
[Stage 6] Generate traceability matrix → markdown/HTML
    ↓
[Stage 7] Execute metadata → executor_logs/_result.json
    ↓ (automatic)
[UNIFIED] Generate comprehensive report → validation-report.md
    ↓
READY FOR REGULATORY SUBMISSION
```

---

## Next Steps

1. **After Stage 7 Execution**
   - Review unified report: `tests/documentation/{id}-validation-report.md`
   - Verify execution status is SUCCESS
   - Check that PDF was generated

2. **Fix Metadata Issues** (if needed)
   - Update ARMADA YAML files to match requirements
   - Re-run full pipeline (Stages 1-7)
   - Generate new report

3. **For Regulatory Submission**
   - Verify no uncommitted changes: `git status`
   - Commit changes with reference to this pipeline
   - Attach unified report to PR/submission
   - Provide reproducibility instructions

4. **CI/CD Integration**
   - Automate full pipeline in GitHub Actions
   - Run on every PR/commit to feature branch
   - Generate reports automatically
   - Comment on PR with results

5. **Future TFLs**
   - Use same pipeline for other tables/listings/figures
   - All Stages 1-7 follow identical process
   - Reuse test generation and validation logic
   - New TFL = New output_id = New report

