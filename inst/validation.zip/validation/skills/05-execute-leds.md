# Stage 5 — Convert to LEDs and Execute

## Purpose

Convert the ARMADA metadata (ARM and AOM) into Linked Executable Definitions and run them through Mercury Executor, proving the metadata is not merely correct on paper but actually executes and produces the ARDs and PDF.

## Position

Stage 5 of 7. Consumes the ARMADA metadata tree. Feeds **Stage 7 (Validation Summary)**.

Stage 4 validates the metadata *describes* the right analysis. Stage 5 proves it *runs*. Both are needed; neither substitutes for the other.

**Not gated on Stage 4.** Run this even when tests failed — Stage 7 reports validation outcome and execution outcome independently, and an execution failure is itself evidence worth capturing. Do not, however, treat a successful execution as offsetting failed tests.

## Inputs

| Input | Source |
|---|---|
| Output ID | The target `main_aom`, e.g. `dv_t01_sum_impo_prot_dev_armada` |
| Metadata tree | `/mnt/code/executor/metadata/` |
| `Makefile` | `/mnt/code/Makefile` |
| Env vars | `MERCURY_EXECUTOR_PATH`, `LED_TOOLING_PATH`, `MERCURY_METADATA_PATH`, `DOMINO_PROJECT_NAME` |

```bash
# Set in Domino: Environment → Set Variable, or in session:
export MERCURY_EXECUTOR_PATH="/path/to/executor"
export LED_TOOLING_PATH="/path/to/tooling"
export MERCURY_METADATA_PATH="/mnt/code/executor/metadata"
export DOMINO_PROJECT_NAME="project-name"
```

Missing variables produce a **warning, not an error** — the run proceeds and fails later inside `make`.

## Procedure

```bash
cd /mnt/code

python /mnt/imported/code/standard-led/.github/scripts/armada_executor.py \
  --output-id dv_t01_sum_impo_prot_dev_armada \
  --run-dir "$RUN" \
  --verbose true
```

Preview without executing:

```bash
python .../armada_executor.py --output-id <id> --run-dir "$RUN" --dry-run true --verbose true
```

| Option | Default | Effect |
|---|---|---|
| `--output-id` | required | Target AOM |
| `--run-dir` | **required** | Shared run directory. Receives `execution.json` and `execution.log`. Created if absent. |
| `--work-dir` | `/mnt/code` | Root holding `executor/metadata/` and `Makefile` |
| `--dry-run` | `false` | Print commands without running them |
| `--verbose` | `false` | Debug-level logging |
| `--log-file` | `<run-dir>/execution.log` | Override the log location only. The result JSON always goes to the run directory. |
| `--stop-on-error` | `true` | Stop at first failure |

Or via the wrapper: `./.github/scripts/armada_execute.sh <output-id> [options]`.

## Execution order

**Five phases, in this order.** ARM LEDs are executed *before* the AOM is converted, because AOM conversion needs the ARDs the ARM execution produces:

```
PHASE 1  Discover ARM files linked to the target AOM
PHASE 2  Convert ARM → LED
PHASE 3  Execute ARM LEDs        ← creates the ARDs
PHASE 4  Convert AOM → LED       ← needs those ARDs
PHASE 5  Execute AOM LED         ← creates the final PDF
```

> Earlier documentation described convert-ARM → convert-AOM → execute-ARM → execute-AOM. **That ordering is wrong** and does not match `armada_executor.py`.

### The commands actually run

| Phase | Command |
|---|---|
| 2 | `make convert_1arm args='--analysisID <arm> --branch default'` |
| 3 | `make run args='--what <arm>'` |
| 4 | `make convert_1aom args='--outputID <output_id> --branch default'` |
| 5 | `make run args='--what <output_id>'` |

> Earlier documentation showed `what='<file>.yaml'` and `args='--led adam_arm_XXX_01'`. Neither form is used.

### Phase 1 — how ARMs are discovered

Only ARMs belonging to this output are processed:

1. Load `main_aom/<output_id>.yaml`.
2. Take `bigNAnalysisID` if present — the denominator dataset ARM.
3. Split `sections` on `*` into section UUIDs.
4. For each, load `section_aom/<uuid>.yaml` and take its `analyses` field — the ARM name.
5. De-duplicate and sort.

## Outputs

| Output | Location |
|---|---|
| LEDs | `/mnt/code/executor/metadata/led/` |
| ARDs | `/mnt/data/${DOMINO_PROJECT_NAME}/prod/adamdata/*.parquet` |
| PDF | `/mnt/data/${DOMINO_PROJECT_NAME}/prod/` — searched recursively |
| Log | `<run-dir>/execution.log`, or the `--log-file` override |
| **Result JSON** | **`<run-dir>/execution.json`** — always, regardless of `--log-file` |

The result JSON is written on **failure as well as success**. A failed execution is evidence too, and Stage 7 must be able to report on it.

```json
{
  "status": "success",
  "output_id": "dv_t01_sum_impo_prot_dev_armada",
  "total_duration": 24.4,
  "arms_discovered": 4,
  "arms_converted": ["analysis-set-enrolled-counts", "dv-any-count", "dv-by-acat-count", "dv-by-acat-adecod-count"],
  "aom_converted": "dv_t01_sum_impo_prot_dev_armada",
  "leds_created": [], "leds_executed": [], "failed_commands": [],
  "phases": {
    "arm_conversion": { "status": "success", "duration": 1.7, "items_processed": 4, "items_failed": 0 },
    "arm_execution":  { "status": "success", "duration": 13.7, "items_processed": 4, "items_failed": 0 },
    "aom_conversion": { "status": "success", "duration": 0.8, "items_processed": 1, "items_failed": 0 },
    "aom_execution":  { "status": "success", "duration": 8.2, "items_processed": 1, "items_failed": 0 }
  }
}
```

Exit code 0 on success, 1 on failure. JSON goes to stdout on success, stderr on failure.

## Acceptance checks

```bash
# Discovery found the ARMs you expect — compare against section count from Stage 2
grep "Discovered" "$RUN/execution.log"

# Result JSON landed in the run directory
jq '.status, .failed_commands' "$RUN/execution.json"

# Artifacts actually exist
ls -lh /mnt/data/${DOMINO_PROJECT_NAME}/prod/adamdata/
find /mnt/data/${DOMINO_PROJECT_NAME}/prod -name "*.pdf" -newermt "-1 hour"
```

**Verify the PDF yourself.** AOM execution is reported successful if `make` succeeded **or** a PDF of the right name is found anywhere under `/mnt/data` — including one left over from a previous run (gap D10). Check the timestamp.

## Handover

Stage 7 reads `<run-dir>/execution.json` for its execution-verification section. Same run directory, fixed filename — no reconciliation needed.

On success this stage also invokes Stage 7 automatically, passing the same `--run-dir`. That auto-run still fires **only on success** (gap D11), so run Stage 7 explicitly after a failure.

Stage 6 should be run **after** this stage, so the captured environment reflects the session that actually did the execution.

## Known gaps

| Ref | Gap |
|---|---|
| ~~D2~~ | **Resolved.** The result JSON is now written to `<run-dir>/execution.json`, which is exactly what Stage 7 reads. |
| **D10** | AOM execution declares an `output_patterns` list then ignores it, searching all of `/mnt/data` for any PDF matching the output name, and treating a hit as success even when `make` failed. A stale PDF from an earlier run will be read as success. Always check the file's timestamp. |
| **D11** | The executor auto-invokes the Stage 7 report generator, now via `subprocess.run` with the shared `--run-dir` rather than an unquoted `os.system` call. **It still runs only on success** — a failed run, when you most need a report, produces none. Run Stage 7 explicitly after any failure. |
| — | ARM and AOM conversion detect failure by string-matching stderr for `Error raised during processing` / `not found in database` / `No ARMs found`, because `arm2led.py` and `aom2led.py` exit 0 on error. A new error message they don't match will be read as success. |
| — | Every `make` invocation has a 300-second timeout. Long-running ARMs will be reported as failures. |
| **D13** | Env var naming differs from Stage 2 (`MERCURY_METADATA_PATH` here, `MERCURY_ARMAOM_METADATA_PATH` there). Set both. |
