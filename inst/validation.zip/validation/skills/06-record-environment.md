﻿# Stage 6 — Record Environment

## Purpose

Record exactly *what* was validated and *where* it ran: the commit of the metadata under validation, and the environment that validated it — pinned by an `renv` lockfile. Without this the preceding five stages produce results that cannot be reproduced or defended.

## Position

Stage 6 of 7. Consumes the git repository and the live session. Feeds **Stage 7 (Validation Summary)**.

Run **after Stage 5**, so the captured environment is the one that actually ran the tests and the execution — not a fresh session.

## Run it

```bash
./.github/scripts/armada_record_environment.sh --run-dir "$RUN" \
  --repo /path/to/metadata-repo --project /path/to/package-root
```

That wraps both captures. `--repo` is the repository whose commit is being recorded — point it at the **metadata** repository where the metadata and the framework live apart. `--project` is the package root renv scans.

| Exit | Meaning |
|---|---|
| 0 | Captured, clean tree, lockfile written |
| 2 | Usage error |
| 3 | Captured, but **not submittable** — dirty or commitless tree, or no lockfile |

Both steps run even when the first reports a problem: a dirty tree is a finding to record, not a reason to skip the environment capture. The worst exit code is carried to the end.

Run the steps individually if you prefer:

```bash
python ./.github/scripts/armada_record_git.py --run-dir "$RUN" --repo .
Rscript ./.github/scripts/armada_record_env.R --run-dir "$RUN" --project .
```

The manual procedure below is what the scripts do, kept as the specification and the fallback where the scripts cannot run.

## Inputs

| Input | Source |
|---|---|
| Metadata repository | The git repo holding `executor/metadata/` |
| Validation repository | The repo holding the skills, scripts and tests |
| Live R session | For loaded packages |
| `renv` project library | For the lockfile — the primary environment evidence |

## Procedure (what the scripts do)

### Before you start — commit everything

```bash
git status          # must be clean
git add -A && git commit -m "ARMADA metadata for <study> <tfl> v1.0"
```

**Validation run against a dirty working tree is not reproducible** and must not be used for submission. Capturing the dirty state honestly is better than a clean-looking lie, but the correct action is to commit first and re-run.

### Capture commit information

```bash
cat > $RUN/git_metadata.json <<EOF
{
  "repository_root":       "$(git rev-parse --show-toplevel)",
  "commit_hash":           "$(git rev-parse HEAD)",
  "commit_short":          "$(git rev-parse --short HEAD)",
  "commit_message":        "$(git log -1 --pretty=%s | sed 's/"/\\"/g')",
  "commit_date":           "$(git log -1 --pretty=%cI)",
  "author_name":           "$(git log -1 --pretty=%an)",
  "author_email":          "$(git log -1 --pretty=%ae)",
  "branch":                "$(git rev-parse --abbrev-ref HEAD)",
  "has_uncommitted_changes": $( [ -z "$(git status --porcelain)" ] && echo false || echo true ),
  "uncommitted_files":     $(git status --porcelain | awk '{print $2}' | jq -R . | jq -sc .),
  "validation_timestamp":  "$(date -Iseconds)"
}
EOF

jq . $RUN/git_metadata.json
```

Capture this for **both** repositories if the metadata and the validation framework live apart — the commit that matters most is the metadata one.

### Capture the R environment

The R snippet must stay single-quoted so the shell does not expand `si$otherPkgs`, so the output path is passed through an environment variable rather than interpolated:

```bash
ARMADA_ENV_OUT="$RUN/environment.json" Rscript -e '
  si <- sessionInfo()
  pkgs <- unname(c(si$otherPkgs, si$loadedOnly))
  jsonlite::write_json(list(
    r_version   = R.version.string,
    platform    = si$platform,
    running     = si$running,
    packages    = lapply(pkgs, function(p) list(package = p$Package, version = p$Version)),
    captured_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z")
  ), Sys.getenv("ARMADA_ENV_OUT"), auto_unbox = TRUE, pretty = TRUE)
'

jq '.packages | length' "$RUN/environment.json"
```

**`unname()` is required, not cosmetic.** `si$otherPkgs` and `si$loadedOnly` are *named* lists, so `lapply()` preserves the names and jsonlite emits `"packages": {"jsonlite": {...}}` — a JSON object. Stage 7 sorts that value as a list of dicts and dies with `AttributeError: 'str' object has no attribute 'get'`, because iterating an object yields its keys. `unname()` makes it the array Stage 7 expects.

### Capture the renv lockfile

`sessionInfo()` records what happened to be loaded in the *capturing* session. `run_tests.R` runs in its own process, so that is a proxy at best — and the gap is not theoretical:

> On a real run of this framework, `environment.json` captured 11 packages and the lockfile captured 26. Among the 15 the lockfile added was **`xml2`** — the package `ArmadaJunitReporter` is built on, and therefore the one the entire Stage 4 enrichment depends on. `sessionInfo()` missed it because the capturing session never loaded it directly. An evidence package resting on `environment.json` alone would not have recorded the version of the library that produced the JUnit XML.

The lockfile is the real evidence: every package the project uses, plus its recursive dependencies, pinned to an exact version and source.

**If the project is already renv-managed:**

```bash
Rscript -e 'renv::snapshot(prompt = FALSE)'
```

**If it is not** — `snapshot()` needs an renv project, and `renv::init()` would write an `renv/` library and `.Rprofile` into the repository. To produce the same lockfile without that side effect:

```bash
Rscript -e '
  lf <- renv::lockfile_create(project = ".", type = "implicit", prompt = FALSE)
  renv::lockfile_write(lf, file = "renv.lock")
'
```

`type = "implicit"` scans the project's R sources for the packages it actually uses, rather than locking everything installed. Either way, then:

```bash
cp renv.lock "$RUN/renv.lock"

# CHECK — must not be 0, and the run copy must match the project copy
jq '.Packages | length' "$RUN/renv.lock"
sha256sum renv.lock "$RUN/renv.lock"
```

Copy rather than move — `renv.lock` belongs in the repository as well as the run directory.

Run from the project root with the validation library active. If renv reports packages used but not installed, resolve that before continuing: a lockfile that does not describe a working library is worse than none, because it looks like evidence.

Sanity-check the detected set before trusting it:

```bash
Rscript -e 'print(unique(renv::dependencies(".", quiet = TRUE)$Package))'
```

For this framework that is `jsonlite`, `testthat`, `R6`, `xml2`. A short or empty list means the scan missed something — investigate rather than shipping the lockfile.

#### If the project is not renv-managed

Do not silently skip this. Record the absence as a decision:

```bash
cat > "$RUN/renv-not-used.txt" <<EOF
No renv.lock captured for this run.

Reason: <state it — project not renv-managed, renv not installed, etc.>
Fallback evidence: environment.json (sessionInfo of the capturing session)
Recorded by: $(git config user.name) on $(date -Iseconds)
EOF
```

The evidence package then says why the stronger evidence is missing, rather than leaving a reviewer to wonder whether the step was forgotten. `environment.json` is the fallback, with the proxy caveat above.

### Capture the Python environment

Stages 1, 2, 5 and 7 are Python:

```bash
python -V > $RUN/python_environment.txt
pip freeze >> $RUN/python_environment.txt
```

### Capture the execution environment variables

```bash
env | grep -E '^(MERCURY_|LED_|DOMINO_)' | sort > $RUN/env_vars.txt
```

Never capture `ADO_PAT` or any other credential.

## Outputs

| File | Contents |
|---|---|
| `$RUN/git_metadata.json` | Commit hash, branch, author, date, dirty flag, changed files, timestamp |
| `$RUN/environment.json` | R version, platform, loaded packages with versions |
| `$RUN/renv.lock` | Exact dependency lock — **required**, or `renv-not-used.txt` in its place |
| `$RUN/renv-not-used.txt` | Only when the project is not renv-managed: why, and what stands in |
| `$RUN/python_environment.txt` | Python version and installed packages |
| `$RUN/env_vars.txt` | Mercury/LED/Domino environment variables |

## Acceptance checks

```bash
# Commit was captured and the tree was clean
jq '.commit_hash, .branch, .has_uncommitted_changes' $RUN/git_metadata.json

# Packages were captured — must not be 0
jq '.packages | length' $RUN/environment.json

# packages is an ARRAY, not an object — object form crashes Stage 7 (see unname())
jq -e '.packages | type == "array"' $RUN/environment.json

# The lockfile is present, or its absence is recorded
if [ -f "$RUN/renv.lock" ]; then
  jq '.Packages | length' "$RUN/renv.lock"
elif [ -f "$RUN/renv-not-used.txt" ]; then
  echo "no lockfile — absence recorded:"; cat "$RUN/renv-not-used.txt"
else
  echo "INCOMPLETE: neither renv.lock nor renv-not-used.txt in $RUN"
fi
```

**`has_uncommitted_changes` must be `false` for any run intended for submission.** If it is `true`, the commit hash does not describe what was actually validated. Commit and re-run the pipeline from Stage 1.

## Handover

Stage 7 reads `<run-dir>/git_metadata.json` for its commit section and `<run-dir>/environment.json` for its environment section. Both filenames are fixed; both must sit directly in the run directory.

Stage 7 accepts either key spelling — `author_name`/`author`, `commit_date`/`date`, `repository_root`/`repository` — so the schema above renders fully.

`has_uncommitted_changes` is surfaced prominently in the report: `true` produces an explicit warning that the run is not reproducible and must not be submitted.

The other captures — `renv.lock`, `python_environment.txt`, `env_vars.txt` — are not read by Stage 7. They live in the run directory so the whole directory remains the complete evidence package.

**Stage 7 does not check for `renv.lock`.** Its "Evidence complete" criterion covers only the artifacts it reads, so a run missing the lockfile can still report PASS. The acceptance check above is the control; treat it as part of the stage, not an optional extra.

## Known gaps

| Ref | Gap |
|---|---|
| ~~D-A1~~ | **Resolved.** `armada_record_git.py`, `armada_record_env.R` and the `armada_record_environment.sh` wrapper now implement the stage. The never-existent `capture_git_metadata.py` the old documentation referenced in six places is superseded. The manual procedure above is retained as the specification and the fallback. |
| ~~D4~~ | **Resolved.** Stage 7 tolerates both key spellings, and §5 of the report now renders the captured environment. |
| — | `sessionInfo()` captures what is loaded *in the capturing session*. `run_tests.R` runs in its own process, so strictly this is a proxy — measured at 11 packages against the lockfile's 26, missing `xml2`, which Stage 4's reporter depends on. `renv.lock` avoids the problem, which is why it is required rather than optional. |
| — | Nothing in the pipeline enforces the lockfile. Stage 7 neither reads nor checks `renv.lock`, so the acceptance check above is a manual control. |
| — | Nothing enforces the clean-tree rule. It is a manual check, and the pipeline will run happily without it. |
