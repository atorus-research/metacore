# ARMADA Validation Skill

Use this skill to create an agentic function that validates ARMADA metadata against requirements defined in an Azure DevOps (ADO) work item.

---

## Overview

The ARMADA validation skill helps you:

1. **Read ADO work items** — Fetch ADO cards that define display specifications, table schemas, or listing/figure schemas using the card's URL and an ADO Personal Access Token (PAT)
2. **Parse schema instructions** — Extract structured requirements from the work item's description (HTML rich text)
3. **Generate requirements** — Transform schema instructions into a set of validatable requirements, each with:
   - **ID** — unique identifier (kebab-case)
   - **Documentation** — human-readable description of what must be true
   - **Test code** — executable code snippet that validates the requirement (Java/JUnit pseudocode)
   - **Description** — high-level context and rationale

4. **Support future validation** — Output is designed to feed into a JUnit-based test suite that compares ARMADA metadata against the schema (validation implementation is out of scope)

---

## Prerequisites

- **ADO_PAT** environment variable set to your Azure DevOps Personal Access Token
  - If not set, you will be prompted to provide it
  - **Never commit the PAT to source control**
  - Set as a personal environment variable in your Domino profile, not a project variable
  - In Domino: *Account Settings → Environment Variables → Add Variable*

---

## Usage

### Basic Workflow

1. **Identify the ADO work item** — Get the link to the card defining your schema
   - Example: `https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276`

2. **Invoke the skill** — Use the provided functions to fetch and parse the card

3. **Review generated requirements** — Each requirement includes:
   - A unique ID (kebab-case)
   - English-language documentation
   - Test code (JUnit pseudocode for future test generation)
   - Rationale and context

### CLI with File Output

The CLI script supports saving directly to a file:

```bash
# Save JSON to artifact directory
./armada_validate.sh "https://..." json /artifacts/requirements.json

# Save CSV for spreadsheet import
./armada_validate.sh "https://..." csv /artifacts/requirements.csv

# Save Java test class
./armada_validate.sh "https://..." java /artifacts/DvT01ValidationTest.java

# Output to stdout (no file specified)
./armada_validate.sh "https://..." json
```

---

## Core Concepts

### Schema Definition

A schema definition is an ADO work item description that documents:

- **Display/Table/Listing structure** — sections, columns, rows, hierarchies
- **Analysis set and subset rules** — denominator definitions, filtering logic
- **Treatment variable specifications** — by-variable splits, codelist requirements
- **Statistical methods** — distinct subject counts, percentages, aggregations
- **Sorting and formatting** — sort order, indentation, special cases
- **Known issues** — conflicts with mock shells, edge cases to handle

### Requirements

Each requirement extracted from the schema:

| Field | Purpose |
|-------|---------|
| **id** | Unique kebab-case identifier (e.g. `section-1-distinct-subjects-per-treatment`) |
| **documentation** | Plain-English statement of what must be true in the metadata |
| **test_code** | Pseudocode in JUnit/Groovy style for future test generation |
| **description** | Context, rationale, and examples from the schema |

### Example Requirement

```json
{
  "id": "analysis-set-enrolled-subset-rule",
  "documentation": "Analysis set must filter to ENRLFL == 'Y' for Enrolled subset",
  "test_code": "assertEquals('ENRLFL', metadata.analysis_set.subset.variable);\nassertEquals('Y', metadata.analysis_set.subset.value);",
  "description": "Per the mock shell, the default analysis set is 'Enrolled', restricting to subjects with ENRLFL == 'Y'. This is the denominator for all summary statistics in the display."
}
```

---

## API Functions

### `fetch_ado_workitem(url, pat=None)`

Fetches an ADO work item by URL and returns parsed metadata.

**Parameters:**
- `url` (str) — Full ADO work item URL (e.g. `https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276`)
- `pat` (str, optional) — Azure DevOps Personal Access Token (defaults to `ADO_PAT` environment variable)

**Returns:**
```python
{
  "id": int,
  "title": str,
  "description": str,  # plain-text (HTML converted)
  "type": str,
  "state": str,
  "assigned_to": str
}
```

**Raises:**
- `ValueError` — If ADO_PAT is not set and pat is None
- `requests.HTTPError` — If the API call fails (e.g. 404, 401)

---

### `parse_armada_schema(description_text)`

Parses an ARMADA schema description and extracts structured requirements.

**Parameters:**
- `description_text` (str) — Plain-text schema description (output from `fetch_ado_workitem`)

**Returns:**
```python
{
  "schema_title": str,
  "schema_type": str,  # "table", "listing", "figure"
  "display_name": str,
  "sections": [
    {
      "id": str,
      "title": str,
      "requirements": [
        {
          "id": str,
          "documentation": str,
          "test_code": str,
          "description": str
        }
      ]
    }
  ],
  "requirements": [  # top-level requirements
    {
      "id": str,
      "documentation": str,
      "test_code": str,
      "description": str
    }
  ]
}
```

---

### `generate_junit_template(schema_dict, package_name="com.armada.validation")`

*(Advanced)* Generates a JUnit test class template from parsed schema requirements.

**Note:** Test generation and validation is out of scope for this skill but is included for future extension.

**Parameters:**
- `schema_dict` (dict) — Output from `parse_armada_schema`
- `package_name` (str) — Java package for generated test class (default: `com.armada.validation`)

**Returns:**
```python
{
  "class_name": str,  # derived from schema_title
  "package": str,
  "imports": list,
  "test_methods": [
    {
      "name": str,
      "code": str,
      "requirement_id": str
    }
  ],
  "java_source": str  # full JUnit class source
}
```

---

### `save_requirements(schema_dict, output_file, format='json')`

Save requirements to a file in the specified format.

**Parameters:**
- `schema_dict` (dict) — Output from `parse_armada_schema`
- `output_file` (str) — Path to output file (will be created/overwritten)
- `format` (str) — Output format: `json` (default), `csv`, or `java`

**Returns:** None (writes to file)

**Raises:** `ValueError` if format unknown; `IOError` if file cannot be written

**Example:**
```python
from armada_validator import fetch_ado_workitem, parse_armada_schema, save_requirements

wi = fetch_ado_workitem("https://...")
schema = parse_armada_schema(wi['description'])

# Save as JSON
save_requirements(schema, '/artifacts/requirements.json', format='json')

# Save as CSV
save_requirements(schema, '/artifacts/requirements.csv', format='csv')

# Save as Java
save_requirements(schema, '/artifacts/DvT01ValidationTest.java', format='java')
```

---

## Workflow Example

### Step 1: Fetch the ADO Card

```bash
export ADO_PAT="your-pat-here"  # Set if not already in environment

python3 << 'EOF'
from armada_validator import fetch_ado_workitem

wi = fetch_ado_workitem("https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276")
print(f"Title: {wi['title']}")
print(f"Description (first 500 chars):\n{wi['description'][:500]}")
EOF
```

### Step 2: Parse the Schema

```bash
python3 << 'EOF'
from armada_validator import fetch_ado_workitem, parse_armada_schema
import json

wi = fetch_ado_workitem("https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276")
schema = parse_armada_schema(wi['description'])

print(json.dumps(schema, indent=2))
EOF
```

### Step 3: Review Generated Requirements

```bash
python3 << 'EOF'
from armada_validator import fetch_ado_workitem, parse_armada_schema
import json

wi = fetch_ado_workitem("https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276")
schema = parse_armada_schema(wi['description'])

for req in schema.get('requirements', []):
    print(f"ID: {req['id']}")
    print(f"Documentation: {req['documentation']}")
    print(f"Test Code:\n{req['test_code']}\n")
EOF
```

### Step 4: Save Requirements to Files

```bash
python3 << 'EOF'
from armada_validator import fetch_ado_workitem, parse_armada_schema, save_requirements

wi = fetch_ado_workitem("https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276")
schema = parse_armada_schema(wi['description'])

# Save to artifact directory
save_requirements(schema, '/artifacts/dv_t01_requirements.json', format='json')
save_requirements(schema, '/artifacts/dv_t01_requirements.csv', format='csv')
save_requirements(schema, '/artifacts/DvT01ValidationTest.java', format='java')

print("✓ Requirements saved to /artifacts/")
EOF
```

Or use the CLI directly with file output:

```bash
# Save JSON
./armada_validate.sh "https://..." json /artifacts/requirements.json

# Save CSV
./armada_validate.sh "https://..." csv /artifacts/requirements.csv

# Save Java
./armada_validate.sh "https://..." java /artifacts/ValidationTest.java
```

---

## Implementation Notes

### Architecture

- **Stateless functions** — Each function is independent; call them in any order
- **No side effects** — All output is returned as data structures; nothing is written unless explicitly requested
- **HTML parsing** — Descriptions are converted from HTML (ADO's rich text format) to plain text
- **Structured output** — All results are dictionaries (JSON-compatible) for easy serialization and tool integration

### Future Extensions

The skill is designed to support:

1. **Test generation** — Convert requirements to JUnit test classes
2. **Metadata validation** — Compare actual ARMADA metadata YAML against generated requirements
3. **CI/CD integration** — Run validation as part of the build pipeline
4. **Requirement traceability** — Link requirements back to ADO cards for audit trails

---

## Troubleshooting

### ADO_PAT Not Set

**Error:** `ValueError: ADO_PAT environment variable not set`

**Solution:**
```bash
export ADO_PAT="your-personal-access-token"
```

Or set it in Domino: *Account Settings → Environment Variables → Add Variable*

### 401 Unauthorized

**Error:** `requests.exceptions.HTTPError: 401 Client Error: Unauthorized`

**Solution:** Verify the PAT is valid and has permission to read work items in the target project:
```bash
curl -s -H "Authorization: Basic $(echo -n ":$ADO_PAT" | base64)" \
  "https://dev.azure.com/DevOps-RD/PDCA/_apis/wit/workitems/2385276?api-version=7.1" | head -20
```

### 404 Not Found

**Error:** `requests.exceptions.HTTPError: 404 Client Error: Not Found`

**Possible causes:**
- Work item ID does not exist
- Incorrect project name (e.g. PDCA vs. RD_Hyperaccelerating%20Submissions)
- Permission denied for the project

**Solution:** Verify the URL and project name in your ADO organization.

---

## Related Skills

- **ado-workitems** — Create, read, and update ADO cards programmatically
- **r-development** — For writing R code to validate metadata at runtime
- **pr-description** — For documenting validation changes in pull requests

---

## API Version

- **ADO API version:** 7.1
- **Python version:** 3.8+
- **Dependencies:** `requests`, `html.parser` (standard library)

