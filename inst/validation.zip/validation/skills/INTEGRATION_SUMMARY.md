# ARMADA Unified Report: Integration Architecture

## How Execution Results Integrate into the Validation Report

This document explains how Stage 7 (LED Execution) data flows into the final unified validation report that combines evidence from all 7 stages.

---

## Data Flow Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                       STAGE 1-6: VALIDATION                             │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Stage 1: Generate Requirements (requirements.json)                    │
│  Stage 2: Collect Metadata (metadata.json)                             │
│  Stage 3: Create Tests (R test files)                                  │
│  Stage 4: Run Tests (JUnit XML)                                        │
│  Stage 5: Capture Git Info (git_metadata.json)                         │
│  Stage 6: Generate Traceability (markdown + HTML)                      │
│                                                                         │
│  Outcome: Requirements validated by automated tests                   │
│           But metadata NOT YET proven to execute                      │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
                                   ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                    STAGE 7: EXECUTE & DOCUMENT                          │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  [1] Run: python armada_executor.py --output-id <name>                 │
│      └→ Discovers ARM files linked to target AOM                       │
│      └→ Converts each ARM → LED                                        │
│      └→ Converts AOM → LED                                             │
│      └→ Executes all ARM LEDs (creates ARDs)                           │
│      └→ Executes AOM LED (creates PDF)                                 │
│                                                                         │
│  [2] Save: executor_logs/{id}_result.json                              │
│      └→ Captures structured execution results:                         │
│         - arms_discovered: 4                                           │
│         - arms_converted: ["arm1", "arm2", "arm3", "arm4"]             │
│         - aom_converted: "main_aom_id"                                 │
│         - leds_executed: ["led1", "led2", "led3", "led4", "led5"]     │
│         - status: "success"                                            │
│         - total_duration: 24.4                                         │
│         - phases: {arm_discovery, arm_conversion, ...}                 │
│                                                                         │
│  [3] Verify: Confirm output files exist                                │
│      └→ /mnt/data/{project}/prod/adamdata/*.parquet                   │
│      └→ /mnt/data/{project}/prod/tfls/*.pdf                           │
│                                                                         │
│  Outcome: Metadata converted and executed successfully                │
│           Output artifacts (ARDs + PDF) generated                     │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
                                   ↓
        [AUTOMATIC: Unified Report Generator Launches]
                                   ↓
┌─────────────────────────────────────────────────────────────────────────┐
│              UNIFIED REPORT GENERATION (Automatic)                      │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  [1] Load Input Data:                                                  │
│      ├─ requirements.json (Stage 1)                                    │
│      ├─ git_metadata.json (Stage 5)                                    │
│      ├─ junit-results.xml (Stage 4)                                    │
│      └─ executor_logs/{id}_result.json (Stage 7)                       │
│                                                                         │
│  [2] Generate 5-Section Report:                                        │
│      │                                                                  │
│      ├─ Section 1: COMMIT INFO                                         │
│      │  └─ From: git_metadata.json                                     │
│      │  └─ What: Commit hash, author, date, branch                    │
│      │  └─ Why: Proves validation tied to exact code                  │
│      │                                                                  │
│      ├─ Section 2: REQUIREMENTS SUMMARY                                │
│      │  └─ From: requirements.json                                     │
│      │  └─ What: Total requirements, types, sections                  │
│      │  └─ Why: Documents what needed to be validated                 │
│      │                                                                  │
│      ├─ Section 3: TRACEABILITY MATRIX                                 │
│      │  └─ From: junit-results.xml                                     │
│      │  └─ What: Test results, pass/fail, coverage %                  │
│      │  └─ Why: Proves all requirements tested by automation          │
│      │                                                                  │
│      ├─ Section 4: EXECUTION VERIFICATION                              │
│      │  └─ From: executor_logs/{id}_result.json                        │
│      │  └─ What: ARMs discovered, converted, executed                 │
│      │         AOM converted, executed                                │
│      │         Output files confirmed to exist                        │
│      │         Duration for each phase                                │
│      │  └─ Why: Proves metadata operationally viable                  │
│      │                                                                  │
│      └─ Section 5: COMBINED ASSESSMENT                                 │
│         └─ From: ALL sections combined                                 │
│         └─ What: Overall status (validated? executed? fit for sub?)   │
│         └─ Why: Single clear answer: READY FOR SUBMISSION?           │
│                                                                         │
│  [3] Save Report:                                                       │
│      └→ tests/documentation/{id}-validation-report.md                 │
│                                                                         │
│  Outcome: Single unified document with all evidence                   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
                                   ↓
┌─────────────────────────────────────────────────────────────────────────┐
│              FINAL DELIVERABLE FOR REGULATORY SUBMISSION                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  tests/documentation/{id}-validation-report.md                         │
│                                                                         │
│  Contains:                                                              │
│  ✓ Commit information → Reproducibility                               │
│  ✓ Requirements summary → What was required                           │
│  ✓ Traceability matrix → What was tested (validation evidence)        │
│  ✓ Execution verification → What was executed (operational evidence)  │
│  ✓ Combined assessment → Can this be submitted?                       │
│                                                                         │
│  Ready for:                                                             │
│  ✓ Pull request attachment                                            │
│  ✓ Regulatory submission                                              │
│  ✓ Audit trail                                                         │
│  ✓ Approval workflow                                                   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Execution Results → Report Mapping

### Stage 7 Result JSON

```json
{
  "status": "success",
  "output_id": "dv_t01_sum_impo_prot_dev_armada",
  "total_duration": 24.4,
  "arms_discovered": 4,
  "arms_converted": [
    "analysis-set-enrolled-counts",
    "dv-any-count",
    "dv-by-acat-count",
    "dv-by-acat-adecod-count"
  ],
  "aom_converted": "dv_t01_sum_impo_prot_dev_armada",
  "leds_executed": [
    "analysis-set-enrolled-counts",
    "dv-any-count",
    "dv-by-acat-count",
    "dv-by-acat-adecod-count",
    "dv_t01_sum_impo_prot_dev_armada"
  ],
  "phases": {
    "arm_discovery": {
      "status": "success",
      "duration": 0.3,
      "items_processed": 4,
      "items_failed": 0
    },
    "arm_conversion": {
      "status": "success",
      "duration": 1.7,
      "items_processed": 4,
      "items_failed": 0
    },
    "arm_execution": {
      "status": "success",
      "duration": 13.7,
      "items_processed": 4,
      "items_failed": 0
    },
    "aom_conversion": {
      "status": "success",
      "duration": 0.8,
      "items_processed": 1,
      "items_failed": 0
    },
    "aom_execution": {
      "status": "success",
      "duration": 8.2,
      "items_processed": 1,
      "items_failed": 0
    }
  }
}
```

### How It Becomes Report Section 4

```markdown
## 4. EXECUTION VERIFICATION: Operational Evidence

**Execution Date:** 2024-01-15T10:40:15Z
**Total Duration:** 24.4 seconds
**Overall Status:** ✅ SUCCESS

### Phase Summary

- **arm_discovery:** ✅ (0.3s)
- **arm_conversion:** ✅ (1.7s)
- **arm_execution:** ✅ (13.7s)
- **aom_conversion:** ✅ (0.8s)
- **aom_execution:** ✅ (8.2s)

### Discovery Results

**ARM Files Discovered:** 4
**ARM Files Converted:** 4
**AOM Files Converted:** 1

### Execution Results

**LEDs Executed:** 5
- ✅ analysis-set-enrolled-counts
- ✅ dv-any-count
- ✅ dv-by-acat-count
- ✅ dv-by-acat-adecod-count
- ✅ dv_t01_sum_impo_prot_dev_armada
```

---

## Complete Report Example

The unified report brings together:

### BEFORE (Separate Documents)

```
tests/documentation/dv_t01-traceability-matrix.md
  └─ Only has: Requirements → Tests → Results
  └─ Missing: Did it actually execute?

executor_logs/dv_t01_execution.log
  └─ Only has: Raw log output
  └─ Missing: Requirements context

executor_logs/dv_t01_execution_result.json
  └─ Only has: Structured JSON
  └─ Missing: Human-readable format + context
```

### AFTER (Unified Document)

```
tests/documentation/dv_t01-validation-report.md
  ├─ Section 1: Commit Info (context: what code was tested?)
  ├─ Section 2: Requirements (context: what had to pass?)
  ├─ Section 3: Traceability Matrix (validation evidence)
  ├─ Section 4: Execution Verification (operational evidence)
  └─ Section 5: Combined Assessment (final recommendation)

  = Single comprehensive regulatory document
```

---

## Configuration & Customization

### Report Generation

Happens automatically when:
1. Stage 7 execution completes with `status: "success"`
2. Script `unified_report_generator.py` exists
3. Source files accessible from `/mnt/code/`

Manual generation:
```bash
cd /mnt/code

python .github/scripts/unified_report_generator.py \
  dv_t01_sum_impo_prot_dev_armada \
  tests/documentation/dv_t01_sum_impo_prot_dev_armada-validation-report.md
```

### Customize Template

To modify report structure/content, edit:
```
.github/scripts/unified_report_generator.py
```

Key methods to customize:
- `_section_commit()` — Commit info section
- `_section_requirements()` — Requirements summary
- `_section_traceability()` — Test results
- `_section_execution()` — Execution verification
- `_section_summary()` — Combined assessment

---

## Integration Points

### Stage 6 to Stage 7

```
Stage 6: Traceability Matrix Complete
  └─ Proves: Requirements validated by tests
  
  ⬇ Approval gate (human or automated)
  
Stage 7: Execute Metadata
  └─ Proves: Metadata operationally viable
  └─ Generates: executor_logs/{id}_result.json
  
  ⬇ Automatic report generation triggers
  
Unified Report: Complete Evidence
  └─ Combines: Test results + Execution results
  └─ Conclusion: Fit for submission? ✅ or ❌
```

### PR Workflow Integration

```
1. Create Feature Branch (e.g., pa_01)
   └─ Feature branch for new metadata

2. Run Stages 1-6 Validation
   └─ Create tests, run tests
   └─ Generate traceability matrix
   └─ Create PR with test results

3. Stage 7 Approval & Execution
   └─ In PR comments: "Ready for Stage 7?"
   └─ Merge to feature branch
   └─ Run Stage 7 → Generates unified report
   └─ Comment on PR with report link

4. Final Review
   └─ Review unified report (1 document!)
   └─ Approve for merge to main
   └─ Tag with version for release
```

---

## Regulatory Submission Checklist

- [ ] Stage 1-7 pipeline has run completely
- [ ] All automated tests PASSED
- [ ] Stage 7 execution status: SUCCESS
- [ ] Output files (ARDs, PDF) confirmed generated
- [ ] Unified report created: `tests/documentation/{id}-validation-report.md`
- [ ] Commit hash recorded and frozen
- [ ] No uncommitted changes
- [ ] Report reviewed for accuracy
- [ ] Ready for submission

---

## Key Insights

### Why Unified Report Matters

1. **Single Source of Truth**
   - All evidence in one place
   - No scattered documents to reconcile
   - Regulatory auditor sees complete picture

2. **Proof of Validation**
   - Shows requirements extracted from spec
   - Shows all requirements tested
   - Shows metadata actually executes
   - Shows outputs generated

3. **Proof of Execution**
   - Before: Only had traceability matrix (validation)
   - After: Also has execution verification (operational)
   - Together: Complete proof of fitness

4. **Regulatory Ready**
   - Formatted as markdown (easy to convert to PDF)
   - Structured sections (clear narrative)
   - Timestamps and commit info (reproducibility)
   - All evidence cross-linked (traceability)

---

## Files & Locations

```
Implementation:
  .github/scripts/armada_executor.py       ← Main execution engine
  .github/scripts/unified_report_generator.py ← Report generator

Documentation:
  .github/skills/armada-validation/
    ├─ END_TO_END_VALIDATION_GUIDE.md      ← Complete 7-stage pipeline
    ├─ STAGE7_EXECUTION.md                 ← Stage 7 quick start
    ├─ UNIFIED_REPORT.md                   ← Unified report guide
    ├─ armada-led-execution.md             ← API reference
    └─ INTEGRATION_SUMMARY.md              ← This file

Outputs:
  executor_logs/
    ├─ {id}_execution.log                  ← Raw log
    └─ {id}_result.json                    ← Structured results
  
  tests/documentation/
    └─ {id}-validation-report.md           ← Final unified report
```

---

## Quick Links

- **How to run Stage 7:** [STAGE7_EXECUTION.md](./STAGE7_EXECUTION.md)
- **How reports are structured:** [UNIFIED_REPORT.md](./UNIFIED_REPORT.md)
- **Complete pipeline overview:** [END_TO_END_VALIDATION_GUIDE.md](./END_TO_END_VALIDATION_GUIDE.md)
- **API reference:** [armada-led-execution.md](./armada-led-execution.md)
