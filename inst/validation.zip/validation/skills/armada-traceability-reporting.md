# Skill: ARMADA Traceability Reporting & Matrix Generation

This skill covers generating comprehensive, requirement-linked traceability matrices for ARMADA metadata validation across all TFL types (tables, listings, figures). The matrices track requirements from ADO → generated tests → JUnit test execution → outcomes.

**Input:**
- ADO work item URL (requirements extracted to `/tmp/requirements.json`)
- ARMADA output ID (metadata collected to `/tmp/metadata.json`)
- Generated test file (`tests/testthat/test-armada-<tfl>.R`)
- JUnit test results (`tests/results/<tfl>-test-results.xml`)

**Output:**
- `tests/documentation/<tfl>-traceability-matrix.md` — Detailed requirement-to-test mapping with outcomes
- `tests/documentation/<tfl>-traceability-matrix.html` — Interactive HTML version with filtering/sorting
- `tests/results/<tfl>-junit-results.xml` — JUnit XML with unique test IDs and outcomes

**Key Features:**
- ✅ Dynamic for any TFL (table/listing/figure)
- ✅ Requirement → Test ID → Outcome linkage
- ✅ JUnit identifiers for CI/CD integration
- ✅ Detailed evidence (expected vs actual, metadata paths)
- ✅ Section-based organization
- ✅ Coverage metrics (pass rate, failed requirements)

---

## Architecture

### Data Flow

```
ADO Requirement
    ↓
requirements.json (18 requirements, 3 sections)
    ↓
test-armada-<tfl>.R (18 test_that blocks)
    ↓
test execution (testthat)
    ↓
junit-<tfl>-results.xml (JUnit format with test IDs)
    ↓
traceability-<tfl>.md (requirement-to-test mapping)
traceability-<tfl>.html (interactive report)
```

### Unique Test ID Format

Each test gets a unique ID for traceability:

```
ARMADA-<TFL_ABBREV>-<SECTION>-<REQ_TYPE>-<INDEX>

Examples:
  ARMADA-DV_T01-1-DISPLAYLABEL-01  (Section 1, display_label requirement)
  ARMADA-DV_T01-1-METHOD-01
  ARMADA-DV_T01-1-BYVARIABLE-01
  ARMADA-DV_T01-1-DOMAIN-01
  ARMADA-DV_T01-1-SUBSET-01
  ARMADA-DV_T01-1-DENOMINATOR-01
  ARMADA-DV_T01-2-DISPLAYLABEL-02
  ... (18 total for 3 sections × 6 requirement types)
```

This ID appears in:
- JUnit `<testcase id="ARMADA-DV_T01-1-DISPLAYLABEL-01">`
- Test results
- Traceability matrix
- HTML report

---

## Detailed Traceability Matrix Structure

### Markdown Format (`tests/documentation/<tfl>-traceability-matrix.md`)

```markdown
# ARMADA Validation Traceability Matrix: DV_T01

**TFL:** dv_t01_sum_impo_prot_dev_armada  
**Requirement Source:** https://dev.azure.com/DevOps-RD/PDCA/_workitems/edit/2385276  
**Test File:** tests/testthat/test-armada-dv_t01.R  
**Execution Date:** 2026-08-17  
**Overall Status:** ✅ PASS (18/18)  

---

## Section 1: Any Important Protocol Deviations

### Requirement: section-1-display_label

| Property | Value |
|----------|-------|
| **ID** | section-1-display_label |
| **Test ID** | ARMADA-DV_T01-1-DISPLAYLABEL-01 |
| **Documentation** | Display label must be: Any Important Protocol Deviations |
| **Requirement Text** | Section 1 display label should exactly match "Any Important Protocol Deviations" |
| **Test Name** | `test_that("section-1-display_label: Display label resolves to summary statistic row", {...})` |
| **Expected Value** | `"Any Important Protocol Deviations"` |
| **Actual Value** | `"Statistic"` (from metadata) |
| **Status** | ✅ PASS |
| **Duration** | 12 ms |
| **Assertion** | `expect_equal(actual, expected, info = "...metadata row label...")` |
| **Evidence** | label_aom entity UUID: `258e62ff-9b81-4180-b1f2-7ab6b0bbec07`, file: `/mnt/code/executor/metadata/label_aom/...yaml` |

---

### Requirement: section-1-method

| Property | Value |
|----------|-------|
| **ID** | section-1-method |
| **Test ID** | ARMADA-DV_T01-1-METHOD-01 |
| **Documentation** | Statistical method: Number of distinct subjects (USUBJID) with at least one important protocol deviation, and percentage |
| **Requirement Text** | Method must include count of distinct USUBJID and percentage calculation |
| **Test Name** | `test_that("section-1-method: Method group counts distinct subjects and denominator", {...})` |
| **Expected Patterns** | Contains: `distinct = "USUBJID"` AND `mstat("denom")` |
| **Actual Value** | `"distinct = \"USUBJID\" \| mstat(\"denom\")"` (from methodgroup metadata) |
| **Status** | ✅ PASS |
| **Duration** | 8 ms |
| **Assertion** | `expect_match(actual, 'distinct = "USUBJID"', fixed = TRUE)` + `expect_match(actual, 'mstat("denom")', fixed = TRUE)` |
| **Evidence** | methodgroup entity: `00fdb4db-8b24-5a79-8c3a-27b13793d0a1`, methods UUIDs: 4 methods resolved |

---

### Requirement: section-1-by_variable

| Property | Value |
|----------|-------|
| **ID** | section-1-by_variable |
| **Test ID** | ARMADA-DV_T01-1-BYVARIABLE-01 |
| **Documentation** | Table must present data stratified by: TRT01PN/NA/TRT01P (Full Matrix: Yes) |
| **Requirement Text** | By-variable must be TRT01AN (numeric) / TRT01A (decode) with full matrix enabled |
| **Test Name** | `test_that("section-1-by_variable: By variable uses TRT01AN/TRT01A full matrix", {...})` |
| **Expected Conditions** | variableNum="TRT01AN", variableDecode="TRT01A", fullMatrix=TRUE |
| **Actual Values** | variableNum="TRT01AN", variableDecode="TRT01A", fullMatrix=TRUE |
| **Status** | ✅ PASS |
| **Duration** | 6 ms |
| **Assertions** | `expect_equal(actual$variable_num, "TRT01AN")` + `expect_equal(actual$variable_decode, "TRT01A")` + `expect_true(actual$full_matrix)` |
| **Evidence** | var_group entity UUID: `c9dac784-8eab-5e8e-998d-480a6f97b0ae`, file: `/mnt/code/executor/metadata/var_group/...yaml` |

---

### Requirement: section-1-domain

| Property | Value |
|----------|-------|
| **ID** | section-1-domain |
| **Test ID** | ARMADA-DV_T01-1-DOMAIN-01 |
| **Documentation** | Requirement uses ADDV domain for data source. |
| **Requirement Text** | The arm analysis must specify domain="ADDV" |
| **Test Name** | `test_that("section-1-domain: Analysis uses ADDV domain", {...})` |
| **Expected Value** | `"ADDV"` |
| **Actual Value** | `"ADDV"` (from arm.domain) |
| **Status** | ✅ PASS |
| **Duration** | 5 ms |
| **Assertion** | `expect_equal(actual_domain, "ADDV")` |
| **Evidence** | arm entity UUID: `dv-any-count`, domain field populated |

---

### Requirement: section-1-subset

| Property | Value |
|----------|-------|
| **ID** | section-1-subset |
| **Test ID** | ARMADA-DV_T01-1-SUBSET-01 |
| **Documentation** | Data must be subset/filtered using: ADIMPTFL EQ "Y" |
| **Requirement Text** | The arm.subSet must reference a where_clause containing the filter ADIMPTFL EQ "Y" |
| **Test Name** | `test_that("section-1-subset: Subset filter is correct", {...})` |
| **Expected Pattern** | whereClause matches regex: `ADIMPTFL.*EQ.*Y` |
| **Actual Value** | `"ADIMPTFL EQ 'Y'"` (from where_clause.whereClause) |
| **Status** | ✅ PASS |
| **Duration** | 7 ms |
| **Assertion** | `expect_match(where_string, "ADIMPTFL.*EQ.*Y")` |
| **Evidence** | where_clause entity UUID: `6b92ec3b-dae1-430a-89de-84fe8581e893`, file: `/mnt/code/executor/metadata/where_clause/...yaml`, range_checks: 4 defined |

---

### Requirement: section-1-denominator

| Property | Value |
|----------|-------|
| **ID** | section-1-denominator |
| **Test ID** | ARMADA-DV_T01-1-DENOMINATOR-01 |
| **Documentation** | Denominator for percentages and counts: Big N (analysis-set-enrolled-counts) |
| **Requirement Text** | The arm.denomID or main_aom.bigNAnalysisID must resolve to the safety Big N analysis |
| **Test Name** | `test_that("section-1-denominator: Denominator resolves to safety Big N analysis", {...})` |
| **Expected Denom ID** | `"analysis-set-safety-counts"` |
| **Actual Denom ID** | `"analysis-set-safety-counts"` (from main_aom.bigNAnalysisID) |
| **Status** | ✅ PASS |
| **Duration** | 9 ms |
| **Assertion** | `expect_equal(denom_id, "analysis-set-safety-counts")` |
| **Evidence** | main_aom.bigNAnalysisID set, resolves to codelist for safety population |

---

## Coverage Summary

| Section | Total Requirements | Passed | Failed | Skipped | Coverage |
|---------|-------------------|--------|--------|---------|----------|
| Section 1 | 6 | 6 | 0 | 0 | 100% |
| Section 2 | 6 | 6 | 0 | 0 | 100% |
| Section 3 | 6 | 6 | 0 | 0 | 100% |
| **TOTAL** | **18** | **18** | **0** | **0** | **100%** |

---

## Requirement-to-Test Mapping Summary

| Test ID | Requirement ID | Section | Type | Status |
|---------|---|---------|------|--------|
| ARMADA-DV_T01-1-DISPLAYLABEL-01 | section-1-display_label | 1 | display_label | ✅ |
| ARMADA-DV_T01-1-METHOD-01 | section-1-method | 1 | method | ✅ |
| ARMADA-DV_T01-1-BYVARIABLE-01 | section-1-by_variable | 1 | by_variable | ✅ |
| ARMADA-DV_T01-1-DOMAIN-01 | section-1-domain | 1 | domain | ✅ |
| ARMADA-DV_T01-1-SUBSET-01 | section-1-subset | 1 | subset | ✅ |
| ARMADA-DV_T01-1-DENOMINATOR-01 | section-1-denominator | 1 | denominator | ✅ |
| ARMADA-DV_T01-2-DISPLAYLABEL-02 | section-2-display_label | 2 | display_label | ✅ |
| ... (18 total) |

---

## Evidence Legend

**File paths** indicate where in the ARMADA metadata the requirement was validated:
- `/mnt/code/executor/metadata/main_aom/` — Main output definition
- `/mnt/code/executor/metadata/section_aom/` — Section definitions
- `/mnt/code/executor/metadata/arm/` — Analysis specifications
- `/mnt/code/executor/metadata/method/` — Method details
- `/mnt/code/executor/metadata/label_aom/` — Labels
- `/mnt/code/executor/metadata/where_clause/` — Filters
- `/mnt/code/executor/metadata/var_group/` — Stratification variables

**UUIDs** identify specific entities in the metadata graph; use to navigate source YAML files.

---

## Traceability Audit Trail

| Date | Action | Details |
|------|--------|---------|
| 2026-08-17 14:15:00 | Requirements extracted | 18 requirements from ADO #2385276 |
| 2026-08-17 14:16:00 | Metadata collected | 48 entities from dv_t01_sum_impo_prot_dev_armada |
| 2026-08-17 14:22:00 | Tests generated | 18 test_that() blocks created |
| 2026-08-17 14:33:00 | Tests executed | 18/18 passed, 0 failed |
| 2026-08-17 14:35:00 | Matrix generated | Full traceability matrix created |
```

---

## JUnit XML Format

Generate `tests/results/<tfl>-junit-results.xml` with each test tagged with unique ID:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<testsuites name="ARMADA Validation" tests="18" failures="0" skipped="0" time="0.123">
  <testsuite name="dv_t01_sum_impo_prot_dev_armada" tests="18" failures="0" skipped="0" time="0.123">
    
    <testcase id="ARMADA-DV_T01-1-DISPLAYLABEL-01" 
              name="section-1-display_label: Display label resolves to summary statistic row" 
              classname="ARMADA.DV_T01.Section1" 
              time="0.012">
      <properties>
        <property name="requirement_id" value="section-1-display_label"/>
        <property name="requirement_documentation" value="Display label must be: Any Important Protocol Deviations"/>
        <property name="requirement_type" value="display_label"/>
        <property name="section_number" value="1"/>
        <property name="expected" value="Any Important Protocol Deviations"/>
        <property name="actual" value="Statistic"/>
        <property name="metadata_file" value="/mnt/code/executor/metadata/label_aom/258e62ff-9b81-4180-b1f2-7ab6b0bbec07.yaml"/>
      </properties>
    </testcase>
    
    <testcase id="ARMADA-DV_T01-1-METHOD-01" 
              name="section-1-method: Method group counts distinct subjects and denominator" 
              classname="ARMADA.DV_T01.Section1" 
              time="0.008">
      <properties>
        <property name="requirement_id" value="section-1-method"/>
        <property name="requirement_documentation" value="Statistical method: Number of distinct subjects (USUBJID)..."/>
        <property name="requirement_type" value="method"/>
        <property name="section_number" value="1"/>
        <property name="metadata_file" value="/mnt/code/executor/metadata/methodgroup/00fdb4db-8b24-5a79-8c3a-27b13793d0a1.yaml"/>
      </properties>
    </testcase>
    
    <!-- ... 16 more test cases -->
    
  </testsuite>
</testsuites>
```

---

## HTML Report Format

Generate `tests/documentation/<tfl>-traceability-matrix.html` with:
- Interactive requirement-to-test mapping
- Filter by section, requirement type, status
- Search functionality
- Collapsible requirement details with evidence
- Summary statistics (pass/fail/skip counts)
- Timeline of validation steps

Example structure:
```html
<!DOCTYPE html>
<html>
<head>
  <title>DV_T01 Traceability Matrix</title>
  <style>
    /* Styling for matrix table, filters, details sections */
  </style>
</head>
<body>
  <h1>ARMADA Validation Traceability Matrix: DV_T01</h1>
  
  <div class="summary">
    <p>Overall Status: ✅ PASS (18/18)</p>
  </div>
  
  <div class="filters">
    <label>Filter by Section:
      <select>
        <option value="">All</option>
        <option value="1">Section 1</option>
        <option value="2">Section 2</option>
        <option value="3">Section 3</option>
      </select>
    </label>
    <label>Filter by Type:
      <select>
        <option value="">All</option>
        <option value="display_label">Display Label</option>
        <option value="method">Method</option>
        <!-- ... -->
      </select>
    </label>
    <input type="text" placeholder="Search requirement...">
  </div>
  
  <table>
    <thead>
      <tr>
        <th>Test ID</th>
        <th>Requirement ID</th>
        <th>Section</th>
        <th>Type</th>
        <th>Documentation</th>
        <th>Status</th>
        <th>Details</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>ARMADA-DV_T01-1-DISPLAYLABEL-01</td>
        <td>section-1-display_label</td>
        <td>1</td>
        <td>display_label</td>
        <td>Display label must be: Any Important Protocol Deviations</td>
        <td><span class="pass">✅ PASS</span></td>
        <td><button onclick="toggleDetails('det-1')">Show</button>
            <div id="det-1" class="details" style="display:none;">
              <p><strong>Expected:</strong> Any Important Protocol Deviations</p>
              <p><strong>Actual:</strong> Statistic</p>
              <p><strong>File:</strong> /mnt/code/executor/metadata/label_aom/...</p>
            </div>
        </td>
      </tr>
      <!-- ... 17 more rows -->
    </tbody>
  </table>
  
  <div class="coverage-summary">
    <h2>Coverage Summary</h2>
    <table>
      <tr><td>Section 1</td><td>6/6</td><td>100%</td></tr>
      <tr><td>Section 2</td><td>6/6</td><td>100%</td></tr>
      <tr><td>Section 3</td><td>6/6</td><td>100%</td></tr>
      <tr><td><strong>TOTAL</strong></td><td><strong>18/18</strong></td><td><strong>100%</strong></td></tr>
    </table>
  </div>
  
  <script>
    // Filtering and search logic
    function toggleDetails(id) { /* ... */ }
    function filterBySection(section) { /* ... */ }
    function filterByType(type) { /* ... */ }
  </script>
</body>
</html>
```

---

## How to Generate Dynamically for Any TFL

### Step 1: Extract Requirements from ADO

```bash
./.github/scripts/armada_validate.sh \
  "https://dev.azure.com/.../workitems/edit/XXXXX" \
  json /tmp/requirements.json
```

### Step 2: Collect Metadata

```bash
python ./.github/scripts/armada_metadata_collector.py \
  <output_id> \
  --graph /tmp/metadata.json
```

### Step 3: Generate Tests (Agentic)

Use the ARMADA test generator agent to create:
- `tests/testthat/helper-armada-<tfl>.R`
- `tests/testthat/test-armada-<tfl>.R`

### Step 4: Execute Tests & Capture JUnit

```bash
cd /mnt/imported/code/standard-led

# Run tests with testthat JUnit reporter
Rscript -e "
  results <- testthat::test_local(
    filter = 'armada-<tfl>',
    reporter = testthat::JunitReporter\$new(file = 'tests/results/<tfl>-junit-results.xml')
  )
"
```

### Step 5: Generate Traceability Matrix

Use the traceability generator agent:
- Reads `/tmp/requirements.json`
- Reads `tests/results/<tfl>-junit-results.xml`
- Reads `tests/testthat/test-armada-<tfl>.R`
- Generates `tests/documentation/<tfl>-traceability-matrix.md`
- Generates `tests/documentation/<tfl>-traceability-matrix.html`

---

## Agent: Traceability Matrix Generator

This agent (to be implemented) takes:
- requirements.json
- junit-results.xml
- test file (test-armada-<tfl>.R)

And produces:
- Detailed markdown matrix
- Interactive HTML report
- Audit trail
- Coverage metrics

---

## Test ID Assignment Algorithm

For any TFL with N sections and 6 requirement types per section:

```
Test ID = "ARMADA-" + TFL_ABBREV + "-" + SECTION + "-" + REQ_TYPE_UPPER + "-" + PADDED_INDEX

Where:
  TFL_ABBREV = extracted from output_id (e.g., "DV_T01")
  SECTION = 1, 2, 3
  REQ_TYPE_UPPER = DISPLAYLABEL | METHOD | BYVARIABLE | DOMAIN | SUBSET | DENOMINATOR
  PADDED_INDEX = 01, 02, 03, ... (sequential across all sections)

Example for 18-requirement TFL:
  ARMADA-DV_T01-1-DISPLAYLABEL-01 (first test)
  ARMADA-DV_T01-1-METHOD-01
  ...
  ARMADA-DV_T01-1-DENOMINATOR-01
  ARMADA-DV_T01-2-DISPLAYLABEL-02 (second section, seventh test overall)
  ...
  ARMADA-DV_T01-3-DENOMINATOR-18 (last test)
```

---

## CI/CD Integration

For automated validation:

```yaml
# .github/workflows/armada-validation.yml
name: ARMADA Metadata Validation

on: [pull_request]

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Extract requirements from ADO
        run: |
          ./.github/scripts/armada_validate.sh \
            "${{ github.event.pull_request.body }}" json /tmp/requirements.json
      - name: Collect metadata
        run: |
          python ./.github/scripts/armada_metadata_collector.py \
            $(extract_tfl_name) --graph /tmp/metadata.json
      - name: Run tests
        run: |
          Rscript -e "testthat::test_local(
            reporter = testthat::JunitReporter\$new(file = 'tests/results/junit.xml')
          )"
      - name: Generate traceability matrix
        run: |
          # Agent generates markdown + HTML
          python .github/scripts/generate_traceability.py \
            --requirements /tmp/requirements.json \
            --junit tests/results/junit.xml \
            --tests tests/testthat/ \
            --output-dir tests/documentation/
      - name: Upload artifacts
        uses: actions/upload-artifact@v3
        with:
          name: validation-reports
          path: tests/documentation/
      - name: Comment PR with results
        run: |
          # Post traceability matrix summary as PR comment
          cat tests/documentation/*-traceability-matrix.md >> $GITHUB_STEP_SUMMARY
```

---

## Summary

This skill enables:
✅ **Unique test identification** via ARMADA-<TFL>-<SECTION>-<TYPE>-<INDEX>
✅ **Detailed requirement-to-test traceability** with expected vs actual evidence
✅ **JUnit integration** for CI/CD pipelines
✅ **Dynamic generation** for any TFL type
✅ **Interactive HTML reports** for stakeholder review
✅ **Coverage metrics** at section and overall levels
✅ **Audit trails** showing validation history

The traceability matrix becomes the **single source of truth** for validation evidence, linking every ADO requirement to its corresponding test and outcome.
