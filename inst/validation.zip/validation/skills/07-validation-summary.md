# Stage 7 — Generate the Validation Summary

## Purpose

Consolidate every preceding stage into one document: what was required, what was tested, what passed, that the metadata executed, and against which commit and environment.

## Position

Stage 7 of 7. Consumes Stages 1, 4, 5 and 6. Produces the deliverable.

The verdict is **derived from the evidence**, and the exit code follows it. This report states findings; it does **not** certify fitness for regulatory submission — that judgement is a human one, recorded outside this document.

> **The report structure is defined by [`templates/validation-report-template.md`](../templates/validation-report-template.md), not by this skill.** That template is the contract: six sections, their order, their sources, and the rules for computing the verdict. `unified_report_generator.py` is its reference implementation.
>
> Anything that produces a validation report — the script, an agentic skill, a different model, a human — follows that template so that two reports are always comparable. If the script and the template ever disagree, that is a defect in one of them; reconcile before relying on the output. This skill describes *how to run* the stage; the template describes *what the output must be*.
>
> [`templates/example-validation-report.md`](../templates/example-validation-report.md) is a conforming report to compare against.

## Inputs

Every input is read from the shared run directory. Filenames are fixed; nothing needs reconciling.

| Input | Path | Produced by |
|---|---|---|
| Requirements | `<run-dir>/requirements.json` | Stage 1 |
| Metadata | `<run-dir>/metadata.json` | Stage 2 |
| Test results | `<run-dir>/junit/*.xml` — **all files, aggregated** | Stage 4 |
| Execution results | `<run-dir>/execution.json` | Stage 5 |
| Git metadata | `<run-dir>/git_metadata.json` | Stage 6 |
| Environment | `<run-dir>/environment.json` | Stage 6 |

Any input that is absent is **named explicitly** in a warning block at the top of the report and on stderr, and the generator exits 1. A missing input can no longer pass unnoticed as an empty section.

## Procedure

```bash
python ./.github/scripts/unified_report_generator.py \
  dv_t01_sum_impo_prot_dev_armada \
  --run-dir "$RUN"
```

| Option | Default | Effect |
|---|---|---|
| `output_id` | required | Positional. Target AOM. |
| `--run-dir` | **required** | Shared run directory holding every stage's artifacts |
| `--output` | `<run-dir>/validation-report.md` | Override the report path |

The generator is also invoked automatically at the end of Stage 5 with the same run directory, but **only on success** (gap D11). Run it explicitly after a failure.

## Outputs

**`<run-dir>/validation-report.md`** — six sections, per [the template](../templates/validation-report-template.md):

| § | Section | Source | Answers |
|---|---|---|---|
| 1 | Commit Information | `git_metadata.json` | Which version was validated? |
| 2 | Requirements Summary | `requirements.json` | What had to be true? |
| 3 | Traceability Matrix | `junit/*.xml` | What was tested, and did it pass? |
| 4 | Execution Verification | `execution.json` | Did the metadata actually run? |
| 5 | Environment | `environment.json` | What was it run with? |
| 6 | Validation Criteria | all of the above | Which criteria are met? |

The template also fixes the absence line for each section, so a missing artifact reads the same way in every report rather than becoming an empty table.

### The seven criteria

§6 evaluates each against the evidence and shows met / not met / could-not-assess with the reasoning:

| # | Criterion | Met when |
|---|---|---|
| 1 | Evidence complete | Every stage wrote its artifact to the run directory |
| 2 | Tests executed | At least one test ran — an empty suite is not a pass |
| 3 | All tests passed | No failures or errors |
| 4 | Skips justified | Every skipped test carries a stated reason |
| 5 | Requirement coverage | Every requirement in `requirements.json` has ≥1 test |
| 6 | Execution succeeded | Stage 5 status is `success` with no failed commands |
| 7 | Working tree clean | No uncommitted changes at validation time |

### Verdict and exit code

| Verdict | Exit | Meaning |
|---|---|---|
| `PASS` | 0 | Every criterion met |
| `FAIL` | 1 | At least one criterion not met — the evidence shows a problem |
| `INCOMPLETE` | 3 | Evidence missing or unassessable — **no determination possible** |
| — | 2 | Usage error: run directory missing, or `--run-dir` omitted |

`INCOMPLETE` takes precedence over `FAIL`. "The evidence shows a problem" and "the evidence is absent" are different situations with different remedies, and collapsing them would let a half-run pipeline read as a substantive failure.

The exit code makes this usable as a pipeline gate.

### Skips

Skipping is permitted — Stage 3 uses `skip_if_not()` for genuinely optional metadata — but **a skip with no stated reason fails criterion 4**. Write skips as `skip("subSet is optional for this arm and is absent")`, never a bare `skip("")`. The reason is reproduced in the §3 coverage table.

### How requirements are matched to tests

testthat rewrites the `test_that()` description into the JUnit `name` attribute, collapsing every run of non-alphanumeric characters to a single underscore:

```
test_that("section-1-display_label: ...")  →  name="section_1_display_label_..."
```

So the generator normalises **both** the requirement ID and the test name the same way before comparing, then matches when the test name equals the requirement ID or continues it at an underscore boundary. The boundary check stops `output-title` from claiming `output-titles`' tests.

This is why Stage 3's naming convention matters: a test whose name does not begin with a requirement ID is reported in §3 as untraceable, and its requirement counts as untested.

### Traceability

Linkage uses two mechanisms, in order of reliability:

1. **The `requirement_id` property** emitted per assertion by `ArmadaJunitReporter` (Stage 4). Exact, and independent of how testthat rewrites test descriptions. A test that declares its requirement is matched by that alone.
2. **Name-prefix matching**, for XML from the stock reporter — the normalised rules described above.

Where the enriched properties are present, §3 gains an **Assertion Detail** table: one row per assertion carrying test ID, requirement ID, expected, actual, metadata UUID and metadata path. This is what makes a *pass* auditable rather than merely green — a reviewer can confirm the assertion compared the right values, and follow the UUID into `metadata.json` and `metadata_snapshot/`. Assertions without properties (precondition guards) are counted in a note beneath the table.

Failures are cited by test ID (`ARMADA-DV_T01-1-BY_VARIABLE-01`) rather than testthat's rewritten name, with expected, actual and the metadata UUID beneath.

## Acceptance checks

Do not accept this document without checking it against its own sources:

```bash
python ./.github/scripts/unified_report_generator.py <output_id> --run-dir "$RUN"
echo "exit=$?"   # 0 PASS · 1 FAIL · 3 INCOMPLETE · 2 usage error
```

The exit code is the acceptance check. Any criterion not met is printed to stderr with its reason, and appears in §6 of the report.

Then read the report — the criteria table answers *what* failed, but only you can judge whether the pipeline asked the right questions:

| Check | Against |
|---|---|
| Does the requirement count match the card? | `requirements.json`, and the ADO card itself |
| Are the §3 coverage rows the requirements you expect? | The ADO card |
| Is every skip reason in §3 actually acceptable? | Your judgement — the tool only checks a reason exists |
| Are any tests listed as untraceable in §3? | Stage 3's naming convention |
| Are the ARD and PDF timestamps from this run? | `/mnt/data/${DOMINO_PROJECT_NAME}/prod/` |

Then verify by hand:

**A `PASS` verdict means every criterion the tool can check is met — not that the metadata is fit for submission.** The tool cannot judge whether the requirements were the right requirements, whether a skip reason is genuinely acceptable, or whether the tests assert what they claim to. Those remain human determinations, and the report says so explicitly rather than asserting fitness itself.

## Handover

This is the terminal stage. **The submission package is the run directory itself** — every stage has written into it:

```
<run-dir>/
├── requirements.json        Stage 1
├── metadata.json            Stage 2
├── metadata_snapshot/       Stage 2 (optional)
├── junit/*.xml              Stage 4
├── execution.json           Stage 5
├── execution.log            Stage 5
├── git_metadata.json        Stage 6
├── environment.json         Stage 6
├── renv.lock                Stage 6 (optional)
└── validation-report.md     Stage 7
```

Add the generated tests from Stage 3 (`tests/testthat/*-armada-<tfl>.R`), which live in the package rather than the run directory.

Before submitting: the tree was clean at validation time, all tests passed or every failure is documented and accepted, execution succeeded, the output artifacts carry this run's timestamps, and the verdict in §5 has been verified by hand rather than taken from the template.

## Known gaps

| Ref | Gap |
|---|---|
| ~~D1~~ | **Resolved.** §6 evaluates seven criteria against the evidence and reports PASS / FAIL / INCOMPLETE with reasons; the exit code follows. The fitness-for-submission assertion has been removed — the report states findings and defers the determination to a named reviewer. |
| ~~D2~~ | **Resolved.** Reads `<run-dir>/execution.json`, which is what Stage 5 writes. |
| ~~D3~~ | **Resolved.** Reads and aggregates `<run-dir>/junit/*.xml`, which is what Stage 4 writes. |
| ~~D4~~ | **Resolved.** Both key spellings accepted. |
| ~~D12~~ | **Resolved.** Coverage arithmetic is guarded when the test total is 0. |
| **D5** | §2's "Overview by Type" counts a `type` key that Stage 1 never emits, so it renders one `unknown` row. Unchanged. |
| — | **No full requirements list.** §2 gives counts only. Your stated requirement is a *full list* in the summary. Extract it manually until this is built: `jq -r '.requirements[] \| "- \(.id): \(.documentation)"' "$RUN/requirements.json"` |
| **D11** | Auto-generation from Stage 5 now uses `subprocess.run` with the shared run directory, but still fires **only on success**. |

D1, D2, D3, D4 and D12 are all fixed. The summary reports real test results, real execution evidence and real commit details, and its verdict is computed from them. What remains is D5 (the type table) and the absence of a full requirements listing.
