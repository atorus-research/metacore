# Stage 4 — Run Validation Tests

## Purpose

Execute the generated testthat suite against the collected metadata and emit JUnit XML as the machine-readable record of which requirements passed.

## Position

Stage 4 of 7. Consumes **Stage 3** (test files) plus the Stage 1 and 2 JSON the helpers load at runtime. Feeds **Stage 7 (Validation Summary)**.

## Inputs

| Input | Path | From |
|---|---|---|
| Test suite | `tests/testthat/test-armada-<tfl>.R` | Stage 3 |
| Helpers | `tests/testthat/helper-armada-<tfl>.R` | Stage 3 |
| Requirements | `<run-dir>/requirements.json` | Stage 1 — read at test runtime via the helper's `ARMADA_RUN_DIR` |
| Metadata | `<run-dir>/metadata.json` | Stage 2 — read at test runtime via the helper's `ARMADA_RUN_DIR` |

## Procedure

**`tests/run_tests.R` is the supported runner.** It is the only path that produces JUnit XML reproducibly.

Note it lives in `tests/`, not `.github/scripts/` — unlike every other script in this pipeline. That placement is load-bearing (see below); do not move it.

```bash
cd <package-root>

# The pipeline invocation — same run directory as every other stage
Rscript tests/run_tests.R --junit --run-dir "$RUN" --filter "armada-dv_t01"

# Console only, for local development — no artifacts, so no run directory needed
Rscript tests/run_tests.R --filter "armada-dv_t01"
```

| Flag | Effect |
|---|---|
| `--junit` | Writes one XML per test file to `<run-dir>/junit/`. **Requires `--run-dir`.** |
| `--run-dir <path>` | The shared validation run directory. Resolved to an absolute path before use. |
| `--filter <pattern>` | Regex against test file basenames |

`--junit` without `--run-dir` exits **2** with an explanatory message rather than guessing a location.

### What the runner does

1. Resolves the package root as two directories above itself, and finds tests at `tests/testthat/`. At `tests/run_tests.R` this is correct. **Moving this script into `.github/scripts/` would break that** — the root would resolve to `.github/`, no test files would match, and it would exit 0 as a silent pass.
2. Loads `.env` from the package root if present.
3. Prepends `MERCURY_EXECUTOR_PATH` to `PYTHONPATH`.
4. Sources `setup.R`, then every `helper-*.R`, into one shared environment.
5. Runs each `test-*.R` with `stop_on_failure = FALSE`, so a failing file does not prevent later files running.
6. Prints a total and **exits 1 if anything failed or errored**.

It needs no package structure — no `DESCRIPTION`, no devtools.

## Outputs

**`<run-dir>/junit/test-armada-<tfl>.xml`** — one file per test script, named after the script.

Standard testthat `JunitReporter` output:

```xml
<testsuites>
  <testsuite name="section-1-domain: Domain matches requirement"
             tests="1" failures="0" errors="0" skipped="0" time="0.012">
    <testcase classname="test-armada-dv_t01" name="..." time="0.012"/>
  </testsuite>
</testsuites>
```

### Enriched output

When `helper-armada-junit.R` is present, `run_tests.R` uses `ArmadaJunitReporter` and each assertion additionally carries its evidence:

```xml
<testcase classname="armada-dv_t01" name="section_1_by_variable_..."
          id="ARMADA-DV_T01-1-BY_VARIABLE-01" time="0.02">
  <failure type="failure" message="Expected `actual` to equal `expected`...">…</failure>
  <properties>
    <property name="requirement_id" value="section-1-by_variable"/>
    <property name="assertion"      value="equal"/>
    <property name="expected"       value="TRT01PN/NA/TRT01P"/>
    <property name="actual"         value="TRT01AN/NA/TRT01A"/>
    <property name="metadata_uuid"  value="3f2a10c4-0006-4a00-9000-000000000002"/>
    <property name="metadata_path"  value="arm$byVariables -> var_group"/>
  </properties>
</testcase>
```

Evidence reaches the reporter only from assertions written as `expect_armada_equal()` / `expect_armada_match()` / `expect_armada_in()` (Stage 3). A bare `expect_*()` — a precondition guard, say — still produces a valid `<testcase>`, just without properties, and Stage 7 lists how many were omitted from the assertion matrix.

**`assertion` names the relation between `expected` and `actual`, and only `equal` means the two are identical.** Each wrapper emits its own token:

| Wrapper | Token | `expected` | `actual` |
|---|---|---|---|
| `expect_armada_equal()` | `equal` | the required value | the value found |
| `expect_armada_match()` | `match` | the pattern, in its `expected_display` form | the value found |
| `expect_armada_in()` | `member` | the value that must be present | **the set searched**, not a single value |

Without this token a reader applies equality to every row, and a passing `member` assertion — where the two columns legitimately differ — reads as a mismatch that somehow passed. XML produced before this property existed carries no `assertion`; Stage 7 renders those rows as `—` rather than guessing.

**testthat emits one `<testcase>` per expectation, not per `test_that()`.** Test counts therefore exceed requirement counts, and IDs carry a trailing index (`-01`, `-02`) to distinguish multiple assertions against one requirement.

Plus a console summary and an exit code:

```
Results: 133 passed, 9 failed/errored, 0 skipped
```

| Exit code | Meaning |
|---|---|
| 0 | All tests passed **or no test files matched the filter** — see acceptance checks |
| 1 | At least one failure or error |
| 2 | `--junit` was given without `--run-dir` |

## Acceptance checks

```bash
# The runner found tests — a filter typo yields "No test files matched" and exit 0
Rscript tests/run_tests.R --junit --run-dir "$RUN" --filter "armada-dv_t01"
echo "exit=$?"

# XML landed in the run directory
ls -l "$RUN/junit/"

# Test count in the XML matches the requirement count
grep -c '<testcase' "$RUN"/junit/*.xml
jq '.requirements | length' "$RUN/requirements.json"
```

**A filter that matches nothing exits 0 with the message `No test files matched filter:`.** Read the console output; do not trust the exit code alone. This is the most likely way to get a false green.

Failures at this stage are **information, not blockers** — a failing test means the metadata does not match the specification, which is exactly what validation exists to detect. Record it and carry on to Stage 5; Stage 7 reports both outcomes and will return FAIL.

When a test fails, resolve it in this order: confirm the requirement is right, then fix the metadata to match. Changing the test to match the metadata defeats the purpose.

## Handover

Stage 7 reads **every** XML in `<run-dir>/junit/` and aggregates them into the traceability matrix and coverage figures.

For that to work:
- At least one XML must exist in `<run-dir>/junit/`. An empty directory is reported as a missing input and yields an INCOMPLETE verdict.
- Test names must begin with their requirement ID (Stage 3 convention) — this is the **only** link between a test result and a requirement. Stage 7 normalises both sides before matching, since testthat rewrites `section-1-domain: ...` to `section_1_domain_...`.
- Every skip must carry a reason; Stage 7 fails the run on any skip without one.
- The `--run-dir` here must be the same one passed to every other stage.

## Known gaps

| Ref | Gap |
|---|---|
| ~~D3~~ | **Resolved.** Stage 4 now writes to `<run-dir>/junit/` and Stage 7 reads that same directory. |
| — | **The runner's location is load-bearing.** `repo_root <- dirname(dirname(script_path))` is only correct while the script sits at `tests/run_tests.R`. Relocating it — for instance to sit alongside the other pipeline scripts in `.github/scripts/` — would silently produce zero-test runs that exit 0. If it is ever moved, the root resolution must be changed with it. |
| ~~D-d~~ | **Resolved.** `tests/testthat/helper-armada-junit.R` defines `ArmadaJunitReporter`, an `R6` subclass of `testthat::JunitReporter` that emits `<testcase id="ARMADA-DV_T01-1-DOMAIN-01">` with nested `<properties>` for requirement ID, expected, actual, metadata UUID and metadata path. `run_tests.R` uses it when present and falls back to the stock reporter otherwise. Stage 7 matches on the `requirement_id` property, with name-prefix matching retained as a fallback. See "Enriched output" below. |
| — | The reporter depends on `JunitReporter$add_result` appending exactly one node to `self$suite`. That is internal testthat behaviour, not API. Injection is wrapped in `tryCatch`: a future testthat that breaks the assumption produces a warning and plain, valid JUnit rather than malformed XML. Re-check on a testthat major upgrade. |
| **D7** | `.env` loading is a no-op. `Sys.setenv(.envvar = val, .names = key)` is not a valid signature — it sets variables literally named `.envvar` and `.names`. Export anything you need from `.env` manually before running. |
| — | `--filter` is applied to basenames with `fixed = FALSE`, so regex metacharacters in the pattern are interpreted. |
