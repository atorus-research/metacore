# Unified Validation Report: Integration of All 7 Stages

## Overview

The unified validation report consolidates all evidence from the 7-stage ARMADA validation pipeline into a single, regulatory-ready document. This document serves as the definitive proof that metadata is fit for submission.

**Report Location:** `tests/documentation/{output_id}-validation-report.md`

---

## What Gets Integrated

### Section 1: Commit Information
**Source:** Git metadata + Stage 5 git-metadata.json
- Commit hash
- Author and date
- Repository and branch
- Related TFL ID and output ID

### Section 2: Requirements Summary
**Source:** Stage 1 requirements generation
- Total requirement count
- Requirements grouped by section
- Breakdown by requirement type:
  - Display labels
  - Statistical methods
  - Grouping variables
  - SDTM domain mappings
  - Filtering logic
  - Denominator definitions

### Section 3: Traceability Matrix
**Source:** Stage 6 validation tests (JUnit XML)
- Total requirements tested
- Pass/fail counts
- Overall coverage percentage
- Test execution timestamp
- Test framework (testthat)

### Section 4: Execution Verification
**Source:** Stage 7 execution results (JSON)
- Discovery results: ARMs found and converted
- Conversion results: LEDs generated
- Phase summary: Status of each execution phase
  - arm_conversion: Time to convert ARM → LED
  - arm_execution: Time to execute ARM LEDs
  - aom_conversion: Time to convert AOM → LED
  - aom_execution: Time to execute AOM LED
- Total execution duration
- Output verification: Confirms ARDs and PDF created

### Section 5: Combined Assessment
**Synthesized from all above**
- Overall validation status (PASS/FAIL)
- Execution status (SUCCESS/FAILED)
- Final recommendation: Fit for regulatory submission

---

## Data Flow During Stage 7 Execution

```
[Start: python armada_executor.py --output-id <name>]
              ↓
[Phase 1-4: Execute pipeline, collect results]
              ↓
[Save executor_logs/{output_id}_result.json]
              ↓
[Automatic: unified_report_generator.py launches]
              ↓
[Load: requirements.json, git_metadata.json, junit XML]
       + execution_results.json
              ↓
[Generate: 5-section markdown report]
              ↓
[Save: tests/documentation/{output_id}-validation-report.md]
              ↓
[Result: Single comprehensive report ready for audit]
```

---

## Report Structure Example

```markdown
# ARMADA Validation Report: Complete Pipeline Evidence

This document consolidates all validation and execution evidence for regulatory submission.

## 1. COMMIT INFORMATION

**Commit Hash:** `a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6`
**Author:** Jane Smith
**Date:** 2024-01-15T10:30:00Z
**Repository:** gsk-tech/armada-metadata
**Branch:** pa_01

**Related TFL:** DV 01 Subject Enrollment Summary - Across Study
**Output ID:** `dv_t01_sum_impo_prot_dev_armada`

## 2. REQUIREMENTS SUMMARY

**Total Requirements:** 47
**Grouped by:** 4 sections

### Overview by Type

| Type | Count | Description |
|------|-------|-------------|
| `display_label` | 12 | Section display labels (human-readable names) |
| `method` | 8 | Statistical methods (calculations) |
| `by_variable` | 15 | Grouping/stratification variables |
| `domain` | 7 | SDTM domain source mappings |
| `subset` | 3 | Filtering logic (inclusion/exclusion) |
| `denominator` | 2 | Denominator dataset definitions |

## 3. TRACEABILITY MATRIX: Validation Evidence

**Test Execution Date:** 2024-01-15T10:35:42Z
**Test Framework:** testthat (R)
**Overall Status:** ✅ PASS (47/47 = 100%)

### Coverage Summary

| Metric | Value |
|--------|-------|
| Total Requirements | 47 |
| Passed | 47 |
| Failed | 0 |
| Coverage | 100% |

## 4. EXECUTION VERIFICATION: Operational Evidence

**Execution Date:** 2024-01-15T10:40:15Z
**Total Duration:** 24.4 seconds
**Overall Status:** ✅ SUCCESS

### Phase Summary

- **arm_conversion:** ✅ (1.7s)
- **arm_execution:** ✅ (13.7s)
- **aom_conversion:** ✅ (0.8s)
- **aom_execution:** ✅ (8.2s)

### Discovery Results

**ARM Files Discovered:** 4
**ARM Files Converted:** 4
**AOM Files Converted:** 1

### Execution Results

**LEDs Executed:** 5
- ✅ analysis-set-enrolled-counts
- ✅ dv-any-count
- ✅ dv-by-acat-adecod-count
- ✅ dv-by-acat-count
- ✅ dv_t01_sum_impo_prot_dev_armada

## 5. COMBINED VALIDATION EVIDENCE SUMMARY

### Validation Evidence (Stage 6)

✅ **All requirements validated against metadata**

- Metadata structure: CORRECT
- All requirement mappings: PASS (47/47)
- Coverage: 100%

### Execution Evidence (Stage 7)

✅ **All execution phases successful**

- Metadata discovery: 4 ARM files found
- Metadata conversion: 4 ARM + 1 AOM converted
- Metadata execution: 5 LEDs executed
- Output generation: ARDs and PDF successfully created

### Combined Assessment

✅ **METADATA IS FIT FOR REGULATORY SUBMISSION**

The ARMADA metadata for TFL `dv_t01_sum_impo_prot_dev_armada` has been:
1. **Validated** - All requirements tested
2. **Executed** - Successfully converted to LEDs and executed
3. **Verified** - Output datasets and PDF generated

**Report Generated:** 2024-01-15T10:40:22Z
**Status:** ✅ COMPLETE
```

---

## How to Use the Unified Report

### 1. Generate the Report
The report is **automatically generated** after Stage 7 execution completes successfully:

```bash
python /mnt/imported/code/standard-led/.github/scripts/armada_executor.py \
  --output-id dv_t01_sum_impo_prot_dev_armada \
  --verbose true \
  --log-file executor_logs/dv_t01_execution.log
```

This creates two files:
- `executor_logs/dv_t01_execution.log` — detailed phase-by-phase log
- `executor_logs/dv_t01_execution_result.json` — structured result data
- **`tests/documentation/dv_t01_sum_impo_prot_dev_armada-validation-report.md`** ← Unified Report

### 2. Review the Report
Open the markdown report and verify:
- ✅ Commit information correctly identifies the feature branch
- ✅ All requirements are listed and accounted for
- ✅ Traceability matrix shows 100% coverage with all tests passing
- ✅ Execution section shows all phases successful with ARDs/PDF created
- ✅ Final assessment declares metadata ready for submission

### 3. Use in Regulatory Submission
The unified report serves as:
- **Audit trail** — proves which commit was validated
- **Evidence of testing** — shows all requirements validated by automated tests
- **Evidence of execution** — shows metadata converted and executed successfully
- **Regulatory document** — ready for submission with no additional compilation

---

## Report Generation Details

### What's Required for Each Section

| Section | Requires | Status if Missing |
|---------|----------|-------------------|
| Commit Info | Git metadata | ⚠️ Shows "N/A" |
| Requirements | requirements.json from Stage 1 | ⚠️ Shows "No data" |
| Traceability | JUnit XML from Stage 4 tests | ⚠️ Shows "No data" |
| Execution | executor_logs/{id}_result.json | ⚠️ Shows "No data" |
| Combined Assessment | ✅ + ✅ above | ✅ Always shows result |

### Automatic Triggering

The report generator is called automatically if:
1. Stage 7 execution completes with status `success`
2. Python script `unified_report_generator.py` exists at `.github/scripts/`
3. Output directory `tests/documentation/` can be created
4. Source files are accessible from current working directory

### Manual Generation

If needed, manually generate the report:

```bash
cd /mnt/code

python .github/scripts/unified_report_generator.py \
  dv_t01_sum_impo_prot_dev_armada \
  tests/documentation/dv_t01_sum_impo_prot_dev_armada-validation-report.md
```

---

## Integration in 7-Stage Pipeline

```
Stage 1: Generate requirements from schema
          ↓
Stage 2: Collect metadata
          ↓
Stage 3: Create validation tests
          ↓
Stage 4: Run tests → JUnit XML results
          ↓
Stage 5: Capture git metadata
          ↓
Stage 6: Generate traceability matrix
          ↓
Stage 7: Execute metadata → JSON results
          ↓
[Automatic Report Generation]
          ↓
Output: tests/documentation/{id}-validation-report.md
        = Single regulatory-ready document with all evidence
```

---

## Troubleshooting

### Report Not Generated
**Check:**
1. Did Stage 7 execution complete with `status: "success"`?
2. Do source files exist?
   - `executor_logs/{output_id}_result.json`
   - `tests/results/junit-{output_id}-results.xml` (if tests ran)
3. Can Python script write to `tests/documentation/`?

### Sections Missing Data
**Expected:** Some sections may show "No data available" if earlier stages weren't run.
**Fix:** Run full pipeline from Stage 1 to populate all sections.

### Report Formatting Issues
**Check:** Markdown viewer compatibility (GitHub, VS Code, pandoc all supported)

---

## Next Steps

After generating the unified report:
1. **Review** the complete report end-to-end
2. **Commit** to feature branch with validation evidence
3. **Create PR** linking to this report
4. **Submit** to regulatory team as part of submission package

---

## Related Documentation

- [ARMADA Validation Framework](./END_TO_END_VALIDATION_GUIDE.md) — 7-stage overview
- [Stage 7: LED Execution](./STAGE7_EXECUTION.md) — How to run Stage 7
- [ARMADAExecutor API](./armada-led-execution.md) — Detailed class documentation
