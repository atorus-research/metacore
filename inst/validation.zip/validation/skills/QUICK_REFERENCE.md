# ARMADA Validation Pipeline: Quick Reference

## One-Command Summary

```bash
# Stage 1: Extract requirements
./.github/scripts/armada_validate.sh "https://dev.azure.com/..." json /tmp/requirements.json

# Stage 2: Collect metadata
python ./.github/scripts/armada_metadata_collector.py dv_t01_sum_impo_prot_dev_armada --graph /tmp/metadata.json

# Stage 3: Generate tests (AGENT - see prompt below)
# Invoke: task --agent general-purpose --name "Generate ARMADA Validation Tests" --prompt "..."

# Stage 4: Run validation tests
Rscript -e "testthat::test_file('tests/testthat/test-armada-dv_t01.R')"

# Stage 5: Capture git metadata (for audit trail)
python ./.github/scripts/capture_git_metadata.py /tmp/git_metadata.json

# Stage 6: Generate traceability matrix (documents validation results)
# Invoke: task --agent general-purpose --name "Generate ARMADA Traceability Matrix" --prompt "..."

# ============ VALIDATION COMPLETE ============
# After validation is approved, execute to generate ARDs and PDFs:

# Stage 7: Execute LEDs to generate ARDs and PDFs
cd /mnt/code
python ../.github/scripts/armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada --verbose true --log-file executor_logs/step5_execution.log
```

---

## Agent Invocation for Stage 3 (Test Generation)

**Minimal Prompt:**
```
Generate R testthat tests for ARMADA metadata validation.

Inputs:
- .github/skills/armada-metadata-validation.md (skill doc)
- /tmp/requirements.json (extracted requirements)
- /tmp/metadata.json (ARMADA metadata)

Outputs:
- tests/testthat/helper-armada-dv_t01.R (helper functions)
- tests/testthat/test-armada-dv_t01.R (18 requirement-driven tests)

Key patterns:
- Each test extracts EXPECTED from requirements.json
- Each test extracts ACTUAL from metadata.json
- Each test compares with proper testthat assertions
- Use 3 display_label patterns correctly

Expected: 9 PASS / 9 FAIL
```

---

## Agent Invocation for Stage 6 (Traceability Matrix)

**Minimal Prompt:**
```
Generate comprehensive traceability matrix from validation results.

Inputs:
- .github/skills/armada-traceability-reporting.md (skill doc)
- /tmp/requirements.json (requirements)
- /tmp/metadata.json (metadata)
- /tmp/git_metadata.json (commit info)
- tests/testthat/test-armada-dv_t01.R (test code)

Outputs:
- tests/documentation/dv_t01-traceability-matrix.md (detailed matrix)
- tests/documentation/dv_t01-traceability-matrix.html (interactive report)

Include:
- Commit info header (hash, author, date, branch)
- 18 unique test IDs (ARMADA-DV_T01-1-DISPLAY_LABEL-01, etc.)
- For each test: Status | Expected | Actual | Reason | Evidence
- Summary table and coverage
```

---

## Stage 7: LED Execution & ARD/PDF Generation

**What:** After validation is APPROVED, convert ARMADA metadata (ARM and AOM) to LEDs and execute them to generate Analysis Result Datasets (ARDs) and PDF outputs.

**Important:** This stage happens ONLY AFTER:
1. ✅ Requirements extracted and documented
2. ✅ Metadata validated against requirements (tests passed)
3. ✅ Validation traceability matrix generated (for audit trail)

**Command:**
```bash
cd /mnt/code

# Full execution with logging
python ../.github/scripts/armada_executor.py \
  --output-id dv_t01_sum_impo_prot_dev_armada \
  --verbose true \
  --log-file executor_logs/step5_execution.log

# Dry-run mode (preview commands without executing)
python ../.github/scripts/armada_executor.py \
  --output-id dv_t01_sum_impo_prot_dev_armada \
  --dry-run true \
  --verbose true
```

**What It Does:**
1. Discovers all ARM files linked to the target AOM
2. Converts each ARM → LED using `make convert_1arm`
3. Converts the AOM → LED using `make convert_1aom`
4. Executes all ARM LEDs first (creates ARDs for table data)
5. Executes the AOM LED last (creates final PDF and mock shell)

**Output Files:**
- ARDs: `/mnt/data/{project}/prod/adamdata/*.parquet`
- PDFs: `/mnt/data/{project}/prod/tfls/`
- Mock shells: `/mnt/data/{project}/prod/tfls/*_mock.html`
- Execution log: `executor_logs/step5_execution.log`

**Sample Output:**
```
================================================================================
ARMADA LED Execution Pipeline
Output ID: dv_t01_sum_impo_prot_dev_armada
================================================================================

PHASE 1: Discover ARM Files
✓ Discovered 3 ARM files:
  - ae-any-count
  - ae-by-soc-count
  - ae-by-soc-pt-count

PHASE 2: Convert ARM → LED
✓ Converted: ae-any-count
✓ Converted: ae-by-soc-count
✓ Converted: ae-by-soc-pt-count
✓ ARM conversion complete: 3/3 succeeded

PHASE 3: Convert AOM → LED
✓ Converted: dv_t01_sum_impo_prot_dev_armada
✓ AOM conversion complete: 1/1 succeeded

PHASE 4: Execute ARM LEDs
✓ Executed: adam_arm_ae_any_count_01 (12.3s)
✓ Executed: adam_arm_ae_by_soc_count_01 (15.7s)
✓ Executed: adam_arm_ae_by_soc_pt_count_01 (18.2s)
✓ ARM execution complete: 3/3 succeeded

PHASE 5: Execute AOM LED
✓ Executed: adam_aom_dv_t01_sum_impo_prot_dev_armada_01 (8.5s)

================================================================================
EXECUTION SUMMARY
================================================================================
Status: SUCCESS
Total Duration: 74.1s
ARM files discovered: 3
ARM files converted: 3
AOM files converted: 1
LEDs created: 4
LEDs executed: 4
================================================================================
```

---

## Audit Trail & Reproducibility

### Validation Results (Stage 6 Output)
The traceability matrix documents:
- Requirements extracted from ADO schema
- Tests run against metadata
- Test results (PASS/FAIL)
- Commit info for reproducibility
- Evidence linking requirements to tests

### Execution Results (Stage 7 Output)
The execution log documents:
- Exact make commands run
- Timestamps for each phase
- Success/failure status
- Execution duration
- Output file locations

**Together, they provide full regulatory audit trail for the TFL output.**

**Minimal Prompt:**
```
Generate comprehensive traceability matrix from validation results.

Inputs:
- .github/skills/armada-traceability-reporting.md (skill doc)
- /tmp/requirements.json (requirements)
- /tmp/metadata.json (metadata)
- /tmp/git_metadata.json (commit info)
- tests/testthat/test-armada-dv_t01.R (test code)

Outputs:
- tests/documentation/dv_t01-traceability-matrix.md (detailed matrix)
- tests/documentation/dv_t01-traceability-matrix.html (interactive report)

Include:
- Commit info header (hash, author, date, branch)
- 18 unique test IDs (ARMADA-DV_T01-1-DISPLAY_LABEL-01, etc.)
- For each test: Status | Expected | Actual | Reason | Evidence
- Summary table and coverage
```

---

## File Summary

| Stage | Input | Output | Purpose | Status |
|-------|-------|--------|---------|--------|
| 1 | ADO URL | requirements.json | Extract schema requirements | ✅ |
| 2 | Output ID | metadata.json | Collect ARMADA metadata | ✅ |
| 3 | Req+Meta | helper-armada*.R | Generate test helpers | ✅ (AGENT) |
| 3 | Req+Meta | test-armada*.R | Generate validation tests | ✅ (AGENT) |
| 4 | Tests | Console | Run validation (PASS/FAIL) | ✅ |
| 5 | Branch | git_metadata.json | Capture audit trail | ✅ |
| 6 | Tests+Req+Meta+Git | traceability.md | Document validation evidence | ✅ (AGENT) |
| 6 | All | traceability.html | Interactive validation report | ✅ (AGENT) |
| **7** | **LEDs** | **ARDs + PDFs** | **Execute to generate outputs** | **✅ (NEW: armada_executor.py)** |

---

## Test Results

```
Total: 18 tests (6 types × 3 sections)

✅ PASS (9):
  - display_label (S1, S2, S3) = 3 PASS
  - method (S1, S2, S3) = 3 PASS
  - domain (S1, S2, S3) = 3 PASS
  - subset (S1, S2, S3) = 3 PASS

❌ FAIL (9):
  - by_variable (S1, S2, S3) = 3 FAIL (expected TRT01PN/P, actual TRT01AN/A)
  - denominator (S1, S2, S3) = 3 FAIL (expected enrolled-counts, actual safety-counts)

Coverage: 50% (9 PASS / 9 FAIL)
```

---

## Key Directories

- Requirements: `/tmp/requirements.json`
- Metadata: `/tmp/metadata.json`
- Git metadata: `/tmp/git_metadata.json`
- Tests: `tests/testthat/test-armada-*.R`
- Helpers: `tests/testthat/helper-armada-*.R`
- Reports: `tests/documentation/dv_t01-traceability-matrix.*`
- Skills: `.github/skills/armada-*.md`
- Scripts: `.github/scripts/armada_*.py`, `.github/scripts/capture_git_metadata.py`

---

## For Regulatory Submission

1. Ensure clean repo: `git status`
2. Commit changes: `git commit -am "..."`
3. Capture git metadata: `python ./.github/scripts/capture_git_metadata.py /tmp/git_metadata.json`
4. Run validation pipeline (Stages 1-6)
5. Include in submission:
   - Commit hash: `76e481fb597096a40b995a0801b3f43f96f56f3f`
   - Traceability matrix: `tests/documentation/dv_t01-traceability-matrix.md`
   - HTML report: `tests/documentation/dv_t01-traceability-matrix.html`
   - Instructions for reproducibility

---

## Tips

- **Agent timeout?** Increase --timeout parameter or use background mode
- **Tests fail?** Check if metadata YAML needs updates to match requirements
- **No uncommitted changes warning:** Run test with clean git repo first
- **Large metadata?** Metadata collector handles 48+ entities, should scale to 100+
- **Fast feedback:** Run stage 4 only after generating tests to verify quickly

