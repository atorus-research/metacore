# Stage 7: LED Execution & ARD/PDF Generation

**Quick Start:** Run the LED execution pipeline after validation is complete

---

## Prerequisites

1. ✅ Validation tests PASSED (Stage 4)
2. ✅ Traceability matrix GENERATED (Stage 6)
3. ✅ Validation approved for release
4. ✅ Environment variables set in Domino

---

## Quick Start

```bash
cd /mnt/code

# Full execution with verbose logging
python ../.github/scripts/armada_executor.py \
  --output-id dv_t01_sum_impo_prot_dev_armada \
  --verbose true \
  --log-file executor_logs/dv_t01_execution.log
```

### Monitor Progress

```bash
# Watch log in real-time
tail -f /mnt/code/executor_logs/dv_t01_execution.log

# Or use the CLI wrapper
/mnt/imported/code/standard-led/.github/scripts/armada_execute.sh \
  dv_t01_sum_impo_prot_dev_armada \
  --log-file /tmp/execution.log
```

### Verify Outputs

```bash
# Check ARD files
ls -lh /mnt/data/${DOMINO_PROJECT_NAME}/prod/adamdata/

# Check PDF outputs
ls -lh /mnt/data/${DOMINO_PROJECT_NAME}/prod/tfls/

# Check execution log
cat /mnt/code/executor_logs/dv_t01_execution.log
```

---

## What Gets Created

### LEDs (Linked Executable Definitions)

Located in `/mnt/code/executor/metadata/led/`:

```
adam_arm_ae_any_count_01.yaml          # Derived from ARM
adam_arm_ae_by_soc_count_01.yaml       # Derived from ARM
adam_arm_ae_by_soc_pt_count_01.yaml    # Derived from ARM
adam_aom_dv_t01_sum_impo_prot_dev_armada_01.yaml  # Derived from AOM
```

### Analysis Result Datasets (ARDs)

Located in `/mnt/data/{project}/prod/adamdata/`:

```
ae_any_count.parquet                   # From ARM execution
ae_by_soc_count.parquet                # From ARM execution
ae_by_soc_pt_count.parquet             # From ARM execution
dv_t01.parquet                         # From AOM execution (final table)
```

### Tables and Figures (TFLs)

Located in `/mnt/data/{project}/prod/tfls/`:

```
dv_t01.pdf                             # Final PDF output
dv_t01_mock.html                       # Mock shell (for validation)
dv_t01_metadata.json                   # Output metadata
```

---

## Execution Flow

The executor runs in 5 phases:

```
┌─────────────────────────────────────────────────────────────┐
│ PHASE 1: Discover ARM Files                                 │
│ - Read target AOM YAML                                      │
│ - Extract linked ARM UUIDs                                  │
│ - Map to ARM files in metadata directory                    │
│ Result: List of 3 ARM files to process                      │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ PHASE 2: Convert ARM → LED                                  │
│ For each ARM:                                               │
│   - Run: make convert_1arm what='arm_file.yaml'             │
│   - Result: LED YAML file created                           │
│ Result: 3 ARM LEDs in metadata/led/                         │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ PHASE 3: Convert AOM → LED                                  │
│ For target AOM:                                             │
│   - Run: make convert_1aom what='aom_file.yaml'             │
│   - Result: LED YAML file created                           │
│ Result: 1 AOM LED in metadata/led/                          │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ PHASE 4: Execute ARM LEDs (Creates ARDs)                    │
│ For each ARM LED (sequential):                              │
│   - Run: make run args='--led adam_arm_XXX_01'              │
│   - Result: Parquet file in prod/adamdata/                  │
│ Result: 3 ARD files created                                 │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ PHASE 5: Execute AOM LED (Creates Final PDF)                │
│ For AOM LED:                                                │
│   - Run: make run args='--led adam_aom_XXX_01'              │
│   - Result: PDF + HTML in prod/tfls/                        │
│ Result: Final TFL output created                            │
└─────────────────────────────────────────────────────────────┘
```

---

## Exit Codes

```
0   Success - all phases completed successfully
1   Failure - one or more phases failed
```

---

## Options

### Full Command Syntax

```bash
python armada_executor.py \
  --output-id <output_id> \              # Required: target AOM ID
  --work-dir /mnt/code \                 # Optional: metadata directory (default)
  --dry-run true|false \                 # Optional: preview without executing
  --verbose true|false \                 # Optional: detailed logging
  --log-file <path> \                    # Optional: write logs to file
  --stop-on-error true|false             # Optional: stop on first error (default: true)
```

### Examples

```bash
# Basic execution
python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada

# Dry-run mode (preview all commands)
python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada --dry-run true

# Verbose with logging
python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada \
  --verbose true --log-file /tmp/exec.log

# Continue on error (instead of stopping)
python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada \
  --stop-on-error false

# Custom work directory
python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada \
  --work-dir /custom/path
```

### CLI Wrapper

```bash
# Simple wrapper (requires shell)
./armada_execute.sh dv_t01_sum_impo_prot_dev_armada

# With options
./armada_execute.sh dv_t01_sum_impo_prot_dev_armada \
  --dry-run true \
  --verbose true

# Help
./armada_execute.sh --help
```

---

## Troubleshooting

### Environment Variables Not Set

**Error:**
```
KeyError: MERCURY_EXECUTOR_PATH not set
```

**Solution:**
```bash
# In Domino: Account Settings → Environment Variables
# Or temporarily:
export MERCURY_EXECUTOR_PATH="/path"
export LED_TOOLING_PATH="/path"
export MERCURY_METADATA_PATH="/mnt/code/executor/metadata"
export DOMINO_PROJECT_NAME="project"
```

### Output ID Not Found

**Error:**
```
FileNotFoundError: /mnt/code/executor/metadata/main_aom/invalid_id.yaml
```

**Solution:**
```bash
# List available output IDs
ls /mnt/code/executor/metadata/main_aom/*.yaml | xargs basename -a
```

### Make Command Fails

**Error:**
```
make: *** [convert_1arm] Error 2
```

**Solution:**
1. Check Makefile exists: `ls /mnt/code/Makefile`
2. Try dry-run to see exact commands: `--dry-run true`
3. Check logs: `tail -100 /mnt/code/executor_logs/*.log`
4. Run make command manually to see error

### Execution Hangs or Times Out

**Note:** Each phase has a 5-minute timeout. If exceeded:

1. Check Mercury Executor logs: `/mnt/code/executor_logs/`
2. Try `--stop-on-error false` to skip failed LED
3. Rerun just the failed LED manually: `cd /mnt/code && make run args='--led adam_arm_XXX_01'`

---

## JSON Output

The executor returns structured JSON on stdout:

```bash
python armada_executor.py --output-id dv_t01_sum_impo_prot_dev_armada | jq .
```

**Output structure:**
```json
{
  "status": "success",
  "output_id": "dv_t01_sum_impo_prot_dev_armada",
  "total_duration": 74.1,
  "arms_discovered": 3,
  "arms_converted": ["ae-any-count", "ae-by-soc-count", "ae-by-soc-pt-count"],
  "aom_converted": "dv_t01_sum_impo_prot_dev_armada",
  "leds_created": ["adam_arm_ae_any_count_01", "..."],
  "leds_executed": ["adam_arm_ae_any_count_01", "..."],
  "failed_commands": [],
  "phases": {
    "arm_conversion": {"status": "success", "duration": 5.2, "items_processed": 3},
    "aom_conversion": {"status": "success", "duration": 2.8, "items_processed": 1},
    "arm_execution": {"status": "success", "duration": 46.2, "items_processed": 3},
    "aom_execution": {"status": "success", "duration": 8.5, "items_processed": 1}
  }
}
```

---

## Audit Trail

### What's Documented

1. **Execution log** (`executor_logs/step5_execution.log`):
   - Timestamp of execution
   - Exact make commands run
   - Success/failure for each phase
   - Duration for each component
   - Output file locations

2. **Git commit** (for reproducibility):
   - Commit hash
   - Author
   - Branch
   - Date/time

3. **Input metadata** (for traceability):
   - ARM and AOM files converted
   - Links to requirements (from Stage 6 traceability matrix)

### For Regulatory Submission

Include with submission:
1. ✅ Traceability matrix from Stage 6 (validation evidence)
2. ✅ Execution log from Stage 7 (this stage)
3. ✅ Commit hash (for reproducibility)
4. ✅ Instructions for running stages 1-7

---

## Unified Report Generation (Automatic)

After execution completes with status `success`, a unified validation report is **automatically generated** that combines:
- Commit information (git metadata)
- Requirements summary (from Stage 1)
- Traceability matrix (from Stage 6 tests)
- Execution verification (Stage 7 results you just created)

### Generated Report File

```bash
tests/documentation/{output_id}-validation-report.md
```

**Example:**
```
tests/documentation/dv_t01_sum_impo_prot_dev_armada-validation-report.md
```

### What the Report Contains

**Section 1: Commit Information**
- Commit hash, author, date, repository, branch
- Ensures validation tied to exact code state

**Section 2: Requirements Summary**
- All requirements extracted from source (ADO card)
- Organized by section and type
- Shows what was required to validate

**Section 3: Traceability Matrix**
- Requirements → Test mappings
- Test results (PASS/FAIL) from Stage 4
- Coverage percentage

**Section 4: Execution Verification**
- ARM discovery results (how many found, converted, executed)
- AOM execution results (conversion time, execution time)
- Confirmed outputs generated (ARDs and PDF)
- Total duration and status for each phase

**Section 5: Combined Assessment**
- Overall validation status (all requirements tested?)
- Overall execution status (all LEDs executed successfully?)
- Final recommendation: **Fit for regulatory submission?**

### Verify Report Generation

```bash
# Check if report was created
ls -lh tests/documentation/{output_id}-validation-report.md

# View the report
cat tests/documentation/{output_id}-validation-report.md

# Or in an editor
code tests/documentation/{output_id}-validation-report.md
```

### Manual Report Generation (if needed)

If report wasn't automatically generated, generate manually:

```bash
cd /mnt/code

python .github/scripts/unified_report_generator.py \
  dv_t01_sum_impo_prot_dev_armada \
  tests/documentation/dv_t01_sum_impo_prot_dev_armada-validation-report.md
```

### Use in Regulatory Submission

The unified report serves as:
- **Complete audit trail** — All evidence in one place
- **Validation proof** — Shows all requirements tested
- **Execution proof** — Shows metadata converted and executed
- **Regulatory document** — Ready to attach to submission

---

## Related Documentation

- **UNIFIED_REPORT.md** — Complete guide to unified report generation
- **armada-led-execution.md** — Full API reference and architecture
- **END_TO_END_VALIDATION_GUIDE.md** — Complete pipeline (all 7 stages)
- **QUICK_REFERENCE.md** — Quick reference for all stages

